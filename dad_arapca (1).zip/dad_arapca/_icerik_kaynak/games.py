"""Oyunlar için veri: Hareke Avı çeldiricileri.

Her uygun kelime için harekelerinden bir ya da ikisi değiştirilmiş üç yanlış
şık üretilir. Sözlükte başka bir kelimenin harekeli hâliyle aynı olan şık
kullanılmaz (geçerli başka bir okunuş doğru cevabı belirsizleştirmesin).
"""
import random

F, D, K, S, SH = 'َ', 'ُ', 'ِ', 'ْ', 'ّ'
VOW = (F, D, K)
MARKS = set('ًٌٍَُِّْٰ')


def units(s):
    out = []
    for ch in s:
        if ch in MARKS and out:
            out[-1][1].append(ch)
        else:
            out.append([ch, []])
    return out


def join(us):
    return ''.join(b + ''.join(m) for b, m in us)


def plain(s):
    return ''.join(ch for ch in s if ch not in MARKS)


def variants(ar, rnd):
    us = units(ar)
    def long_next(i):
        if i + 1 >= len(us):
            return False
        nb, nm = us[i + 1]
        return nb in 'اى' or (nb in 'وي' and not nm)

    pos = [i for i, (b, m) in enumerate(us[:-1])
           if sum(1 for x in m if x in VOW) == 1 and not set(m) - {F, D, K, SH}
           and b not in 'اأإآؤئء' and not long_next(i)]
    if len(pos) < 2:
        return []

    def change(base, i, to):
        us2 = [[b, list(m)] for b, m in base]
        m = us2[i][1]
        v = next(x for x in m if x in VOW)
        if to == S:
            if SH in m or i == 0 or (i + 1 < len(us2) and SH in us2[i + 1][1]):
                return None
            # yan yana iki sükûn olmasın
            for j in (i - 1, i + 1):
                if 0 <= j < len(us2) and S in us2[j][1]:
                    return None
            us2[i][1] = [S]
        else:
            us2[i][1] = [to if x == v else x for x in m]
        return us2

    cands = set()
    for _ in range(60):
        k = 1 if rnd.random() < 0.6 else 2
        cur = [[b, list(m)] for b, m in us]
        ok = True
        for i in rnd.sample(pos, min(k, len(pos))):
            v = next(x for x in cur[i][1] if x in VOW)
            to = rnd.choice([x for x in VOW if x != v] + ([S] if rnd.random() < 0.25 else []))
            nxt = change(cur, i, to)
            if nxt is None:
                ok = False
                break
            cur = nxt
        if ok:
            s = join(cur)
            if s != ar:
                cands.add(s)
    return sorted(cands)


def hareke_items(words):
    known = {w['ar'] for w in words}
    out = {}
    for w in words:
        ar = w['ar']
        if ' ' in ar or w.get('tag') or not (3 <= len(plain(ar)) <= 9):
            continue
        rnd = random.Random(w['id'] + ar)
        c = [x for x in variants(ar, rnd) if x not in known]
        if w.get('pos') == 'f':
            c = [x for x in c if not is_passive(x)]
        if len(c) < 3:
            continue
        out[w['id']] = rnd.sample(c, 3)
    return out


def is_passive(s):
    """Fiilin meçhul (edilgen) okunuşu geçerli bir şekildir; çeldirici olamaz."""
    vs = [next((x for x in m if x in VOW), None) for _, m in units(s)]
    vs = [v for v in vs[:-1] if v]
    return len(vs) >= 2 and vs[0] == D and vs[-1] == K
