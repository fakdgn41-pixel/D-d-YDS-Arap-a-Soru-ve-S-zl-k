import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

/// Harekeleri siler (Hareke Avı'nda soru hâli için).
String stripHarakat(String s) => s.replaceAll(RegExp('[ً-ْٰ]'), '');

const List<(String, String)> _kGameDecks = [
  ('all', 'Bütün kelimeler'),
  ('yds', "YDS'de çıkanlar"),
  ('saved', 'Kayıtlı'),
];

// ====================================================================
// Oyunlar ana ekranı
// ====================================================================
class GamesHomeScreen extends StatefulWidget {
  const GamesHomeScreen({super.key});

  @override
  State<GamesHomeScreen> createState() => _GamesHomeScreenState();
}

class _GamesHomeScreenState extends State<GamesHomeScreen> {
  String deck = 'all';

  List<(String, String)> get decks => [
        ..._kGameDecks,
        for (final e in kKonu.entries) ('k:${e.key}', e.value),
      ];

  void _open(Widget screen) =>
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Oyunlar')),
        body: ListenableBuilder(
          listenable: AppState.I,
          builder: (context, _) {
            final st = AppState.I;
            return ListView(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              children: [
                const Text(
                  'Oynarken öğren. Oyunlarda bilemediğin kelimeler, kelime kartlarında yeniden karşına çıkar.',
                  style: TextStyle(fontSize: 14.5, color: C.muted, height: 1.5),
                ),
                const SizedBox(height: 16),
                const Text('KELİME HAVUZU', style: labelCaps),
                const SizedBox(height: 8),
                SizedBox(
                  height: 40,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [for (final d in decks) _deckChip(d.$1, d.$2)],
                  ),
                ),
                const SizedBox(height: 18),
                _GameTile(
                  icon: Icons.bolt_rounded,
                  title: 'Kelime Yarışı',
                  desc: '60 saniyede kaç kelime bilirsin? Arka arkaya bildikçe puan katlanır.',
                  best: st.gameBest['yaris'] == null ? null : 'Rekor: ${st.gameBest['yaris']} puan',
                  onTap: () => _open(RaceGameScreen(pool: st.gamePool(deck))),
                ),
                const SizedBox(height: 10),
                _GameTile(
                  icon: Icons.join_inner_rounded,
                  title: 'Eşleştirme',
                  desc: 'Arapça kelimeyi Türkçe anlamıyla eşleştir. 3 tur, 15 kelime.',
                  best: st.gameBest['eslestir'] == null ? null : 'Rekor: ${st.gameBest['eslestir']} puan',
                  onTap: () => _open(MatchGameScreen(pool: st.gamePool(deck))),
                ),
                const SizedBox(height: 10),
                _GameTile(
                  icon: Icons.track_changes_rounded,
                  title: 'Hareke Avı',
                  desc: 'Harekesiz kelimenin doğru okunuşunu bul. 10 soru.',
                  best: st.gameBest['hareke'] == null ? null : 'Rekor: ${st.gameBest['hareke']} / 10',
                  onTap: () => _open(HarekeGameScreen(pool: st.gamePool(deck))),
                ),
              ],
            );
          },
        ),
      );

  Widget _deckChip(String key, String label) {
    final sel = deck == key;
    return Padding(
      padding: const EdgeInsets.only(right: 6),
      child: Material(
        color: sel ? C.ink : C.surface,
        shape: StadiumBorder(side: BorderSide(color: sel ? C.ink : C.line)),
        child: InkWell(
          customBorder: const StadiumBorder(),
          onTap: () => setState(() => deck = key),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Center(
              widthFactor: 1,
              child: Text(label,
                  style: TextStyle(
                      fontSize: 13.5, fontWeight: FontWeight.w600, color: sel ? Colors.white : C.muted)),
            ),
          ),
        ),
      ),
    );
  }
}

class _GameTile extends StatelessWidget {
  final IconData icon;
  final String title, desc;
  final String? best;
  final VoidCallback onTap;
  const _GameTile({required this.icon, required this.title, required this.desc, this.best, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
        color: C.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: C.line)),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 14, 10, 14),
            child: Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(color: C.accentSoft, borderRadius: BorderRadius.circular(16)),
                  child: Icon(icon, color: C.accentDark, size: 28),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: C.ink)),
                      const SizedBox(height: 2),
                      Text(desc, style: const TextStyle(fontSize: 13.5, color: C.muted, height: 1.35)),
                      if (best != null) ...[
                        const SizedBox(height: 6),
                        Pill(best!, bg: C.goldSoft, fg: C.gold, size: 11.5),
                      ],
                    ],
                  ),
                ),
                const Icon(Icons.play_circle_fill_rounded, color: C.accent, size: 34),
              ],
            ),
          ),
        ),
      );
}

// ====================================================================
// Ortak parçalar
// ====================================================================
enum _Mark { none, right, wrong }

/// Cevap şıkkı: doğruysa yeşil, yanlış seçildiyse kırmızı.
class _Choice extends StatelessWidget {
  final Widget child;
  final _Mark mark;
  final VoidCallback? onTap;
  final double minHeight;
  const _Choice({required this.child, this.mark = _Mark.none, this.onTap, this.minHeight = 58});

  @override
  Widget build(BuildContext context) {
    final bg = switch (mark) { _Mark.right => C.goodSoft, _Mark.wrong => C.badSoft, _Mark.none => C.surface };
    final bd = switch (mark) { _Mark.right => C.good, _Mark.wrong => C.bad, _Mark.none => C.line };
    return Material(
      color: bg,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14), side: BorderSide(color: bd, width: mark == _Mark.none ? 1 : 2)),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: ConstrainedBox(
          constraints: BoxConstraints(minHeight: minHeight),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            child: Center(child: child),
          ),
        ),
      ),
    );
  }
}

/// Oyun sonu ekranı: skor, rekor ve bilinemeyen kelimeler.
class _GameResult extends StatelessWidget {
  final String big, caption;
  final bool record;
  final String? best;
  final List<Word> missed;
  final VoidCallback onReplay;
  const _GameResult({
    required this.big,
    required this.caption,
    required this.record,
    required this.best,
    required this.missed,
    required this.onReplay,
  });

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 22),
            decoration: BoxDecoration(color: C.accent, borderRadius: BorderRadius.circular(22)),
            child: Column(
              children: [
                if (record) ...[
                  const Pill('YENİ REKOR!', bg: C.today, fg: C.ink, size: 13),
                  const SizedBox(height: 12),
                ],
                Text(big, style: display(56, color: Colors.white)),
                const SizedBox(height: 4),
                Text(caption,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 15, color: C.onAccent, height: 1.4)),
                if (best != null) ...[
                  const SizedBox(height: 10),
                  Text(best!, style: const TextStyle(fontSize: 13.5, color: C.onAccent, fontWeight: FontWeight.w600)),
                ],
              ],
            ),
          ),
          const SizedBox(height: 16),
          PrimaryButton('Tekrar oyna', icon: Icons.replay_rounded, onPressed: onReplay),
          const SizedBox(height: 10),
          GhostButton('Oyunlara dön', icon: Icons.arrow_back_rounded, onPressed: () => Navigator.of(context).pop()),
          if (missed.isNotEmpty) ...[
            const SizedBox(height: 22),
            const Text('BİLEMEDİKLERİN', style: labelCaps),
            const SizedBox(height: 4),
            const Text('Bu kelimeler kelime kartlarına eklendi.', style: TextStyle(fontSize: 13, color: C.muted)),
            const SizedBox(height: 8),
            Panel(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              child: Column(
                children: [
                  for (var i = 0; i < missed.length; i++) ...[
                    if (i > 0) const Divider(height: 1, color: C.line),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Ar(missed[i].ar, size: 26, height: 1.6),
                          Text(missed[i].tr, style: const TextStyle(fontSize: 14.5, color: C.ink)),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ],
      );
}

void _replay(BuildContext context, Widget screen) =>
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => screen));

void _cardsRefreshLater() =>
    WidgetsBinding.instance.addPostFrameCallback((_) => AppState.I.cardsChanged());

// ====================================================================
// 1) Kelime Yarışı
// ====================================================================
class RaceGameScreen extends StatefulWidget {
  final List<Word> pool;
  const RaceGameScreen({super.key, required this.pool});

  @override
  State<RaceGameScreen> createState() => _RaceGameScreenState();
}

class _RaceGameScreenState extends State<RaceGameScreen> {
  static const int totalMs = 60000;
  final st = AppState.I;
  late final List<Word> queue = st.shuffled(widget.pool);
  int qi = 0;
  late Word word;
  List<String> opts = [];
  int ans = 0;
  int? picked;
  bool locked = false, done = false, record = false;
  int left = totalMs, score = 0, streak = 0, correct = 0, wrong = 0;
  final List<Word> missed = [];
  Timer? timer;

  int get mult => min(1 + streak ~/ 3, 5);

  @override
  void initState() {
    super.initState();
    _next();
    timer = Timer.periodic(const Duration(milliseconds: 100), (_) {
      if (done) return;
      if (left <= 100) {
        _finish();
        return;
      }
      setState(() => left -= 100);
    });
  }

  void _next() {
    word = queue[qi % queue.length];
    qi++;
    opts = [word.tr, ...st.wrongMeanings(word)]..shuffle(st.rnd);
    ans = opts.indexOf(word.tr);
    picked = null;
  }

  void _tap(int i) {
    if (locked || done) return;
    final ok = i == ans;
    setState(() {
      locked = true;
      picked = i;
      if (ok) {
        streak++;
        correct++;
        score += 10 * mult;
      } else {
        streak = 0;
        wrong++;
        if (!missed.contains(word)) missed.add(word);
      }
    });
    if (ok) {
      HapticFeedback.selectionClick();
    } else {
      HapticFeedback.mediumImpact();
      st.gameMiss(word.id);
    }
    Future.delayed(Duration(milliseconds: ok ? 280 : 900), () {
      if (!mounted || done) return;
      setState(() {
        locked = false;
        _next();
      });
    });
  }

  void _finish() {
    timer?.cancel();
    final r = st.submitGameScore('yaris', score);
    setState(() {
      left = 0;
      done = true;
      record = r;
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    _cardsRefreshLater();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Kelime Yarışı', style: TextStyle(fontSize: 16)),
          actions: [
            if (!done)
              Padding(
                padding: const EdgeInsets.only(right: 16),
                child: Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.timer_outlined, size: 18, color: left < 10000 ? C.bad : C.muted),
                      const SizedBox(width: 4),
                      Text('${(left / 1000).ceil()} sn',
                          style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                              fontFeatures: tabular,
                              color: left < 10000 ? C.bad : C.ink)),
                    ],
                  ),
                ),
              ),
          ],
        ),
        body: SafeArea(
          top: false,
          child: done
              ? _GameResult(
                  big: '$score',
                  caption: 'puan · $correct doğru, $wrong yanlış',
                  record: record,
                  best: 'Rekorun: ${st.gameBest['yaris'] ?? score} puan',
                  missed: missed,
                  onReplay: () => _replay(context, RaceGameScreen(pool: widget.pool)),
                )
              : _play(),
        ),
      );

  Widget _play() => Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(99),
              child: LinearProgressIndicator(
                value: left / totalMs,
                minHeight: 8,
                backgroundColor: C.track,
                color: left < 10000 ? C.bad : C.accent,
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Text('$score', style: display(34)),
                const SizedBox(width: 6),
                const Text('puan', style: TextStyle(fontSize: 14, color: C.muted)),
                const Spacer(),
                if (streak >= 3)
                  Pill('×$mult · $streak seri', bg: C.goldSoft, fg: C.gold, size: 13)
                else if (streak > 0)
                  Pill('$streak seri', bg: C.surface, fg: C.muted, border: C.line, size: 13),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: Panel(
                padding: const EdgeInsets.all(16),
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Ar(word.ar, size: 46, align: TextAlign.center, height: 1.7, weight: FontWeight.w700),
                      const SizedBox(height: 6),
                      posPill(word.pos),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            for (var i = 0; i < opts.length; i++) ...[
              _Choice(
                mark: picked == null
                    ? _Mark.none
                    : i == ans
                        ? _Mark.right
                        : i == picked
                            ? _Mark.wrong
                            : _Mark.none,
                onTap: () => _tap(i),
                child: Text(opts[i],
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: C.ink)),
              ),
              if (i < opts.length - 1) const SizedBox(height: 8),
            ],
          ],
        ),
      );
}

// ====================================================================
// 2) Eşleştirme
// ====================================================================
class MatchGameScreen extends StatefulWidget {
  final List<Word> pool;
  const MatchGameScreen({super.key, required this.pool});

  @override
  State<MatchGameScreen> createState() => _MatchGameScreenState();
}

class _MatchGameScreenState extends State<MatchGameScreen> {
  static const int rounds = 3, perRound = 5;
  final st = AppState.I;
  late final List<Word> picks = _pick();
  int round = 0;
  List<Word> arCol = [], trCol = [];
  final Set<String> matched = {};
  final Set<String> flash = {}; // kırmızı yanıp sönen kimlikler ("a:" / "t:" önekli)
  String? selA, selT;
  int mistakes = 0;
  final List<Word> missed = [];
  final Stopwatch sw = Stopwatch();
  Timer? ticker;
  bool done = false, record = false;
  int score = 0;

  List<Word> _pick() {
    final out = <Word>[];
    final trs = <String>{};
    for (final w in st.shuffled(widget.pool)) {
      if (w.tr.length > 30 || trs.contains(w.tr)) continue;
      trs.add(w.tr);
      out.add(w);
      if (out.length == rounds * perRound) break;
    }
    return out;
  }

  int get totalRounds => min(rounds, picks.length ~/ perRound);

  @override
  void initState() {
    super.initState();
    _setupRound();
    sw.start();
    ticker = Timer.periodic(const Duration(milliseconds: 250), (_) {
      if (!done && mounted) setState(() {});
    });
  }

  void _setupRound() {
    final ws = picks.skip(round * perRound).take(perRound).toList();
    arCol = st.shuffled(ws);
    trCol = st.shuffled(ws);
    selA = null;
    selT = null;
  }

  void _tapA(Word w) {
    if (done || matched.contains(w.id)) return;
    setState(() => selA = w.id);
    _check();
  }

  void _tapT(Word w) {
    if (done || matched.contains(w.id)) return;
    setState(() => selT = w.id);
    _check();
  }

  void _check() {
    final a = selA, t = selT;
    if (a == null || t == null) return;
    if (a == t) {
      HapticFeedback.selectionClick();
      setState(() {
        matched.add(a);
        selA = null;
        selT = null;
      });
      final roundDone = arCol.every((w) => matched.contains(w.id));
      if (roundDone) {
        Future.delayed(const Duration(milliseconds: 350), () {
          if (!mounted) return;
          if (round + 1 < totalRounds) {
            setState(() {
              round++;
              _setupRound();
            });
          } else {
            _finish();
          }
        });
      }
    } else {
      HapticFeedback.mediumImpact();
      final w = st.wordById[a];
      if (w != null && !missed.contains(w)) {
        missed.add(w);
        st.gameMiss(w.id);
      }
      setState(() {
        mistakes++;
        flash
          ..add('a:$a')
          ..add('t:$t');
        selA = null;
        selT = null;
      });
      Future.delayed(const Duration(milliseconds: 450), () {
        if (mounted) setState(() => flash.clear());
      });
    }
  }

  void _finish() {
    sw.stop();
    ticker?.cancel();
    final secs = sw.elapsed.inSeconds;
    score = max(0, totalRounds * perRound * 100 - secs * 10 - mistakes * 40);
    final r = st.submitGameScore('eslestir', score);
    setState(() {
      done = true;
      record = r;
    });
  }

  @override
  void dispose() {
    ticker?.cancel();
    _cardsRefreshLater();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final secs = sw.elapsed.inSeconds;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Eşleştirme', style: TextStyle(fontSize: 16)),
        actions: [
          if (!done)
            Padding(
              padding: const EdgeInsets.only(right: 16),
              child: Center(
                child: Text('Tur ${round + 1}/$totalRounds · $secs sn',
                    style: const TextStyle(fontSize: 14, color: C.muted, fontFeatures: tabular)),
              ),
            ),
        ],
      ),
      body: SafeArea(
        top: false,
        child: done
            ? _GameResult(
                big: '$score',
                caption: 'puan · ${sw.elapsed.inSeconds} saniye, $mistakes hata',
                record: record,
                best: 'Rekorun: ${st.gameBest['eslestir'] ?? score} puan',
                missed: missed,
                onReplay: () => _replay(context, MatchGameScreen(pool: widget.pool)),
              )
            : totalRounds == 0
                ? const Center(child: Text('Bu havuzda yeterli kelime yok.'))
                : _play(),
      ),
    );
  }

  Widget _play() => Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Bir Arapça kelimeye, sonra anlamına dokun.',
                style: TextStyle(fontSize: 14, color: C.muted)),
            const SizedBox(height: 4),
            Text('Hata: $mistakes', style: const TextStyle(fontSize: 13, color: C.faint)),
            const SizedBox(height: 12),
            Expanded(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      children: [
                        for (final w in trCol) ...[
                          _tile(
                            id: w.id,
                            key: 't:${w.id}',
                            sel: selT == w.id,
                            onTap: () => _tapT(w),
                            child: Text(w.tr,
                                textAlign: TextAlign.center,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontSize: 14.5, fontWeight: FontWeight.w600, color: C.ink, height: 1.25)),
                          ),
                          const SizedBox(height: 10),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      children: [
                        for (final w in arCol) ...[
                          _tile(
                            id: w.id,
                            key: 'a:${w.id}',
                            sel: selA == w.id,
                            onTap: () => _tapA(w),
                            child: Ar(w.ar, size: 27, align: TextAlign.center, height: 1.5),
                          ),
                          const SizedBox(height: 10),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _tile({
    required String id,
    required String key,
    required bool sel,
    required VoidCallback onTap,
    required Widget child,
  }) {
    final gone = matched.contains(id);
    final red = flash.contains(key);
    final bg = red ? C.badSoft : (sel ? C.accentSoft : C.surface);
    final bd = red ? C.bad : (sel ? C.accent : C.line);
    return AnimatedOpacity(
      opacity: gone ? 0.0 : 1.0,
      duration: const Duration(milliseconds: 250),
      child: IgnorePointer(
        ignoring: gone,
        child: SizedBox(
          height: 70,
          child: Material(
            color: gone ? C.goodSoft : bg,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
                side: BorderSide(color: gone ? C.good : bd, width: (sel || red) ? 2 : 1)),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: onTap,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Center(child: child),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ====================================================================
// 3) Hareke Avı
// ====================================================================
class HarekeGameScreen extends StatefulWidget {
  final List<Word> pool;
  const HarekeGameScreen({super.key, required this.pool});

  @override
  State<HarekeGameScreen> createState() => _HarekeGameScreenState();
}

class _HarekeGameScreenState extends State<HarekeGameScreen> {
  static const int total = 10;
  final st = AppState.I;
  late final List<Word> items = _pick();
  int index = 0, correct = 0;
  List<String> opts = [];
  int ans = 0;
  int? picked;
  bool done = false, record = false;
  final List<Word> missed = [];

  List<Word> _pick() {
    var ws = widget.pool.where((w) => st.harekeGame.containsKey(w.id)).toList();
    if (ws.length < total) ws = st.words.where((w) => st.harekeGame.containsKey(w.id)).toList();
    return st.shuffled(ws).take(total).toList();
  }

  @override
  void initState() {
    super.initState();
    if (items.isNotEmpty) _load();
  }

  void _load() {
    final w = items[index];
    opts = [w.ar, ...st.harekeGame[w.id]!]..shuffle(st.rnd);
    ans = opts.indexOf(w.ar);
    picked = null;
  }

  void _tap(int i) {
    if (picked != null) return;
    final w = items[index];
    final ok = i == ans;
    setState(() {
      picked = i;
      if (ok) {
        correct++;
      } else {
        missed.add(w);
      }
    });
    if (ok) {
      HapticFeedback.selectionClick();
    } else {
      HapticFeedback.mediumImpact();
      st.gameMiss(w.id);
    }
  }

  void _nextQ() {
    if (index + 1 >= items.length) {
      final r = st.submitGameScore('hareke', correct);
      setState(() {
        done = true;
        record = r;
      });
      return;
    }
    setState(() {
      index++;
      _load();
    });
  }

  @override
  void dispose() {
    _cardsRefreshLater();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Hareke Avı', style: TextStyle(fontSize: 16)),
          actions: [
            if (!done && items.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(right: 16),
                child: Center(
                  child: Text('${index + 1} / ${items.length}',
                      style: const TextStyle(fontSize: 14, color: C.muted, fontFeatures: tabular)),
                ),
              ),
          ],
        ),
        body: SafeArea(
          top: false,
          child: items.isEmpty
              ? const Center(child: Text('Bu havuzda uygun kelime yok.'))
              : done
                  ? _GameResult(
                      big: '$correct / ${items.length}',
                      caption: correct == items.length
                          ? 'Kusursuz! Hepsini doğru okudun.'
                          : 'doğru okunuş buldun',
                      record: record,
                      best: 'Rekorun: ${st.gameBest['hareke'] ?? correct} / 10',
                      missed: missed,
                      onReplay: () => _replay(context, HarekeGameScreen(pool: widget.pool)),
                    )
                  : _play(),
        ),
      );

  Widget _play() {
    final w = items[index];
    final answered = picked != null;
    final ok = picked == ans;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(99),
          child: LinearProgressIndicator(
            value: (index + (answered ? 1 : 0)) / items.length,
            minHeight: 6,
            backgroundColor: C.track,
            color: C.accent,
          ),
        ),
        const SizedBox(height: 14),
        Panel(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
          child: Column(
            children: [
              const Text('DOĞRU OKUNUŞ HANGİSİ?', style: labelCaps),
              const SizedBox(height: 8),
              Text(w.tr, textAlign: TextAlign.center, style: display(21)),
              const SizedBox(height: 4),
              Ar(stripHarakat(w.ar), size: 48, align: TextAlign.center, height: 1.6, weight: FontWeight.w700),
            ],
          ),
        ),
        const SizedBox(height: 12),
        for (var i = 0; i < opts.length; i++) ...[
          _Choice(
            minHeight: 66,
            mark: !answered
                ? _Mark.none
                : i == ans
                    ? _Mark.right
                    : i == picked
                        ? _Mark.wrong
                        : _Mark.none,
            onTap: answered ? null : () => _tap(i),
            child: Ar(opts[i], size: 32, align: TextAlign.center, height: 1.6),
          ),
          const SizedBox(height: 8),
        ],
        if (answered) ...[
          const SizedBox(height: 6),
          Panel(
            color: ok ? C.goodSoft : C.badSoft,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(ok ? Icons.check_circle_rounded : Icons.cancel_rounded,
                        color: ok ? C.good : C.bad, size: 22),
                    const SizedBox(width: 8),
                    Text(ok ? 'Doğru' : 'Yanlış',
                        style: TextStyle(
                            fontSize: 17, fontWeight: FontWeight.w800, color: ok ? C.good : C.bad)),
                  ],
                ),
                if (w.root.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text('Kök:', style: const TextStyle(fontSize: 13.5, color: C.muted)),
                  Ar(w.rootSpaced, size: 24, height: 1.5),
                ],
                if (w.ex.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  const Text('Örnek cümle:', style: TextStyle(fontSize: 13.5, color: C.muted)),
                  Ar(w.ex, size: 23, height: 1.7),
                  Text(w.ext, style: const TextStyle(fontSize: 14, color: C.ink, height: 1.4)),
                ],
              ],
            ),
          ),
          const SizedBox(height: 14),
          PrimaryButton(index + 1 >= items.length ? 'Sonucu gör' : 'Sonraki',
              icon: Icons.arrow_forward_rounded, onPressed: _nextQ),
        ],
      ],
    );
  }
}
