"""Harekeli Arapçadan Türkçe okunuş (ör. كِتَابٌ → kitâbun, اَلشَّمْسُ → eş-şemsu).

Sıfırdan Arapça bölümündeki örneklerin altına yazılır. Kurallar:
- üstün ince harfte 'e', kalın harfte (خ ص ض ط ظ غ ق ع ح) 'a'; esre 'i'; ötre 'u'
- uzatma: â î û; tenvin: -un -in -en/-an
- kelime başındaki hemze ve ayn yazılmaz, ortadakiler ' ve ‘ ile gösterilir
- şemsî harflerde lam okunmaz (eş-şems), sesli harfle biten kelimeden sonra 'l- (fi'l-beyt)
"""
import re

FATHA, KASRA, DAMMA, SUKUN, SHADDA = 'َ', 'ِ', 'ُ', 'ْ', 'ّ'
TAN_F, TAN_K, TAN_D, DAGGER = 'ً', 'ٍ', 'ٌ', 'ٰ'
HARAKAT = {FATHA, KASRA, DAMMA, SUKUN, SHADDA, TAN_F, TAN_K, TAN_D, DAGGER}
CONS = {
    'ب': 'b', 'ت': 't', 'ث': 's', 'ج': 'c', 'ح': 'h', 'خ': 'h', 'د': 'd', 'ذ': 'z', 'ر': 'r', 'ز': 'z',
    'س': 's', 'ش': 'ş', 'ص': 's', 'ض': 'd', 'ط': 't', 'ظ': 'z', 'ع': '‘', 'غ': 'g', 'ف': 'f', 'ق': 'k',
    'ك': 'k', 'ل': 'l', 'م': 'm', 'ن': 'n', 'ه': 'h', 'و': 'v', 'ي': 'y', 'ة': 't', 'ء': "'", 'أ': "'",
    'إ': "'", 'ؤ': "'", 'ئ': "'", 'پ': 'p', 'چ': 'ç', 'گ': 'g', 'ڤ': 'v',
}
THICK = set('خصضطظغقعح')
SUN = set('تثدذرزسشصضطظلن')
HAMZA = set('ءأإؤئ')


def _word(w, prev_vowel):
    """Tek kelime. prev_vowel: önceki kelime sesliyle mi bitti (vasl için)."""
    chars = list(w)
    # harf + harekeler
    units = []
    for c in chars:
        if c in HARAKAT and units:
            units[-1][1].append(c)
        elif c == 'ـ':
            continue
        else:
            units.append([c, []])
    out = []
    i = 0
    # lâm-ı tarif
    if len(units) >= 2 and units[0][0] in 'اٱ' and units[1][0] == 'ل' and (SUKUN in units[1][1] or not units[1][1]) \
            and len(units) > 2:
        nxt = units[2][0]
        if nxt in SUN and SHADDA in units[2][1]:
            art = CONS[nxt]
        else:
            art = 'l'
        out.append(("'" if prev_vowel else 'e') + art + '-')
        i = 2
        sun_art = art != 'l'
    elif units and units[0][0] in 'اٱ' and not ({FATHA, KASRA, DAMMA} & set(units[0][1])) and prev_vowel:
        i = 1  # hemze-i vasl: okunmaz
    elif units and units[0][0] == 'ا' and len(units) > 1:
        # hemze-i vasl (اِبْنٌ, اِسْمٌ): kelime başında esre/üstün
        v = units[0][1]
        if prev_vowel:
            i = 1
        else:
            out.append('i' if KASRA in v else 'u' if DAMMA in v else 'e')
            i = 1
    n = len(units)
    sun_art = locals().get('sun_art', False)
    while i < n:
        c, h = units[i]
        hs = set(h)
        nxt = units[i + 1] if i + 1 < n else None
        if c == 'آ':
            out.append('â' if i == 0 or (i == 2 and sun_art is not None and out and out[-1].endswith('-')) else "'â")
            i += 1
            continue
        if c in 'اى' and not (hs & {FATHA, KASRA, DAMMA, TAN_F}):
            # uzatma ya da tenvin elifi
            if out and out[-1].endswith(('e', 'a')):
                out[-1] = out[-1][:-1] + 'â'
            elif i == 0:
                out.append('e')
            i += 1
            continue
        if c == 'ا' and TAN_F in hs:
            i += 1
            continue
        if c not in CONS and c not in 'ا':
            out.append(c)
            i += 1
            continue
        # sessiz
        if c == 'ة' and not (hs & {FATHA, KASRA, DAMMA, TAN_F, TAN_K, TAN_D}):
            out.append('')  # durakta okunmaz; önceki üstün yeter
            i += 1
            continue
        if c == 'ا':
            cons = ''
        elif (c in HAMZA or c == 'ع') and i == 0:
            cons = ''
        else:
            cons = CONS[c]
        if SHADDA in hs and cons and not (sun_art and i == 2):
            cons = cons * 2
        if c == 'ء' and out and out[-1].endswith('â'):
            cons = ''
        thick = c in THICK
        # sesli
        vow = ''
        if FATHA in hs:
            vow = 'a' if thick or (nxt and nxt[0] in THICK and SUKUN in nxt[1]) else 'e'
        elif KASRA in hs:
            vow = 'i'
        elif DAMMA in hs:
            vow = 'u'
        elif TAN_F in hs:
            vow = 'an' if thick else 'en'
        elif TAN_K in hs:
            vow = 'in'
        elif TAN_D in hs:
            vow = 'un'
        if DAGGER in hs:
            vow = 'â'
        # uzunluk ve iki ünlü
        if nxt and vow in ('i', 'u') and nxt[0] in 'يو' and not (set(nxt[1]) & {FATHA, KASRA, DAMMA, SHADDA, TAN_F, TAN_K, TAN_D}):
            if (vow == 'i' and nxt[0] == 'ي') or (vow == 'u' and nxt[0] == 'و'):
                vow = 'î' if vow == 'i' else 'û'
                i += 1
        if nxt and vow in ('e', 'a') and nxt[0] in 'يو' and SUKUN in set(nxt[1]):
            vow += 'y' if nxt[0] == 'ي' else 'v'
            i += 1
        out.append(cons + vow)
        i += 1
    s = ''.join(out)
    s = s.replace('‘‘', '‘')
    return s


def okunus(text):
    toks = re.split(r'(\s+|[·،.؟!,:;()←→/«»"“”-])', text)
    res = []
    prev_vowel = False
    for t in toks:
        if not t:
            continue
        if re.fullmatch(r'\s+', t):
            res.append(' ')
            continue
        if not re.search('[ء-ي]', t):
            res.append({'؟': '?', '،': ',', '←': '→'}.get(t, t))
            if t.strip():
                prev_vowel = False
            continue
        w = _word(t, prev_vowel)
        res.append(w)
        prev_vowel = bool(w) and w[-1] in 'aeiuâîû'
    s = ''.join(res)
    s = re.sub(r"\s+'", " '", s)
    s = re.sub(r"(\w) '(\w)-", r"\1'\2-", s)  # fi 'l- → fi'l-
    s = re.sub(r"[âîû](?='\w+-)", lambda m: {'â': 'e', 'î': 'i', 'û': 'u'}[m.group()], s)  # ilâ → ile'l-
    return re.sub(r'\s+', ' ', s).strip()


if __name__ == '__main__':
    import baslangic
    bad = 0
    for k, pairs in baslangic.READ_WORDS.items():
        for a, t in pairs:
            o = okunus(a)
            if o != t:
                bad += 1
                print(a, t, '→', o)
    print('fark', bad)
