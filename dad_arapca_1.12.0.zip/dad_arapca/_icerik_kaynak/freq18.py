"""YDS Arapça sıklık verisi (2018–2026): ÖSYM'nin yayımladığı 13 sınav kitapçığından Dâd'ın kendi sayımı.

sik_ids.json: {kelime_id: geçtiği sınav sayısı}  (mevcut kelimeler; id'ler sabit)
sik_ar.json : {normalize_arapça: sayı}           (1.12.0'da eklenen yeni kelimeler)
tag(words): her kelimeye 's' (13 sınavın kaçında geçtiği) yazar.
"""
import json, re
from pathlib import Path
HERE = Path(__file__).parent
MARK = set('ًٌٍَُِّْٰـ')


def norm(s):
    s = ''.join(c for c in s if c not in MARK).split('/')[0].strip()
    s = re.sub('^ال(?=..)', '', s)
    for a, b in (('أ', 'ا'), ('إ', 'ا'), ('آ', 'ا'), ('ى', 'ي'), ('ة', 'ه')):
        s = s.replace(a, b)
    return s.strip()


def _j(n):
    p = HERE / n
    return json.loads(p.read_text()) if p.exists() else {}


def tag(words):
    ids, ar = _j('sik_ids.json'), _j('sik_ar.json')
    n = 0
    for w in words:
        s = ids.get(w['id']) or ar.get(norm(w['ar']))
        if s:
            w['s'] = s
            n += 1
    return n
