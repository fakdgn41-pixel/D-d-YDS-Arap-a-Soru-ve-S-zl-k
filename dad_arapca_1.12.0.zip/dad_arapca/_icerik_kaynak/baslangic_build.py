import re
"""Sıfırdan Arapça üreticisi: dersler, harf tablosu ve sorular."""
import random

TATWEEL = 'ـ'
SIMILAR = ['بتثني', 'جحخ', 'دذ', 'رز', 'سش', 'صض', 'طظ', 'عغ', 'فق', 'كل', 'هم', 'او']
UNITS = [
    ('u1', 'Harfler', 'Arap alfabesinin 28 harfi ve kelime içindeki şekilleri.'),
    ('u2', 'Okuma', 'Harekeler, cezm, uzatma, şedde, tenvin ve el takısı.'),
    ('u3', 'İlk kelimeler', 'Günlük hayatın temel kelimeleri, konu konu.'),
    ('u4', 'Temel dilbilgisi', 'Zamirlerden çoğullara, cümle kurmanın temelleri.'),
]
VOWELS = ['a', 'e', 'i', 'u', 'ı']
LONG = {'â': 'a', 'î': 'i', 'û': 'u'}


def forms(ch, joins):
    if ch == 'ا' or not joins:
        return [ch, ch, TATWEEL + ch, TATWEEL + ch]
    return [ch, ch + TATWEEL, TATWEEL + ch + TATWEEL, TATWEEL + ch]


def read_variants(t, rnd):
    out = set()
    chars = list(t)
    for i, c in enumerate(chars):
        if c in 'aeiuı':
            for v in VOWELS:
                if v != c:
                    out.add(''.join(chars[:i] + [v] + chars[i + 1:]))
        if c in LONG:
            out.add(''.join(chars[:i] + [LONG[c]] + chars[i + 1:]))
        if c in 'aeiu' and i > 0:
            lv = {'a': 'â', 'e': 'â', 'i': 'î', 'u': 'û'}[c]
            out.add(''.join(chars[:i] + [lv] + chars[i + 1:]))
    for i in range(len(t) - 1):
        if t[i] == t[i + 1] and t[i].isalpha() and t[i] not in 'aeiuı':
            out.add(t[:i] + t[i + 1:])
    for a, b in (('eş-ş', 'el-ş'), ('es-s', 'el-s'), ('en-n', 'el-n'), ('ed-d', 'el-d'), ('el-k', 'ek-k'), ('el-b', 'eb-b'), ('el-v', 'ev-v')):
        if t.startswith(a):
            out.add(b + t[len(a):])
    for end, alt in (('un', ['u', 'in', 'en']), ('in', ['i', 'un', 'en']), ('en', ['e', 'un', 'in'])):
        if t.endswith(end):
            for x in alt:
                out.add(t[:-len(end)] + x)
    out.discard(t)
    out = sorted(out)
    rnd.shuffle(out)
    return out


from okunus import okunus


def _blk(b, uid):
    """Blok sözlüğü; Arapça örneklere Türkçe okunuş ('o') eklenir (okuma dersleri zaten okunuşla yazıldı)."""
    if b[0] != 'a':
        return {b[0]: b[1]}
    d = {'a': b[1], 'tr': b[2]}
    if uid != 'u2' and '   ' not in b[1] and re.search('[\u064b-\u0652]', b[1]):
        d['o'] = okunus(b[1])
    return d


def build(mod, q, err):
    letters = mod.LETTERS
    by_ch = {l['ch']: l for l in letters}
    raw = []  # (lessonId, raw q)
    units = {u[0]: dict(id=u[0], title=u[1], desc=u[2], lessons=[]) for u in UNITS}

    def opts(correct, pool, rnd, n=5):
        out = [correct]
        for x in pool:
            if x not in out:
                out.append(x)
            if len(out) == n:
                break
        return out if len(out) == n else None

    # ---- Harfler
    for gi, (lid, title, chars, intro) in enumerate(mod.LETTER_GROUPS, 1):
        rnd = random.Random(gi * 31)
        blocks = [('h', 'Harfler ve şekilleri'),
                  ('t', 'Her satırda harfin tek başına, kelime başında, ortasında ve sonundaki şekli yer alır.')]
        group = [by_ch[c] for c in chars.split()]
        for l in group:
            f = forms(l['ch'], l['joins'])
            blocks.append(('a', '   '.join(f), f'{l["name"]} · {l["tr"]}. {l["note"]}'))
            blocks.append(('a', l['ex'], f'Örnek: {l["ext"]}'))
        blocks.append(('h', 'Ayırt etme ipucu'))
        blocks.append(('t', intro))
        if lid == 'h3':
            blocks.append(('b', 'Kendinden sonrakine bağlanmayan harfler altı tanedir: elif, dal, zel, ra, ze, vav.'))
        if lid == 'h7':
            blocks += [('h', 'Hemze ve yuvarlak te'),
                       ('t', 'Hemze kısa bir kesme sesidir; elif, vav ya da ye üzerinde ya da tek başına yazılır.'),
                       ('a', 'أَ   إِ   ؤ   ئ   ء', 'Hemzenin yazılış biçimleri'),
                       ('t', 'Yuvarlak te dişil kelimelerin sonunda gelir; durakta “h” gibi okunur.'),
                       ('a', 'مَدْرَسَة', 'okul')]
        units['u1']['lessons'].append(dict(id=lid, title=title, intro='Bu derste şu harfleri öğreneceksin.', blocks=blocks, chars=chars))
        names = [l['name'] for l in letters]
        for l in group:
            sim = [by_ch[c]['name'] for s in SIMILAR if l['ch'] in s for c in s if c != l['ch'] and c in by_ch]
            rest = [n for n in names if n != l['name'] and n not in sim]
            rnd.shuffle(rest)
            o = opts(l['name'], sim + rest, rnd)
            raw.append((lid, q(None, o, [f'Bu harf {l["name"]} harfidir; {l["tr"]} sesini verir.'], kind='Başlangıç · Harfler',
                               prompt='Bu harfin adı nedir?', lines=[l['ch']], optAr=False)))
            simc = [c for s in SIMILAR if l['ch'] in s for c in s if c != l['ch'] and c in by_ch]
            restc = [x['ch'] for x in letters if x['ch'] != l['ch'] and x['ch'] not in simc]
            rnd.shuffle(restc)
            o = opts(l['ch'], simc + restc, rnd)
            raw.append((lid, q(None, o, [f'{l["name"]} harfi:', '@' + l['ch']], kind='Başlangıç · Harfler',
                               prompt=f'“{l["name"]}” harfi hangisidir?', lines=[], optAr=True)))
            f = forms(l['ch'], l['joins'])
            pick = f[2] if l['joins'] else f[3]
            pool = []
            for c in simc + restc:
                ff = forms(c, by_ch[c]['joins'])
                pool.append(by_ch[c]['name'])
            o = opts(l['name'], pool, rnd)
            raw.append((lid, q(None, o, [f'Bu, {l["name"]} harfinin kelime içindeki şeklidir:', '@' + pick],
                               kind='Başlangıç · Harfler', prompt='Kelime içindeki bu şekil hangi harfe aittir?',
                               lines=[pick], optAr=False)))

    # ---- Okuma
    for li, (lid, title, intro, blocks) in enumerate(mod.READ_LESSONS, 1):
        rnd = random.Random(li * 97)
        units['u2']['lessons'].append(dict(id=lid, title=title, intro=intro, blocks=blocks))
        for ar, tr in mod.READ_WORDS[lid]:
            v = read_variants(tr, rnd)
            o = opts(tr, v, rnd)
            if not o:
                err(lid, f'okuma çeldiricisi yetmedi: {tr}')
                continue
            raw.append((lid, q(None, o, [f'Doğru okunuş: {tr}.'], kind='Başlangıç · Okuma',
                               prompt='Kelime nasıl okunur?', lines=[ar], optAr=False)))

    # ---- Kelimeler
    for li, (lid, title, intro, words) in enumerate(mod.VOCAB, 1):
        rnd = random.Random(li * 131)
        blocks = [('h', 'Kelimeler')] + [('a', a, t) for a, t in words]
        units['u3']['lessons'].append(dict(id=lid, title=title, intro=intro, blocks=blocks))
        for wi, (a, t) in enumerate(words):
            others = [x for x in words if x[0] != a]
            rnd.shuffle(others)
            if wi % 2 == 0:
                o = opts(t, [x[1] for x in others], rnd)
                raw.append((lid, q(None, o, [f'Okunuşu: {okunus(a)}. Anlamı: {t}.'], [(a, t)], kind='Başlangıç · Kelime',
                                   prompt='Kelimenin anlamı nedir?', lines=[a], optAr=False)))
            else:
                o = opts(a, [x[0] for x in others], rnd)
                raw.append((lid, q(None, o, [f'“{t}” kelimesinin Arapçası:', '@' + a, f'Okunuşu: {okunus(a)}.'], [(a, t)], kind='Başlangıç · Kelime',
                                   prompt=f'“{t}” kelimesinin Arapçası hangisidir?', lines=[], optAr=True)))

    # ---- Dilbilgisi
    for lid, title, intro, blocks, qs in mod.GRAMMAR:
        units['u4']['lessons'].append(dict(id=lid, title=title, intro=intro, blocks=blocks))
        for s in qs:
            lines = ([s['stem']] if s['stem'] else []) + ['#' + s['tr']]
            raw.append((lid, q(None, s['opts'], s['exp'], kind='Başlangıç · Dilbilgisi',
                               prompt='Doğru seçenek hangisidir?', lines=lines)))

    data = dict(
        letters=[dict(l, forms=forms(l['ch'], l['joins'])) for l in letters],
        units=[dict(u, lessons=[dict(id=x['id'], title=x['title'], intro=x['intro'],
                                     blocks=[_blk(b, uid) for b in x['blocks']])
                                for x in u['lessons']]) for uid, u in units.items()],
    )
    return raw, data
