import 'package:flutter/material.dart';

import 'models.dart';
import 'state.dart';
import 'theme.dart';

/// Arapça metin: her zaman kendi satırında, sağdan sola.
class Ar extends StatelessWidget {
  final String text;
  final double size;
  final Color color;
  final TextAlign align;
  final double height;
  final FontWeight weight;
  final double? wordSpacing;

  const Ar(
    this.text, {
    super.key,
    this.size = 25,
    this.color = C.ink,
    this.align = TextAlign.right,
    this.height = 1.8,
    this.weight = FontWeight.w400,
    this.wordSpacing,
  });

  @override
  Widget build(BuildContext context) => SizedBox(
        width: align == TextAlign.center ? null : double.infinity,
        child: Text(
          text,
          textDirection: TextDirection.rtl,
          textAlign: align,
          locale: const Locale('ar'),
          style: TextStyle(
            fontFamily: kArabic, letterSpacing: 0,
            fontSize: size,
            height: height,
            color: color,
            fontWeight: weight,
            wordSpacing: wordSpacing,
          ),
        ),
      );
}

/// Soru kökündeki Arapça satır: boşluk çizgisi ve altı çizili hedef kelime ile.
class ArStem extends StatelessWidget {
  final String text;
  final String? target;
  final double size;
  const ArStem(this.text, {super.key, this.target, this.size = 26});

  @override
  Widget build(BuildContext context) {
    final base = TextStyle(fontFamily: kArabic, letterSpacing: 0, fontSize: size, height: 2.0, color: C.ink);
    final spans = <InlineSpan>[];
    final parts = text.split(kBlank);
    for (var i = 0; i < parts.length; i++) {
      spans.addAll(_withTarget(parts[i], base));
      if (i < parts.length - 1) {
        spans.add(WidgetSpan(
          alignment: PlaceholderAlignment.middle,
          child: Container(
            width: size * 3,
            height: size * 0.9,
            margin: const EdgeInsets.symmetric(horizontal: 4),
            decoration: const BoxDecoration(
              border: Border(bottom: BorderSide(color: C.goldLine, width: 2.5)),
            ),
          ),
        ));
      }
    }
    return SizedBox(
      width: double.infinity,
      child: Text.rich(
        TextSpan(children: spans, style: base),
        textDirection: TextDirection.rtl,
        textAlign: TextAlign.right,
        locale: const Locale('ar'),
      ),
    );
  }

  List<InlineSpan> _withTarget(String s, TextStyle base) {
    final t = target;
    if (t == null || !s.contains(t)) return [TextSpan(text: s)];
    final i = s.indexOf(t);
    return [
      TextSpan(text: s.substring(0, i)),
      TextSpan(
        text: t,
        style: base.copyWith(
          decoration: TextDecoration.underline,
          decorationColor: C.goldLine,
          decorationThickness: 2,
        ),
      ),
      TextSpan(text: s.substring(i + t.length)),
    ];
  }
}

class Pill extends StatelessWidget {
  final String text;
  final Color bg, fg;
  final Color? border;
  final double size;
  const Pill(this.text,
      {super.key, this.bg = C.accentSoft, this.fg = C.accentDark, this.border, this.size = 12});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(99),
          border: border == null ? null : Border.all(color: border!),
        ),
        child: Text(text,
            style: TextStyle(
                fontSize: size, fontWeight: FontWeight.w700, color: fg, fontFeatures: tabular)),
      );
}

/// Skor rozetinin renkleri: yüksek yeşil, orta nötr, düşük kırmızı.
Pill scorePill(int? pct) {
  if (pct == null) return const Pill('Yeni', bg: C.surface, fg: C.muted, border: C.line);
  if (pct >= 75) return Pill('%$pct', bg: C.goodSoft, fg: C.good);
  if (pct >= 50) return Pill('%$pct', bg: C.sunk, fg: C.ink);
  return Pill('%$pct', bg: C.badSoft, fg: C.bad);
}

Pill posPill(String pos) {
  switch (pos) {
    case 'f':
      return const Pill('FİİL', bg: C.accentSoft, fg: C.accentDark, size: 11);
    case 'i':
      return const Pill('İSİM', bg: C.goldSoft, fg: Color(0xFF7A4C0B), size: 11);
    case 's':
      return const Pill('SIFAT', bg: Color(0xFFF5E4EE), fg: Color(0xFF7A2D58), size: 11);
    case 'h':
      return const Pill('HARF-İ CER', bg: Color(0xFFE3F0E6), fg: Color(0xFF2F6B3D), size: 11);
    default:
      return const Pill('EDAT/ZARF', bg: Color(0xFFE6E7F5), fg: Color(0xFF3B3F7A), size: 11);
  }
}

/// Kelimenin YDS'de çıktığını gösteren etiket.
Pill ydsPill(List<String> years, {bool long = false}) => Pill(
      long ? 'YDS ${years.join(' · ')}' : 'YDS',
      bg: const Color(0xFFFFF1D6),
      fg: const Color(0xFF8A5A00),
      size: 11,
    );

/// 2018–2026 sıklık rozeti: kelimenin incelenen 13 YDS'den kaçında geçtiği.
Pill sikPill(int s, {bool long = false}) => Pill(
      long ? '2018–26: $s/13 sınav' : '$s/13',
      bg: const Color(0xFFFCE4DC),
      fg: const Color(0xFF9A3412),
      size: 11,
    );

class Panel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final Color color;
  final double radius;
  const Panel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.color = C.surface,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) => Container(
        padding: padding,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(radius),
          border: Border.all(color: C.line),
        ),
        child: child,
      );
}

class PrimaryButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  const PrimaryButton(this.label, {super.key, this.icon, this.onPressed});

  @override
  Widget build(BuildContext context) => SizedBox(
        height: 52,
        child: FilledButton(
          onPressed: onPressed,
          style: FilledButton.styleFrom(
            backgroundColor: C.accent,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            textStyle: const TextStyle(fontFamily: kBody, fontSize: 16, fontWeight: FontWeight.w700),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[Icon(icon, size: 20), const SizedBox(width: 8)],
              Flexible(child: Text(label, overflow: TextOverflow.ellipsis)),
            ],
          ),
        ),
      );
}

class GhostButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final bool iconAfter;
  final VoidCallback? onPressed;
  const GhostButton(this.label, {super.key, this.icon, this.iconAfter = false, this.onPressed});

  @override
  Widget build(BuildContext context) {
    final ic = icon == null ? null : Icon(icon, size: 19);
    return SizedBox(
      height: 52,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          backgroundColor: C.surface,
          foregroundColor: C.ink,
          side: const BorderSide(color: C.line),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: const TextStyle(fontFamily: kBody, fontSize: 15, fontWeight: FontWeight.w600),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (ic != null && !iconAfter) ...[ic, const SizedBox(width: 8)],
            Flexible(child: Text(label, overflow: TextOverflow.ellipsis)),
            if (ic != null && iconAfter) ...[const SizedBox(width: 8), ic],
          ],
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const SectionTitle(this.text, {super.key, this.trailing});

  @override
  Widget build(BuildContext context) => Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(child: Text(text, style: display(18))),
          if (trailing != null) trailing!,
        ],
      );
}

/// Kaçırılan soru kartı (sonuç ve günlük ekranlarında).
class MissedCard extends StatelessWidget {
  final Missed m;
  final String? prefix;
  const MissedCard(this.m, {super.key, this.prefix});

  @override
  Widget build(BuildContext context) => Panel(
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
        radius: 14,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text((prefix == null ? m.kind : '$prefix · ${m.kind}').toUpperCase(),
                style: labelCaps.copyWith(fontSize: 11)),
            const SizedBox(height: 2),
            if (m.stemAr)
              Ar(m.stem, size: 21)
            else
              Text(m.stem, style: const TextStyle(fontSize: 15, height: 1.45)),
            const SizedBox(height: 4),
            const Text('Doğru cevap',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: C.good)),
            if (m.answerAr)
              Ar(m.answer, size: 21, color: C.good)
            else
              Text(m.answer, style: const TextStyle(fontSize: 15, color: C.good, height: 1.45)),
          ],
        ),
      );
}


/// Harekeleri göster/gizle düğmesi (bütün Arapça metinler için ortak ayar).
class HarakatToggle extends StatelessWidget {
  const HarakatToggle({super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final on = AppState.I.showHarakat;
          return Tooltip(
            message: on ? 'Harekeleri gizle' : 'Harekeleri göster',
            child: InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: AppState.I.toggleHarakat,
              child: Container(
                padding: const EdgeInsets.fromLTRB(10, 2, 12, 2),
                decoration: BoxDecoration(
                  color: on ? C.accent : C.surface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: on ? C.accent : C.line),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('حَـ',
                        textDirection: TextDirection.rtl,
                        style: TextStyle(fontFamily: kArabic, letterSpacing: 0, fontSize: 20, height: 1.5, color: on ? Colors.white : C.ink)),
                    const SizedBox(width: 6),
                    Text('Hareke',
                        style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: on ? Colors.white : C.ink)),
                  ],
                ),
              ),
            ),
          );
        },
      );
}
