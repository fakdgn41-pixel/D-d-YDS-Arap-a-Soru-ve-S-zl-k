"""Derleme sırasında Arapça sesleri üretir (edge-tts). Başarısız olursa uygulama sessiz çalışır.
Girdi: assets/data/ses.json  ->  Çıktı: assets/audio/<anahtar>.mp3 ve assets/audio/index.json"""
import asyncio, json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'assets', 'data', 'ses.json')
OUT = os.path.join(HERE, 'assets', 'audio')
VOICE = os.environ.get('SES', 'ar-SA-HamedNeural')

async def main():
    import edge_tts
    items = json.load(open(SRC, encoding='utf-8'))
    os.makedirs(OUT, exist_ok=True)
    done = {}
    sem = asyncio.Semaphore(6)

    async def one(it):
        path = os.path.join(OUT, it['k'] + '.mp3')
        async with sem:
            for attempt in range(3):
                try:
                    await edge_tts.Communicate(it['t'], VOICE, rate=it.get('r', '-10%')).save(path)
                    if os.path.getsize(path) > 500:
                        done[it['s']] = it['k']; return
                except Exception as e:
                    print('hata', it['k'], e)
                    await asyncio.sleep(2 + attempt * 3)
            if os.path.exists(path): os.remove(path)

    await asyncio.gather(*(one(it) for it in items))
    json.dump(done, open(os.path.join(OUT, 'index.json'), 'w', encoding='utf-8'), ensure_ascii=False)
    print(f'ses: {len(done)}/{len(items)} dosya üretildi')

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except Exception as e:
        print('ses üretilemedi:', e)
        sys.exit(0)
