import 'package:flutter/material.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'quiz.dart';

/// Güncel okuma metinleri: konuya göre liste.
class ReadingListScreen extends StatefulWidget {
  const ReadingListScreen({super.key});

  @override
  State<ReadingListScreen> createState() => _ReadingListScreenState();
}

class _ReadingListScreenState extends State<ReadingListScreen> {
  String? topic; // null: hepsi

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          final list = st.readings.where((p) => topic == null || p.topic == topic).toList();
          return Scaffold(
            appBar: AppBar(title: const Text('Güncel okuma metinleri')),
            body: ListView(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              children: [
                const Text(
                  'Farklı konularda YDS üslubunda metinler. Her metinde çeviri, önemli kelimeler ve dört soru var.',
                  style: TextStyle(fontSize: 14.5, color: C.muted, height: 1.5),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  height: 46,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      _chip(null, 'Tümü'),
                      for (final e in kReadTopics.entries) _chip(e.key, e.value),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                for (final p in list) ...[
                  _ReadingTile(passage: p),
                  const SizedBox(height: 8),
                ],
              ],
            ),
          );
        },
      );

  Widget _chip(String? key, String label) {
    final sel = topic == key;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label, style: TextStyle(fontWeight: FontWeight.w600, color: sel ? Colors.white : C.ink)),
        selected: sel,
        showCheckmark: false,
        selectedColor: C.ink,
        backgroundColor: C.surface,
        side: BorderSide(color: sel ? C.ink : C.line),
        onSelected: (_) => setState(() => topic = key),
      ),
    );
  }
}

class _ReadingTile extends StatelessWidget {
  final Passage passage;
  const _ReadingTile({required this.passage});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I.readingStats(passage.id);
    final first = passage.text.split('،').first.split('.').first;
    return Material(
      color: C.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: C.line)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => ReadingScreen(passage: passage))),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 12, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Pill((kReadTopics[passage.topic] ?? '').toUpperCase(), size: 11),
                  const Spacer(),
                  if (s.done == 0)
                    const Pill('Yeni', bg: C.surface, fg: C.faint, border: C.line, size: 11)
                  else
                    Pill('${s.right}/${s.total} doğru', bg: C.goldSoft, fg: C.gold, size: 11),
                ],
              ),
              const SizedBox(height: 8),
              Text(passage.title ?? '', style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w700)),
              Ar('$first …', size: 19, height: 1.7, color: C.muted),
            ],
          ),
        ),
      ),
    );
  }
}

/// Tek metin: Arapça metin, çeviri, önemli kelimeler ve sorular.
class ReadingScreen extends StatefulWidget {
  final Passage passage;
  const ReadingScreen({super.key, required this.passage});

  @override
  State<ReadingScreen> createState() => _ReadingScreenState();
}

class _ReadingScreenState extends State<ReadingScreen> {
  bool showTr = false;

  @override
  Widget build(BuildContext context) {
    final p = widget.passage;
    final st = AppState.I;
    final qs = st.passageQuestions(p.id);
    return Scaffold(
      appBar: AppBar(title: Text(kReadTopics[p.topic] ?? 'Okuma', style: const TextStyle(fontSize: 15, color: C.muted))),
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                children: [
                  Text(p.title ?? '', style: display(24)),
                  const SizedBox(height: 12),
                  Panel(
                    radius: 18,
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                    child: Ar(p.text, size: 22, height: 1.95),
                  ),
                  const SizedBox(height: 10),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton.icon(
                      onPressed: () => setState(() => showTr = !showTr),
                      icon: Icon(showTr ? Icons.visibility_off_outlined : Icons.translate_rounded, size: 19),
                      label: Text(showTr ? 'Çeviriyi gizle' : 'Çeviriyi göster'),
                    ),
                  ),
                  if (showTr && p.tr != null)
                    Panel(
                      radius: 18,
                      color: C.sunk,
                      child: Text(p.tr!, style: const TextStyle(fontSize: 15.5, height: 1.55)),
                    ),
                  if (p.gloss.isNotEmpty) ...[
                    const SizedBox(height: 18),
                    const Text('ÖNEMLİ KELİMELER', style: labelCaps),
                    const SizedBox(height: 8),
                    Container(
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                        color: C.surface,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: C.line),
                      ),
                      child: Column(
                        children: [
                          for (var i = 0; i < p.gloss.length; i++)
                            Container(
                              decoration: BoxDecoration(
                                  border: i == p.gloss.length - 1
                                      ? null
                                      : const Border(bottom: BorderSide(color: C.sunk))),
                              padding: const EdgeInsets.fromLTRB(16, 4, 16, 6),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Text(p.gloss[i][1],
                                        style: const TextStyle(fontSize: 14.5, color: C.muted)),
                                  ),
                                  const SizedBox(width: 12),
                                  Flexible(child: Ar(p.gloss[i][0], size: 21, height: 1.7)),
                                ],
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
            if (qs.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 14),
                child: SizedBox(
                  width: double.infinity,
                  child: PrimaryButton(
                    'Soruları çöz (${qs.length})',
                    icon: Icons.play_arrow_rounded,
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => QuizScreen(
                          setKey: 'okuma', name: p.title ?? 'Okuma', questions: qs.map(st.prep).toList()),
                    )),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
