import 'package:flutter/material.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'quiz.dart';

/// Sıfırdan Arapça: üniteler ve dersler, adım adım.
class BaslangicScreen extends StatelessWidget {
  const BaslangicScreen({super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          final done = st.lessonsDone, total = st.lessonsTotal;
          final next = st.nextLesson;
          return Scaffold(
            appBar: AppBar(title: const Text('Sıfırdan Arapça')),
            body: ListView(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 24 + MediaQuery.of(context).padding.bottom),
              children: [
                const Text(
                  'Hiç bilmeyenler için: önce harfler, sonra okuma, ilk kelimeler ve temel dilbilgisi. '
                  'Her dersi oku, alıştırmayı çöz. Yüzde 70 ve üstü alınca ders tamamlanır.',
                  style: TextStyle(fontSize: 14.5, color: C.muted, height: 1.5),
                ),
                const SizedBox(height: 14),
                Panel(
                  color: C.accentSoft,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text('$done / $total ders tamamlandı',
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: C.accentDark)),
                      const SizedBox(height: 8),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: LinearProgressIndicator(
                          value: total == 0 ? 0 : done / total,
                          minHeight: 8,
                          backgroundColor: C.surface,
                          color: C.accent,
                        ),
                      ),
                      if (next != null) ...[
                        const SizedBox(height: 12),
                        PrimaryButton(
                          'Sıradaki ders: ${next.title}',
                          icon: Icons.arrow_forward_rounded,
                          onPressed: () => Navigator.of(context)
                              .push(MaterialPageRoute(builder: (_) => LessonScreen(lesson: next))),
                        ),
                      ] else ...[
                        const SizedBox(height: 8),
                        const Text(
                          'Tebrikler, bütün dersleri bitirdin! Artık ana sayfadaki bölümlerle devam edebilirsin.',
                          style: TextStyle(fontSize: 14.5, height: 1.45),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                GhostButton('Harf tablosu', icon: Icons.grid_view_rounded,
                    onPressed: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => const LetterTableScreen()))),
                for (var ui = 0; ui < st.bas.units.length; ui++) ...[
                  const SizedBox(height: 20),
                  Text('ÜNİTE ${ui + 1}', style: labelCaps),
                  Text(st.bas.units[ui].title, style: display(20)),
                  Text(st.bas.units[ui].desc, style: const TextStyle(fontSize: 14, color: C.muted)),
                  const SizedBox(height: 8),
                  Container(
                    clipBehavior: Clip.antiAlias,
                    decoration: BoxDecoration(
                      color: C.surface,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: C.line),
                    ),
                    child: Column(
                      children: [
                        for (var i = 0; i < st.bas.units[ui].lessons.length; i++) ...[
                          _LessonRow(
                            lesson: st.bas.units[ui].lessons[i],
                            isNext: identical(st.bas.units[ui].lessons[i], next),
                          ),
                          if (i < st.bas.units[ui].lessons.length - 1) const Divider(height: 1, color: C.sunk),
                        ],
                      ],
                    ),
                  ),
                ],
              ],
            ),
          );
        },
      );
}

class _LessonRow extends StatelessWidget {
  final BasLesson lesson;
  final bool isNext;
  const _LessonRow({required this.lesson, required this.isNext});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final done = st.lessonDone(lesson.id);
    final best = st.bestScore('bl_${lesson.id}');
    return InkWell(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => LessonScreen(lesson: lesson))),
      child: Container(
        color: isNext ? C.goldSoft : null,
        padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
        child: Row(
          children: [
            Icon(
              done ? Icons.check_circle_rounded : (isNext ? Icons.play_circle_rounded : Icons.radio_button_unchecked),
              color: done ? C.good : (isNext ? C.gold : C.faint),
              size: 24,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(lesson.title,
                  style: TextStyle(fontSize: 15, fontWeight: isNext ? FontWeight.w700 : FontWeight.w600)),
            ),
            if (best != null) ...[
              Pill('%$best', bg: done ? C.goodSoft : C.badSoft, fg: done ? C.good : C.bad, size: 11),
              const SizedBox(width: 4),
            ],
            const Icon(Icons.chevron_right_rounded, color: C.faint),
          ],
        ),
      ),
    );
  }
}

/// Tek ders: anlatım ve alıştırma.
class LessonScreen extends StatelessWidget {
  final BasLesson lesson;
  const LessonScreen({super.key, required this.lesson});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final n = st.lessonQuestions(lesson.id).length;
    return Scaffold(
      appBar: AppBar(title: const Text('Sıfırdan Arapça', style: TextStyle(fontSize: 15, color: C.muted))),
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                children: [
                  Text(lesson.title, style: display(26)),
                  const SizedBox(height: 8),
                  Text(lesson.intro, style: const TextStyle(fontSize: 16, height: 1.5)),
                  const SizedBox(height: 8),
                  for (final b in lesson.blocks) BlockView(b),
                ],
              ),
            ),
            if (n > 0)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 14),
                child: SizedBox(
                  width: double.infinity,
                  child: PrimaryButton(
                    'Alıştırma yap (${n < 10 ? n : 10} soru)',
                    icon: Icons.play_arrow_rounded,
                    onPressed: () => Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (_) => QuizScreen(
                          setKey: 'bl_${lesson.id}', name: lesson.title, questions: st.lessonSet(lesson.id)),
                    )),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// Anlatım bloğu: başlık, metin, madde ya da Arapça örnek.
class BlockView extends StatelessWidget {
  final TopicBlock b;
  const BlockView(this.b, {super.key});

  @override
  Widget build(BuildContext context) {
    if (b.h != null) {
      return Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 6),
        child: Text(b.h!, style: display(18)),
      );
    }
    if (b.b != null) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.only(top: 9, right: 10),
              child: SizedBox(
                  width: 6,
                  height: 6,
                  child: DecoratedBox(decoration: BoxDecoration(color: C.accent, shape: BoxShape.circle))),
            ),
            Expanded(child: Text(b.b!, style: const TextStyle(fontSize: 15.5, height: 1.5))),
          ],
        ),
      );
    }
    if (b.ar != null) {
      return Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.fromLTRB(14, 4, 14, 10),
        decoration: BoxDecoration(color: C.sunk, borderRadius: BorderRadius.circular(14)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Ar(b.ar!, size: 28, height: 1.8),
            Text(b.tr ?? '', style: const TextStyle(fontSize: 14.5, color: C.muted, height: 1.4)),
          ],
        ),
      );
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(b.t ?? '', style: const TextStyle(fontSize: 15.5, height: 1.5)),
    );
  }
}

/// 28 harf: dokununca dört şekli ve örneği açılır.
class LetterTableScreen extends StatelessWidget {
  const LetterTableScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final letters = AppState.I.bas.letters;
    return Scaffold(
      appBar: AppBar(title: const Text('Harf tablosu')),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: GridView.builder(
        padding: EdgeInsets.fromLTRB(16, 4, 16, 24 + MediaQuery.of(context).padding.bottom),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 4,
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          childAspectRatio: 0.82,
        ),
        itemCount: letters.length,
        itemBuilder: (context, i) {
          final l = letters[i];
          return Material(
            color: C.surface,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: C.line)),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => _show(context, l),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Ar(l.ch, size: 36, height: 1.3, align: TextAlign.center, color: C.accentDark),
                  Text(l.name, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          );
        },
      ),
      ),
    );
  }

  void _show(BuildContext context, BasLetter l) {
    const labels = ['Tek başına', 'Başta', 'Ortada', 'Sonda'];
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      backgroundColor: C.paper,
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('${l.name} · ${l.tr}', textAlign: TextAlign.center, style: display(22)),
              const SizedBox(height: 10),
              Row(
                textDirection: TextDirection.rtl,
                children: [
                  for (var k = 0; k < l.forms.length && k < labels.length; k++)
                    Expanded(
                      child: Column(
                        children: [
                          Ar(l.forms[k], size: 34, height: 1.5, align: TextAlign.center, color: C.accentDark),
                          Text(labels[k], style: const TextStyle(fontSize: 12, color: C.muted)),
                        ],
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              Text(l.note, style: const TextStyle(fontSize: 15, height: 1.45)),
              const SizedBox(height: 10),
              Panel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Ar(l.ex, size: 30, height: 1.6, align: TextAlign.center),
                    Text(l.ext, textAlign: TextAlign.center, style: const TextStyle(fontSize: 15, color: C.muted)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
