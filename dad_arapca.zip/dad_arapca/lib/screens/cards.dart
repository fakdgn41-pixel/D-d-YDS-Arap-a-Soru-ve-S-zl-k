import 'package:flutter/material.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

/// Deste seçimi.
class CardsHomeScreen extends StatefulWidget {
  const CardsHomeScreen({super.key});

  @override
  State<CardsHomeScreen> createState() => _CardsHomeScreenState();
}

class _CardsHomeScreenState extends State<CardsHomeScreen> {
  bool trFirst = false;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          return Scaffold(
            appBar: AppBar(title: const Text('Kelime kartları')),
            body: ListView(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              children: [
                const Text(
                  'Kartı çevir, anlamını bilip bilmediğini söyle. Bildiğin kartlar giderek seyrek, bilmediklerin ertesi gün yeniden gelir.',
                  style: TextStyle(fontSize: 14.5, color: C.muted, height: 1.5),
                ),
                const SizedBox(height: 12),
                Panel(
                  padding: EdgeInsets.zero,
                  child: SwitchListTile(
                    value: trFirst,
                    onChanged: (v) => setState(() => trFirst = v),
                    title: const Text('Önce Türkçesini göster', style: TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: const Text('Açıkken Arapçasını hatırlamaya çalışırsın.'),
                    activeColor: C.accent,
                  ),
                ),
                const SizedBox(height: 16),
                for (final d in kDecks) ...[
                  _DeckTile(
                    deck: d,
                    size: st.deckPool(d.key).length,
                    due: st.deckDue(d.key),
                    onTap: () {
                      final words = st.cardSession(d.key);
                      if (words.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Bu destede henüz kart yok.')),
                        );
                        return;
                      }
                      Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => CardSessionScreen(title: d.title, words: words, trFirst: trFirst),
                      ));
                    },
                  ),
                  const SizedBox(height: 8),
                ],
              ],
            ),
          );
        },
      );
}

class _DeckTile extends StatelessWidget {
  final Deck deck;
  final int size, due;
  final VoidCallback onTap;
  const _DeckTile({required this.deck, required this.size, required this.due, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
        color: C.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: C.line)),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: size == 0 ? null : onTap,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 12, 12),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(deck.title,
                          style: TextStyle(
                              fontSize: 15.5, fontWeight: FontWeight.w700, color: size == 0 ? C.faint : C.ink)),
                      Text(deck.desc.isEmpty ? '$size kart' : '$size kart · ${deck.desc}',
                          style: const TextStyle(fontSize: 13, color: C.muted)),
                    ],
                  ),
                ),
                if (due > 0) Pill('$due tekrar', bg: C.goldSoft, fg: C.gold),
                const SizedBox(width: 4),
                const Icon(Icons.chevron_right_rounded, color: C.faint),
              ],
            ),
          ),
        ),
      );
}

/// Kart oturumu.
class CardSessionScreen extends StatefulWidget {
  final String title;
  final List<Word> words;
  final bool trFirst;
  const CardSessionScreen({super.key, required this.title, required this.words, this.trFirst = false});

  @override
  State<CardSessionScreen> createState() => _CardSessionScreenState();
}

class _CardSessionScreenState extends State<CardSessionScreen> {
  late final List<Word> queue = List.of(widget.words);
  final Set<String> retried = {};
  int index = 0, known = 0, unknown = 0;
  bool flipped = false;

  Word? get w => index < queue.length ? queue[index] : null;

  void rate(bool ok) {
    final word = w!;
    AppState.I.rateCard(word.id, ok);
    setState(() {
      if (ok) {
        known++;
      } else {
        unknown++;
        // Bilinmeyen kart oturumun sonunda bir kez daha gösterilir.
        if (!retried.contains(word.id)) {
          retried.add(word.id);
          queue.add(word);
        }
      }
      index++;
      flipped = false;
    });
  }

  @override
  void dispose() {
    // Ana sayfadaki sayaçlar, ekran kapandıktan sonraki karede güncellenir.
    WidgetsBinding.instance.addPostFrameCallback((_) => AppState.I.cardsChanged());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final word = w;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title, style: const TextStyle(fontSize: 16)),
        actions: [
          if (word != null)
            Padding(
              padding: const EdgeInsets.only(right: 16),
              child: Center(
                child: Text('${index + 1} / ${queue.length}',
                    style: const TextStyle(fontSize: 14, color: C.muted, fontFeatures: tabular)),
              ),
            ),
        ],
      ),
      body: SafeArea(
        top: false,
        child: word == null ? _done() : _card(word),
      ),
    );
  }

  Widget _card(Word word) {
    final showAr = !widget.trFirst || flipped;
    final showTr = widget.trFirst || flipped;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: LinearProgressIndicator(
              value: index / queue.length,
              minHeight: 6,
              color: C.accent,
              backgroundColor: C.track,
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: GestureDetector(
              onTap: flipped ? null : () => setState(() => flipped = true),
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 220),
                transitionBuilder: (child, a) => FadeTransition(
                  opacity: a,
                  child: ScaleTransition(scale: Tween(begin: 0.97, end: 1.0).animate(a), child: child),
                ),
                child: Container(
                  key: ValueKey('${word.id}-$flipped'),
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: C.surface,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: flipped ? C.accent : C.line, width: flipped ? 1.5 : 1),
                  ),
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        const SizedBox(height: 12),
                        posPill(word.pos),
                        const SizedBox(height: 16),
                        if (showAr) Ar(word.ar, size: 48, height: 1.6, align: TextAlign.center),
                        if (showAr && flipped && word.extra.isNotEmpty)
                          Ar(word.extra, size: 22, color: C.muted, height: 1.6, align: TextAlign.center),
                        if (showTr)
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Text(word.tr, textAlign: TextAlign.center, style: display(26)),
                          ),
                        if (flipped) ...[
                          if (word.root.isNotEmpty) ...[
                            const SizedBox(height: 16),
                            const Text('KÖK', style: labelCaps),
                            Ar(word.rootSpaced, size: 26, color: C.gold, height: 1.5, align: TextAlign.center, wordSpacing: 6),
                          ],
                          if (word.ex.isNotEmpty) ...[
                            const SizedBox(height: 14),
                            const Divider(height: 1, color: C.line),
                            const SizedBox(height: 10),
                            Ar(word.ex, size: 22, height: 1.7, align: TextAlign.center),
                            Text(word.ext, textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, color: C.muted)),
                          ],
                        ] else ...[
                          const SizedBox(height: 28),
                          const Text('Anlamını düşün, sonra karta dokun',
                              style: TextStyle(fontSize: 13, color: C.muted)),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
          child: flipped
              ? Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 52,
                        child: FilledButton.icon(
                          onPressed: () => rate(false),
                          style: FilledButton.styleFrom(
                            backgroundColor: C.badSoft,
                            foregroundColor: C.bad,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          ),
                          icon: const Icon(Icons.close_rounded),
                          label: const Text('Bilmiyorum', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: SizedBox(
                        height: 52,
                        child: FilledButton.icon(
                          onPressed: () => rate(true),
                          style: FilledButton.styleFrom(
                            backgroundColor: C.good,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          ),
                          icon: const Icon(Icons.check_rounded),
                          label: const Text('Biliyorum', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                        ),
                      ),
                    ),
                  ],
                )
              : SizedBox(
                  width: double.infinity,
                  child: PrimaryButton('Kartı çevir', icon: Icons.flip_rounded, onPressed: () => setState(() => flipped = true)),
                ),
        ),
      ],
    );
  }

  Widget _done() => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.check_circle_rounded, size: 56, color: C.good),
            const SizedBox(height: 12),
            Text('Deste tamamlandı', textAlign: TextAlign.center, style: display(24)),
            const SizedBox(height: 8),
            Text('$known kez biliyorum, $unknown kez bilmiyorum dedin.',
                textAlign: TextAlign.center, style: const TextStyle(fontSize: 15, color: C.muted)),
            const SizedBox(height: 6),
            const Text('Bilmediğin kartlar yarın yeniden karşına çıkacak.',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 14, color: C.muted)),
            const SizedBox(height: 24),
            PrimaryButton('Bitir', onPressed: () => Navigator.of(context).pop()),
          ],
        ),
      );
}
