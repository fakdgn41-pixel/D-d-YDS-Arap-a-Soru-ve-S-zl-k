import 'package:flutter/material.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'quiz.dart';
import 'topics.dart';

/// Sarf: konu anlatımları, bab tablosu, çekim tabloları ve test.
class SarfScreen extends StatefulWidget {
  const SarfScreen({super.key});

  @override
  State<SarfScreen> createState() => _SarfScreenState();
}

class _SarfScreenState extends State<SarfScreen> {
  int view = 0; // 0: konular, 1: bablar, 2: çekim tabloları

  void _test(BuildContext context) {
    final qs = AppState.I.buildSet('sarf');
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => QuizScreen(setKey: 'sarf', name: 'Sarf', questions: qs),
    ));
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          final score = st.lastScore('sarf');
          return Scaffold(
            appBar: AppBar(title: const Text('Sarf')),
            body: ListView(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 24 + MediaQuery.of(context).padding.bottom),
              children: [
                const Text(
                  'Kelimenin yapısı: bablar, fiil çekimi, illetli fiiller, masdarlar ve türemiş isimler. '
                  'Konuyu oku, tabloya bak, sonra kendini test et.',
                  style: TextStyle(fontSize: 14.5, color: C.muted, height: 1.5),
                ),
                const SizedBox(height: 14),
                PrimaryButton('Sarf testi çöz', icon: Icons.play_arrow_rounded, onPressed: () => _test(context)),
                if (score != null) ...[
                  const SizedBox(height: 10),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Pill('Son test %$score', bg: C.accentSoft, fg: C.accentDark),
                  ),
                ],
                const SizedBox(height: 14),
                SegmentedButton<int>(
                  segments: const [
                    ButtonSegment(value: 0, label: Text('Konular')),
                    ButtonSegment(value: 1, label: Text('Bablar')),
                    ButtonSegment(value: 2, label: Text('Çekimler')),
                  ],
                  selected: {view},
                  showSelectedIcon: false,
                  onSelectionChanged: (v) => setState(() => view = v.first),
                ),
                const SizedBox(height: 12),
                if (view == 0) ..._topics(context, st),
                if (view == 1) ..._babs(context, st),
                if (view == 2) ..._tables(context, st),
              ],
            ),
          );
        },
      );

  List<Widget> _topics(BuildContext context, AppState st) => [
        _ListBox(children: [
          for (final t in st.sarfTopics)
            _Row(
              title: t.title,
              sub: t.intro,
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => TopicScreen(topic: t))),
            ),
        ]),
      ];

  List<Widget> _babs(BuildContext context, AppState st) {
    final groups = <String, List<Bab>>{};
    for (final b in st.sarf.babs) {
      groups.putIfAbsent(b.group, () => []).add(b);
    }
    return [
      for (final g in groups.entries) ...[
        Text(g.key.toUpperCase(), style: labelCaps),
        const SizedBox(height: 8),
        _ListBox(children: [
          for (final b in g.value)
            _Row(
              title: b.name,
              arabic: '${b.forms[0]}  ${b.forms[1]}',
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => BabScreen(bab: b))),
            ),
        ]),
        const SizedBox(height: 16),
      ],
    ];
  }

  List<Widget> _tables(BuildContext context, AppState st) => [
        _ListBox(children: [
          for (final t in st.sarf.tables)
            _Row(
              title: '${t.tr} · ${t.type}',
              arabic: t.verb,
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ConjScreen(table: t))),
            ),
        ]),
      ];
}

class _ListBox extends StatelessWidget {
  final List<Widget> children;
  const _ListBox({required this.children});

  @override
  Widget build(BuildContext context) => Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: C.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: C.line),
        ),
        child: Column(
          children: [
            for (var i = 0; i < children.length; i++) ...[
              children[i],
              if (i < children.length - 1) const Divider(height: 1, color: C.sunk),
            ],
          ],
        ),
      );
}

class _Row extends StatelessWidget {
  final String title;
  final String? sub, arabic;
  final VoidCallback onTap;
  const _Row({required this.title, this.sub, this.arabic, required this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 12, 10),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    if (arabic != null) Ar(arabic!, size: 23, height: 1.6),
                    Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                    if (sub != null && sub!.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(sub!, maxLines: 2, overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 13.5, color: C.muted, height: 1.4)),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 6),
              const Icon(Icons.chevron_right_rounded, color: C.faint),
            ],
          ),
        ),
      );
}

/// Tek bab: kalıp tablosu, anlamlar ve örnekler.
class BabScreen extends StatelessWidget {
  final Bab bab;
  const BabScreen({super.key, required this.bab});

  static const _labels = ['Mazi', 'Muzari', 'Masdar', 'İsm-i fâil', 'İsm-i mef‘ûl', 'Emir'];

  @override
  Widget build(BuildContext context) {
    final b = bab;
    return Scaffold(
      appBar: AppBar(title: Text(b.group, style: const TextStyle(fontSize: 15, color: C.muted))),
      body: ListView(
        padding: EdgeInsets.fromLTRB(16, 0, 16, 24 + MediaQuery.of(context).padding.bottom),
        children: [
          Text(b.name, style: display(24)),
          const SizedBox(height: 12),
          Container(
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              color: C.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: C.line),
            ),
            child: Column(
              children: [
                for (var i = 0; i < b.forms.length && i < _labels.length; i++)
                  Container(
                    decoration: BoxDecoration(
                      color: i.isEven ? C.surface : C.soft,
                    ),
                    padding: const EdgeInsets.fromLTRB(16, 2, 16, 4),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 110,
                          child: Text(_labels[i], style: const TextStyle(fontSize: 14, color: C.muted)),
                        ),
                        Expanded(child: Ar(b.forms[i], size: 25, height: 1.7, color: C.gold)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          const Text('ANLAMLARI VE ÖZELLİKLERİ', style: labelCaps),
          const SizedBox(height: 8),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                for (final m in b.meanings)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(top: 7, right: 10),
                          child: Icon(Icons.circle, size: 6, color: C.accent),
                        ),
                        Expanded(child: Text(m, style: const TextStyle(fontSize: 15, height: 1.45))),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          const Text('ÖRNEKLER', style: labelCaps),
          const SizedBox(height: 8),
          for (final e in b.examples) ...[
            Panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Ar(e[0], size: 26, height: 1.6),
                  Text(e[1], style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  const Divider(height: 1, color: C.sunk),
                  Ar(e[2], size: 21, height: 1.8),
                  Text(e[3], style: const TextStyle(fontSize: 14, color: C.muted, height: 1.4)),
                ],
              ),
            ),
            const SizedBox(height: 8),
          ],
        ],
      ),
    );
  }
}

/// Çekim tablosu: kip seçilir, on dört şahıs listelenir.
class ConjScreen extends StatefulWidget {
  final ConjTable table;
  const ConjScreen({super.key, required this.table});

  @override
  State<ConjScreen> createState() => _ConjScreenState();
}

class _ConjScreenState extends State<ConjScreen> {
  String tense = 'mazi';
  bool hide = false; // ezber modu: formları gizle
  final Set<int> shown = {};

  @override
  Widget build(BuildContext context) {
    final sd = AppState.I.sarf;
    final t = widget.table;
    final tenses = sd.tenses.where((e) => t.t.containsKey(e.$1)).toList();
    final forms = t.t[tense] ?? const <String>[];
    final idx = tense == 'emir' ? sd.emirIdx : List<int>.generate(forms.length, (i) => i);
    return Scaffold(
      appBar: AppBar(title: Text(t.type, style: const TextStyle(fontSize: 15, color: C.muted))),
      body: ListView(
        padding: EdgeInsets.fromLTRB(16, 0, 16, 24 + MediaQuery.of(context).padding.bottom),
        children: [
          Ar(t.verb, size: 36, height: 1.5, align: TextAlign.center),
          Text(t.tr, textAlign: TextAlign.center, style: display(20)),
          if (t.note.isNotEmpty) ...[
            const SizedBox(height: 10),
            Panel(
              color: C.goldSoft,
              child: Text(t.note, style: const TextStyle(fontSize: 14.5, height: 1.45)),
            ),
          ],
          const SizedBox(height: 12),
          SizedBox(
            height: 46,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                for (final e in tenses)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(e.$2,
                          style: TextStyle(fontWeight: FontWeight.w600, color: tense == e.$1 ? Colors.white : C.ink)),
                      selected: tense == e.$1,
                      showCheckmark: false,
                      selectedColor: C.ink,
                      backgroundColor: C.surface,
                      side: BorderSide(color: tense == e.$1 ? C.ink : C.line),
                      onSelected: (_) => setState(() {
                        tense = e.$1;
                        shown.clear();
                      }),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 6),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Ezber modu', style: TextStyle(fontWeight: FontWeight.w600)),
            subtitle: const Text('Formlar gizlenir; görmek için satıra dokun.'),
            value: hide,
            onChanged: (v) => setState(() {
              hide = v;
              shown.clear();
            }),
          ),
          const SizedBox(height: 6),
          Container(
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              color: C.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: C.line),
            ),
            child: Column(
              children: [
                for (var i = 0; i < forms.length; i++)
                  InkWell(
                    onTap: hide ? () => setState(() => shown.contains(i) ? shown.remove(i) : shown.add(i)) : null,
                    child: Container(
                      color: (idx[i] ~/ 3).isEven ? C.surface : C.soft,
                      padding: const EdgeInsets.fromLTRB(14, 2, 14, 2),
                      child: Row(
                        children: [
                          Expanded(
                            flex: 5,
                            child: Text(sd.personsTr[idx[i]], style: const TextStyle(fontSize: 13.5, color: C.muted)),
                          ),
                          SizedBox(
                            width: 64,
                            child: Ar(sd.persons[idx[i]], size: 19, height: 1.7, color: C.faint),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            flex: 6,
                            child: hide && !shown.contains(i)
                                ? const Align(
                                    alignment: Alignment.centerRight,
                                    child: Icon(Icons.visibility_outlined, color: C.faint, size: 20),
                                  )
                                : Ar(forms[i], size: 25, height: 1.7, color: C.accentDark),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
