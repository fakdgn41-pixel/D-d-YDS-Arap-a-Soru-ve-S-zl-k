import 'package:flutter/material.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'cards.dart';
import 'word.dart';

/// Arama için sadeleştirme: hareke, tatvil ve hemze farkları yok sayılır;
/// Türkçe büyük/küçük harf doğru eşlenir.
String normalize(String s) {
  var x = s
      .replaceAll(RegExp(r'[ً-ٰٟـ]'), '')
      .replaceAll(RegExp(r'[أإآٱ]'), 'ا')
      .replaceAll('ى', 'ي')
      .replaceAll('ة', 'ه')
      .replaceAll('ؤ', 'و')
      .replaceAll('ئ', 'ي')
      .replaceAll('İ', 'i')
      .replaceAll('I', 'ı');
  return x.toLowerCase().trim();
}

class DictionaryScreen extends StatefulWidget {
  const DictionaryScreen({super.key});

  @override
  State<DictionaryScreen> createState() => _DictionaryScreenState();
}

class _DictionaryScreenState extends State<DictionaryScreen> {
  final ctrl = TextEditingController();
  String filter = 'all'; // all, yds, f, i, s, b, saved
  String konu = ''; // boşsa bütün konular

  @override
  void dispose() {
    ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          final q = normalize(ctrl.text);
          final list = st.words.where((w) {
            if (filter == 'saved' && !st.saved.contains(w.id)) return false;
            if (filter == 'yds' && w.yds.isEmpty) return false;
            if (konu.isNotEmpty && w.konu != konu) return false;
            if (filter != 'all' && filter != 'saved' && filter != 'yds' && w.pos != filter) return false;
            if (q.isEmpty) return true;
            return normalize(w.ar).contains(q) ||
                normalize(w.extra).contains(q) ||
                normalize(w.root).contains(q) ||
                normalize(w.tr).contains(q);
          }).toList();

          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Expanded(child: Text('Sözlük', style: display(26))),
                    Text('${list.length} kelime',
                        style: const TextStyle(fontSize: 13, color: C.muted, fontFeatures: tabular)),
                    const SizedBox(width: 8),
                    OutlinedButton.icon(
                      onPressed: () => Navigator.of(context)
                          .push(MaterialPageRoute(builder: (_) => const CardsHomeScreen())),
                      style: OutlinedButton.styleFrom(
                        backgroundColor: C.surface,
                        foregroundColor: C.accent,
                        side: const BorderSide(color: C.line),
                        visualDensity: VisualDensity.compact,
                      ),
                      icon: const Icon(Icons.style_outlined, size: 18),
                      label: const Text('Kartlar'),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: TextField(
                  controller: ctrl,
                  onChanged: (_) => setState(() {}),
                  textInputAction: TextInputAction.search,
                  style: const TextStyle(fontSize: 16),
                  decoration: InputDecoration(
                    hintText: 'Arapça veya Türkçe ara',
                    prefixIcon: const Icon(Icons.search_rounded, color: C.muted),
                    suffixIcon: ctrl.text.isEmpty
                        ? null
                        : IconButton(
                            tooltip: 'Temizle',
                            icon: const Icon(Icons.close_rounded, color: C.muted),
                            onPressed: () => setState(ctrl.clear),
                          ),
                  ),
                ),
              ),
              SizedBox(
                height: 54,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
                  children: [
                    _chip('all', 'Tümü'),
                    _chip('yds', "YDS'de çıkan", icon: Icons.verified_outlined),
                    for (final e in kPos.entries) _chip(e.key, e.value),
                    _chip('saved', 'Kayıtlı', icon: Icons.bookmark_border_rounded),
                  ],
                ),
              ),
              SizedBox(
                height: 46,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                  children: [
                    _konuChip('', 'Bütün konular'),
                    for (final e in kKonu.entries) _konuChip(e.key, e.value),
                  ],
                ),
              ),
              Expanded(
                child: list.isEmpty
                    ? const Padding(
                        padding: EdgeInsets.all(32),
                        child: Text(
                          'Bu aramayla eşleşen kelime yok. Harekesiz yazmayı ya da Türkçe aramayı dene.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: C.muted, fontSize: 15),
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                        itemCount: list.length,
                        itemBuilder: (c, i) => _WordRow(
                          word: list[i],
                          saved: st.saved.contains(list[i].id),
                          first: i == 0,
                          last: i == list.length - 1,
                        ),
                      ),
              ),
            ],
          );
        },
      );

  Widget _konuChip(String key, String label) {
    final sel = konu == key;
    return Padding(
      padding: const EdgeInsets.only(right: 6),
      child: Material(
        color: sel ? C.accentSoft : C.surface,
        shape: StadiumBorder(side: BorderSide(color: sel ? C.accent : C.line)),
        child: InkWell(
          customBorder: const StadiumBorder(),
          onTap: () => setState(() => konu = key),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Center(
              widthFactor: 1,
              child: Text(label,
                style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: sel ? C.accentDark : C.muted)),
            ),
          ),
        ),
      ),
    );
  }

  Widget _chip(String key, String label, {IconData? icon}) {
    final sel = filter == key;
    return Padding(
      padding: const EdgeInsets.only(right: 6),
      child: Material(
        color: sel ? C.ink : C.surface,
        shape: StadiumBorder(side: BorderSide(color: sel ? C.ink : C.line)),
        child: InkWell(
          customBorder: const StadiumBorder(),
          onTap: () => setState(() => filter = key),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Row(
              children: [
                if (icon != null) ...[
                  Icon(icon, size: 15, color: sel ? Colors.white : C.muted),
                  const SizedBox(width: 4),
                ],
                Text(label,
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: sel ? Colors.white : C.muted)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _WordRow extends StatelessWidget {
  final Word word;
  final bool saved, first, last;
  const _WordRow({required this.word, required this.saved, required this.first, required this.last});

  @override
  Widget build(BuildContext context) {
    final r = BorderRadius.vertical(
      top: Radius.circular(first ? 18 : 0),
      bottom: Radius.circular(last ? 18 : 0),
    );
    return Material(
      color: C.surface,
      shape: RoundedRectangleBorder(borderRadius: r),
      child: InkWell(
        borderRadius: r,
        onTap: () => Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => WordScreen(word: word))),
        child: Container(
          decoration: BoxDecoration(
            border: last ? null : const Border(bottom: BorderSide(color: C.sunk)),
          ),
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Ar(word.ar, size: 27, height: 1.75),
              Row(
                children: [
                  Expanded(
                    child: Text(word.tr,
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                  ),
                  if (saved) ...[
                    const Icon(Icons.bookmark_rounded, size: 18, color: C.accent),
                    const SizedBox(width: 8),
                  ],
                  if (word.yds.isNotEmpty) ...[
                    ydsPill(word.yds),
                    const SizedBox(width: 6),
                  ],
                  posPill(word.pos),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
