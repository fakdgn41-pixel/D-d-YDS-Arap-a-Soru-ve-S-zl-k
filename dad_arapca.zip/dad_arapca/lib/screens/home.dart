import 'package:flutter/material.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'cards.dart';
import 'exam.dart';
import 'quiz.dart';
import 'settings.dart';

class HomeScreen extends StatelessWidget {
  final VoidCallback onOpenResults;
  const HomeScreen({super.key, required this.onOpenResults});

  void _start(BuildContext context, String key, String name, List<Question> qs) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => QuizScreen(setKey: key, name: name, questions: qs),
    ));
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          final mix = kSets.first;
          final sections = kSets.skip(1).toList();
          final due = st.dueIds.length;
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            children: [
              _Header(onSettings: () => Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => const SettingsScreen()))),
              const SizedBox(height: 16),
              _Countdown(onTap: onOpenResults),
              const SizedBox(height: 12),
              _ReviewCard(
                due: due,
                total: st.srsTotal,
                nextIn: st.nextDueIn,
                onTap: () => _start(context, 'srs', 'Akıllı tekrar', st.reviewSet()),
              ),
              const SizedBox(height: 12),
              _BigCard(
                icon: Icons.assignment_outlined,
                title: 'Deneme sınavı',
                subtitle: st.exam != null && st.exam!.remaining > 0
                    ? 'Yarım kaldı · ${st.exam!.answeredCount}/80 cevaplandı'
                    : '80 soru · 180 dakika · sınav düzeninde',
                strong: true,
                onTap: () => Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => const ExamIntroScreen())),
              ),
              const SizedBox(height: 10),
              _BigCard(
                icon: Icons.shuffle_rounded,
                title: mix.title,
                subtitle: '${mix.count} soru · her bölümden · yaklaşık ${(mix.count * 2.25).round()} dk',
                onTap: () => _start(context, mix.key, mix.title, st.buildSet(mix.key)),
              ),
              const SizedBox(height: 10),
              _BigCard(
                icon: Icons.style_outlined,
                title: 'Kelime kartları',
                subtitle: st.deckDue('all') > 0
                    ? '${st.deckDue('all')} kart tekrar bekliyor · ${st.words.length} kelime'
                    : '${st.cardsSeen}/${st.words.length} kart görüldü · çevir, bil, pekiştir',
                onTap: () => Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => const CardsHomeScreen())),
              ),
              const SizedBox(height: 22),
              const SectionTitle('Bölüm çalış', trailing: Text('SON SKOR', style: labelCaps)),
              const SizedBox(height: 10),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.75,
                children: [
                  for (final s in sections)
                    _SectionTile(
                      title: s.title,
                      sub: s.key == 'sozluk'
                          ? '${st.words.length} kelime'
                          : '${st.countIn(s.key)} soru',
                      score: st.lastScore(s.key),
                      onTap: () => _start(context, s.key, s.title, st.buildSet(s.key)),
                    ),
                  _SectionTile(
                    title: 'İşaretlediklerim',
                    sub: '${st.flagged.length} soru',
                    score: null,
                    badge: st.flagged.isEmpty ? 'Boş' : null,
                    onTap: st.flagged.isEmpty
                        ? null
                        : () => _start(context, 'flag', 'İşaretlediklerim', st.flaggedSet()),
                  ),
                ],
              ),
            ],
          );
        },
      );
}

class _Header extends StatelessWidget {
  final VoidCallback onSettings;
  const _Header({required this.onSettings});

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            padding: const EdgeInsets.only(bottom: 6),
            decoration: BoxDecoration(color: C.accent, borderRadius: BorderRadius.circular(13)),
            child: const Text('ض',
                textDirection: TextDirection.rtl,
                style: TextStyle(fontFamily: kArabic, fontSize: 28, height: 1, color: Colors.white)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Dâd', style: display(22)),
                const Text('YDS Arapça', style: TextStyle(fontSize: 13, color: C.muted)),
              ],
            ),
          ),
          IconButton(
            tooltip: 'Ayarlar',
            onPressed: onSettings,
            icon: const Icon(Icons.tune_rounded, color: C.ink),
          ),
        ],
      );
}

class _Countdown extends StatelessWidget {
  final VoidCallback onTap;
  const _Countdown({required this.onTap});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final left = st.daysLeft;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final monday = today.subtract(Duration(days: today.weekday - 1));
    final studied = st.log.map((r) => r.day).toSet();
    final t = st.dayTotals(dayKey(today));
    final exam = st.examDate;

    return Material(
      color: C.accent,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(left > 0 ? '$left' : '—',
                      style: display(56, color: Colors.white).copyWith(height: 1, fontFeatures: tabular)),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                            left > 0
                                ? 'gün kaldı'
                                : left == 0
                                    ? 'Sınav bugün, başarılar'
                                    : 'Sınav tarihi geçti',
                            style: const TextStyle(
                                fontSize: 17, fontWeight: FontWeight.w700, color: Colors.white)),
                        Text('YDS Arapça · ${trDate(exam, weekday: true)} ${exam.year}',
                            style: const TextStyle(fontSize: 13, color: C.onAccent)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Container(height: 1, color: Colors.white.withValues(alpha: 0.22)),
              const SizedBox(height: 12),
              Row(
                children: [
                  for (var i = 0; i < 7; i++)
                    Expanded(
                      child: _DayDot(
                        label: kWeekShort[i],
                        date: monday.add(Duration(days: i)),
                        today: today,
                        studied: studied,
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                t.sets == 0
                    ? 'Bugün henüz set çözmedin.'
                    : 'Bugün ${t.sets} set · ${t.correct}/${t.total} doğru · %${(t.correct * 100 / t.total).round()}',
                style: const TextStyle(fontSize: 14, color: Colors.white, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DayDot extends StatelessWidget {
  final String label;
  final DateTime date, today;
  final Set<String> studied;
  const _DayDot({required this.label, required this.date, required this.today, required this.studied});

  @override
  Widget build(BuildContext context) {
    final isToday = dayKey(date) == dayKey(today);
    final done = studied.contains(dayKey(date));
    final future = !isToday && date.isAfter(today);
    Widget dot;
    if (done) {
      dot = Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(color: isToday ? C.today : Colors.white, shape: BoxShape.circle),
        child: Icon(Icons.check_rounded, size: 16, color: isToday ? const Color(0xFF3A2604) : C.accent),
      );
    } else if (future || isToday) {
      dot = Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.14),
          shape: BoxShape.circle,
          border: isToday ? Border.all(color: C.today, width: 2) : null,
        ),
      );
    } else {
      dot = Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white.withValues(alpha: 0.45), width: 1.5),
        ),
      );
    }
    return Column(
      children: [
        Text(label,
            style: TextStyle(
                fontSize: 11,
                fontWeight: isToday ? FontWeight.w700 : FontWeight.w600,
                color: isToday ? Colors.white : C.onAccent)),
        const SizedBox(height: 6),
        dot,
      ],
    );
  }
}

class _ReviewCard extends StatelessWidget {
  final int due, total;
  final int? nextIn;
  final VoidCallback onTap;
  const _ReviewCard({required this.due, required this.total, required this.nextIn, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final active = due > 0;
    final String sub;
    if (active) {
      sub = 'Yanlış yaptığın soru ve kelimeler, unutmadan önce tekrar.';
    } else if (total == 0) {
      sub = 'Yanlış yaptığın sorular buraya gelir ve aralıklarla tekrar edilir.';
    } else {
      final n = nextIn ?? 1;
      sub = 'Listede $total öğe var. Sıradaki tekrar ${n <= 1 ? 'yarın' : '$n gün sonra'}.';
    }
    return Material(
      color: active ? C.goldSoft : C.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: BorderSide(color: active ? C.goldLine : C.line, width: active ? 1.5 : 1),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: active ? onTap : null,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: active ? C.gold : C.sunk, shape: BoxShape.circle),
                child: active
                    ? Text('$due',
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w800, color: Colors.white, fontFeatures: tabular))
                    : const Icon(Icons.history_rounded, color: C.muted),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(active ? 'Akıllı tekrar: $due öğe hazır' : 'Akıllı tekrar',
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 2),
                    Text(sub, style: const TextStyle(fontSize: 13, color: C.muted, height: 1.35)),
                  ],
                ),
              ),
              if (active) const Icon(Icons.chevron_right_rounded, color: C.gold),
            ],
          ),
        ),
      ),
    );
  }
}

class _BigCard extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final bool strong;
  final VoidCallback onTap;
  const _BigCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.strong = false,
  });

  @override
  Widget build(BuildContext context) => Material(
        color: C.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: strong ? C.accent : C.line, width: strong ? 1.5 : 1),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(color: strong ? C.accent : C.accentSoft, shape: BoxShape.circle),
                  child: Icon(icon, color: strong ? Colors.white : C.accent),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                      Text(subtitle, style: const TextStyle(fontSize: 13, color: C.muted)),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right_rounded, color: C.accent),
              ],
            ),
          ),
        ),
      );
}

class _SectionTile extends StatelessWidget {
  final String title, sub;
  final int? score;
  final String? badge;
  final VoidCallback? onTap;
  const _SectionTile({required this.title, required this.sub, required this.score, this.onTap, this.badge});

  @override
  Widget build(BuildContext context) => Material(
        color: C.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: C.line),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        height: 1.25,
                        color: onTap == null ? C.faint : C.ink)),
                const Spacer(),
                Row(
                  children: [
                    Expanded(child: Text(sub, style: const TextStyle(fontSize: 13, color: C.muted))),
                    badge != null
                        ? Pill(badge!, bg: C.surface, fg: C.faint, border: C.line)
                        : scorePill(score),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
}
