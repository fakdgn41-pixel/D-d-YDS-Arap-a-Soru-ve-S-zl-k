import 'package:flutter/material.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'quiz.dart';

class HomeScreen extends StatelessWidget {
  final VoidCallback onOpenResults;
  const HomeScreen({super.key, required this.onOpenResults});

  void _start(BuildContext context, SetDef s) {
    final qs = AppState.I.buildSet(s.key);
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => QuizScreen(setKey: s.key, name: s.title, questions: qs),
    ));
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          final mix = kSets.first;
          final sections = kSets.skip(1).toList();
          final flagged = st.flaggedSet();
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            children: [
              const _Header(),
              const SizedBox(height: 16),
              _Countdown(onTap: onOpenResults),
              const SizedBox(height: 16),
              _MixCard(def: mix, onTap: () => _start(context, mix)),
              const SizedBox(height: 22),
              const SectionTitle('Bölüm çalış', trailing: Text('SON SKOR', style: labelCaps)),
              const SizedBox(height: 10),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.95,
                children: [
                  for (final s in sections)
                    _SectionTile(
                        def: s, score: st.lastScore(s.key), onTap: () => _start(context, s)),
                ],
              ),
              if (flagged.isNotEmpty) ...[
                const SizedBox(height: 12),
                _FlaggedRow(
                  count: flagged.length,
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => QuizScreen(
                        setKey: 'flag', name: 'İşaretlediklerim', questions: st.flaggedSet()),
                  )),
                ),
              ],
            ],
          );
        },
      );
}

class _Header extends StatelessWidget {
  const _Header();

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            padding: const EdgeInsets.only(bottom: 6),
            decoration: BoxDecoration(color: C.accent, borderRadius: BorderRadius.circular(13)),
            child: const Text('ض',
                textDirection: TextDirection.rtl,
                style: TextStyle(fontFamily: kArabic, fontSize: 28, height: 1, color: Colors.white)),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Dâd', style: display(22)),
              const Text('YDS Arapça', style: TextStyle(fontSize: 13, color: C.muted)),
            ],
          ),
        ],
      );
}

class _Countdown extends StatelessWidget {
  final VoidCallback onTap;
  const _Countdown({required this.onTap});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final left = st.daysLeft;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final monday = today.subtract(Duration(days: today.weekday - 1));
    final studied = st.log.map((r) => r.day).toSet();
    final t = st.dayTotals(dayKey(today));
    final exam = st.examDate;

    return Material(
      color: C.accent,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(left > 0 ? '$left' : '—',
                      style: display(56, color: Colors.white)
                          .copyWith(height: 1, fontFeatures: tabular)),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                            left > 0
                                ? 'gün kaldı'
                                : left == 0
                                    ? 'Sınav bugün, başarılar'
                                    : 'Sınav tarihi geçti',
                            style: const TextStyle(
                                fontSize: 17, fontWeight: FontWeight.w700, color: Colors.white)),
                        Text('YDS Arapça · ${trDate(exam, weekday: true)} ${exam.year}',
                            style: const TextStyle(fontSize: 13, color: C.onAccent)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Container(height: 1, color: Colors.white.withValues(alpha: 0.22)),
              const SizedBox(height: 12),
              Row(
                children: [
                  for (var i = 0; i < 7; i++)
                    Expanded(
                      child: _DayDot(
                        label: kWeekShort[i],
                        date: monday.add(Duration(days: i)),
                        today: today,
                        studied: studied,
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                t.sets == 0
                    ? 'Bugün henüz set çözmedin.'
                    : 'Bugün ${t.sets} set · ${t.correct}/${t.total} doğru · %${(t.correct * 100 / t.total).round()}',
                style: const TextStyle(fontSize: 14, color: Colors.white, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DayDot extends StatelessWidget {
  final String label;
  final DateTime date, today;
  final Set<String> studied;
  const _DayDot(
      {required this.label, required this.date, required this.today, required this.studied});

  @override
  Widget build(BuildContext context) {
    final isToday = dayKey(date) == dayKey(today);
    final done = studied.contains(dayKey(date));
    final future = !isToday && date.isAfter(today);
    Widget dot;
    if (done) {
      dot = Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(color: isToday ? C.today : Colors.white, shape: BoxShape.circle),
        child: Icon(Icons.check_rounded,
            size: 16, color: isToday ? const Color(0xFF3A2604) : C.accent),
      );
    } else if (future || isToday) {
      dot = Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.14),
          shape: BoxShape.circle,
          border: isToday ? Border.all(color: C.today, width: 2) : null,
        ),
      );
    } else {
      dot = Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white.withValues(alpha: 0.45), width: 1.5),
        ),
      );
    }
    return Column(
      children: [
        Text(label,
            style: TextStyle(
                fontSize: 11,
                fontWeight: isToday ? FontWeight.w700 : FontWeight.w600,
                color: isToday ? Colors.white : C.onAccent)),
        const SizedBox(height: 6),
        dot,
      ],
    );
  }
}

class _MixCard extends StatelessWidget {
  final SetDef def;
  final VoidCallback onTap;
  const _MixCard({required this.def, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
        color: C.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: const BorderSide(color: C.accent, width: 1.5),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: const BoxDecoration(color: C.accentSoft, shape: BoxShape.circle),
                  child: const Icon(Icons.shuffle_rounded, color: C.accent),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(def.title,
                          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                      Text('${def.count} soru · ${def.desc} · yaklaşık ${(def.count * 2.25).round()} dk',
                          style: const TextStyle(fontSize: 13, color: C.muted)),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right_rounded, color: C.accent),
              ],
            ),
          ),
        ),
      );
}

class _SectionTile extends StatelessWidget {
  final SetDef def;
  final int? score;
  final VoidCallback onTap;
  const _SectionTile({required this.def, required this.score, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
        color: C.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: C.line),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(def.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, height: 1.25)),
                const Spacer(),
                Row(
                  children: [
                    Expanded(
                        child: Text('${def.count} soru',
                            style: const TextStyle(fontSize: 13, color: C.muted))),
                    scorePill(score),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
}

class _FlaggedRow extends StatelessWidget {
  final int count;
  final VoidCallback onTap;
  const _FlaggedRow({required this.count, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
        color: C.goldSoft,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            child: Row(
              children: [
                const Icon(Icons.bookmark_rounded, color: C.gold, size: 20),
                const SizedBox(width: 10),
                Expanded(
                    child: Text('İşaretlediğin $count soruyu çöz',
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700))),
                const Icon(Icons.chevron_right_rounded, color: C.gold),
              ],
            ),
          ),
        ),
      );
}
