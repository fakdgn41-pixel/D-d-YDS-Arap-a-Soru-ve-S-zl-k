import 'dart:async';

import 'package:flutter/material.dart';

import '../models.dart';
import '../question_view.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

// ---------------------------------------------------------------------------
// Giriş: kurallar, bölüm düzeni, başla / devam et
// ---------------------------------------------------------------------------
class ExamIntroScreen extends StatelessWidget {
  const ExamIntroScreen({super.key});

  void _open(BuildContext context, ExamSession e) {
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => ExamScreen(session: e)));
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final saved = st.exam;
    final savedAlive = saved != null && saved.remaining > 0;
    return Scaffold(
      appBar: AppBar(title: const Text('Deneme sınavı')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        children: [
          Text('80 soru · 180 dakika', style: display(26)),
          const SizedBox(height: 8),
          const Text(
            'Sorular gerçek sınavdaki sırayla gelir. Cevaplar sınav bitince gösterilir. '
            'Sorular arasında serbestçe dolaşabilir, şıkkını değiştirebilir, emin olmadığını işaretleyebilirsin. '
            'Uygulamadan çıksan da süre işlemeye devam eder; kaldığın yerden sürdürebilirsin.',
            style: TextStyle(fontSize: 15, height: 1.5, color: C.muted),
          ),
          const SizedBox(height: 16),
          Panel(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            child: Column(
              children: [
                for (final (cat, n) in kExamPlan)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 7),
                    child: Row(
                      children: [
                        Expanded(child: Text(kCat[cat]!, style: const TextStyle(fontSize: 15))),
                        Text('$n soru',
                            style: const TextStyle(
                                fontSize: 14, fontWeight: FontWeight.w700, fontFeatures: tabular)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          const Text('Puan, YDS’deki gibi hesaplanır: her doğru 1,25 puan; yanlışlar doğruları götürmez.',
              style: TextStyle(fontSize: 13, color: C.muted)),
          const SizedBox(height: 24),
          if (savedAlive) ...[
            PrimaryButton(
              'Kaldığın yerden devam et (${saved.answeredCount}/80)',
              icon: Icons.play_arrow_rounded,
              onPressed: () => _open(context, saved),
            ),
            const SizedBox(height: 10),
            GhostButton('Yeni deneme başlat', onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (c) => AlertDialog(
                  title: const Text('Yeni deneme başlatılsın mı?'),
                  content: const Text('Yarım kalan denemedeki cevapların silinecek.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')),
                    FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Yeni başlat')),
                  ],
                ),
              );
              if (ok == true && context.mounted) _open(context, st.newExam());
            }),
          ] else
            PrimaryButton('Sınavı başlat', icon: Icons.play_arrow_rounded, onPressed: () {
              if (saved != null) st.clearExam();
              _open(context, st.newExam());
            }),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Sınav
// ---------------------------------------------------------------------------
class ExamScreen extends StatefulWidget {
  final ExamSession session;
  const ExamScreen({super.key, required this.session});

  @override
  State<ExamScreen> createState() => _ExamScreenState();
}

class _ExamScreenState extends State<ExamScreen> {
  late final ExamSession e = widget.session;
  Timer? timer;
  int remaining = 0;
  bool finished = false;
  final scroll = ScrollController();

  Question get q => e.questions[e.current];

  @override
  void initState() {
    super.initState();
    remaining = e.remaining;
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() => remaining = e.remaining);
      if (remaining <= 0) _finish(timeUp: true);
    });
    if (remaining <= 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _finish(timeUp: true));
    }
  }

  @override
  void dispose() {
    timer?.cancel();
    scroll.dispose();
    super.dispose();
  }

  void _go(int i) {
    if (i < 0 || i >= e.questions.length) return;
    setState(() => e.current = i);
    AppState.I.saveExam();
    if (scroll.hasClients) scroll.jumpTo(0);
  }

  void _select(int j) {
    setState(() => e.answers[e.current] = e.answers[e.current] == j ? null : j);
    AppState.I.saveExam();
  }

  void _toggleFlag() {
    setState(() => e.flags.contains(e.current) ? e.flags.remove(e.current) : e.flags.add(e.current));
    AppState.I.saveExam();
  }

  String _clock(int s) {
    final h = s ~/ 3600, m = (s % 3600) ~/ 60, sec = s % 60;
    return '$h:${two(m)}:${two(sec)}';
  }

  Future<void> _confirmFinish() async {
    final blank = e.answers.where((a) => a == null).length;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Sınavı bitir'),
        content: Text(blank == 0
            ? 'Bütün soruları cevapladın. Sınavı bitirip sonucunu görmek istiyor musun?'
            : '$blank soru boş. Yine de sınavı bitirmek istiyor musun?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Sınava dön')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Bitir')),
        ],
      ),
    );
    if (ok == true && mounted) _finish();
  }

  void _finish({bool timeUp = false}) {
    if (finished) return;
    finished = true;
    timer?.cancel();
    final st = AppState.I;
    final cats = <String, List<int>>{};
    final missed = <Missed>[];
    var correct = 0;
    for (var k = 0; k < e.questions.length; k++) {
      final qq = e.questions[k];
      final a = e.answers[k];
      final ok = a == qq.ans;
      if (ok) correct++;
      final c = cats.putIfAbsent(qq.cat, () => [0, 0]);
      c[1]++;
      if (ok) c[0]++;
      if (!ok) missed.add(Missed.of(qq));
      if (a != null || !ok) st.recordAnswer(qq.id, ok);
    }
    final sec = kExamSeconds - e.remaining;
    final r = SetResult(
      day: dayKey(),
      ts: DateTime.now().millisecondsSinceEpoch,
      key: 'deneme',
      name: 'Deneme sınavı',
      correct: correct,
      total: e.questions.length,
      sec: sec.clamp(0, kExamSeconds),
      missed: missed,
      cats: cats,
    );
    st.addResult(r);
    final done = ExamSession(
      questions: e.questions,
      orders: e.orders,
      answers: List.of(e.answers),
      flags: Set.of(e.flags),
      startedAt: e.startedAt,
    );
    st.clearExam();
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => ExamResultScreen(session: done, result: r, timeUp: timeUp),
    ));
  }

  void _openMap() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: C.paper,
      showDragHandle: true,
      builder: (c) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Soru haritası', style: display(20)),
              const SizedBox(height: 4),
              Text('${e.answeredCount} cevaplandı · ${80 - e.answeredCount} boş · ${e.flags.length} işaretli',
                  style: const TextStyle(fontSize: 13, color: C.muted)),
              const SizedBox(height: 12),
              Flexible(
                child: SingleChildScrollView(
                  child: Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      for (var k = 0; k < e.questions.length; k++) _cell(c, k),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              PrimaryButton('Sınavı bitir', icon: Icons.flag_rounded, onPressed: () {
                Navigator.pop(c);
                _confirmFinish();
              }),
            ],
          ),
        ),
      ),
    );
  }

  Widget _cell(BuildContext sheet, int k) {
    final answered = e.answers[k] != null;
    final flagged = e.flags.contains(k);
    final current = k == e.current;
    return SizedBox(
      width: 40,
      height: 40,
      child: Material(
        color: answered ? C.accent : C.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(
            color: current ? C.ink : (flagged ? C.goldLine : C.line),
            width: current || flagged ? 2.5 : 1,
          ),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: () {
            Navigator.pop(sheet);
            _go(k);
          },
          child: Center(
            child: Text('${k + 1}',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  fontFeatures: tabular,
                  color: answered ? Colors.white : C.ink,
                )),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final low = remaining < 600;
    final flagged = e.flags.contains(e.current);
    final last = e.current == e.questions.length - 1;
    return PopScope(
      canPop: true,
      onPopInvokedWithResult: (didPop, _) => AppState.I.saveExam(),
      child: Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(4, 6, 8, 0),
                child: Row(
                  children: [
                    IconButton(
                      tooltip: 'Kaydet ve çık',
                      onPressed: () => Navigator.of(context).maybePop(),
                      icon: const Icon(Icons.close_rounded, color: C.ink),
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(kCat[q.cat] ?? '',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                          Text('Soru ${e.current + 1} / ${e.questions.length}',
                              style: const TextStyle(fontSize: 12, color: C.muted, fontFeatures: tabular)),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                      decoration: BoxDecoration(
                        color: low ? C.badSoft : C.surface,
                        borderRadius: BorderRadius.circular(99),
                        border: Border.all(color: low ? C.bad : C.line),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.hourglass_bottom_rounded, size: 16, color: low ? C.bad : C.ink),
                          const SizedBox(width: 6),
                          Text(_clock(remaining),
                              style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                  fontFeatures: tabular,
                                  color: low ? C.bad : C.ink)),
                        ],
                      ),
                    ),
                    IconButton(
                      tooltip: flagged ? 'İşareti kaldır' : 'Soruyu işaretle',
                      onPressed: _toggleFlag,
                      icon: Icon(flagged ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
                          color: flagged ? C.gold : C.ink),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(3),
                  child: LinearProgressIndicator(
                    value: e.answeredCount / e.questions.length,
                    minHeight: 6,
                    color: C.accent,
                    backgroundColor: C.track,
                  ),
                ),
              ),
              Expanded(
                child: ListView(
                  controller: scroll,
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
                  children: [
                    QuestionView(
                      key: ValueKey('e${e.current}'),
                      q: q,
                      chosen: e.answers[e.current],
                      onSelect: _select,
                    ),
                    const SizedBox(height: 4),
                    const Text('Seçtiğin şıkka tekrar dokunursan seçim kalkar.',
                        style: TextStyle(fontSize: 12, color: C.muted)),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                decoration: const BoxDecoration(
                  color: C.paper,
                  border: Border(top: BorderSide(color: C.line)),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: GhostButton('Önceki',
                          icon: Icons.arrow_back_rounded,
                          onPressed: e.current == 0 ? null : () => _go(e.current - 1)),
                    ),
                    const SizedBox(width: 8),
                    SizedBox(
                      width: 56,
                      height: 52,
                      child: IconButton.outlined(
                        tooltip: 'Soru haritası',
                        onPressed: _openMap,
                        style: IconButton.styleFrom(
                          backgroundColor: C.surface,
                          side: const BorderSide(color: C.line),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        icon: const Icon(Icons.grid_view_rounded, color: C.ink),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: last
                          ? PrimaryButton('Bitir', icon: Icons.flag_rounded, onPressed: _confirmFinish)
                          : PrimaryButton('Sonraki',
                              icon: Icons.arrow_forward_rounded, onPressed: () => _go(e.current + 1)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Sonuç
// ---------------------------------------------------------------------------
class ExamResultScreen extends StatelessWidget {
  final ExamSession session;
  final SetResult result;
  final bool timeUp;
  const ExamResultScreen({super.key, required this.session, required this.result, this.timeUp = false});

  @override
  Widget build(BuildContext context) {
    final r = result;
    final blank = session.answers.where((a) => a == null).length;
    final wrong = r.total - r.correct - blank;
    final score = r.correct * 1.25;
    final scoreText = score == score.roundToDouble()
        ? score.toStringAsFixed(0)
        : score.toStringAsFixed(2).replaceAll('.', ',').replaceAll(RegExp(r'0$'), '');
    return Scaffold(
      appBar: AppBar(title: const Text('Deneme sonucu')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        children: [
          if (timeUp)
            Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: C.goldSoft, borderRadius: BorderRadius.circular(12)),
              child: const Text('Süre doldu; sınav otomatik olarak bitirildi.',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: C.gold)),
            ),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: C.accent, borderRadius: BorderRadius.circular(22)),
            child: Row(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('YDS PUANI', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1, color: C.onAccent)),
                    Text(scoreText, style: display(52, color: Colors.white).copyWith(height: 1.05, fontFeatures: tabular)),
                  ],
                ),
                const Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text('${r.correct} doğru', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Colors.white)),
                    Text('$wrong yanlış · $blank boş', style: const TextStyle(fontSize: 13, color: C.onAccent)),
                    const SizedBox(height: 6),
                    Text('Süre ${fmtSec(r.sec)}', style: const TextStyle(fontSize: 13, color: C.onAccent, fontFeatures: tabular)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const SectionTitle('Bölümlere göre'),
          const SizedBox(height: 10),
          Panel(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
            child: Column(
              children: [
                for (final (cat, _) in kExamPlan)
                  if (r.cats[cat] != null) _catRow(kCat[cat]!, r.cats[cat]![0], r.cats[cat]![1]),
              ],
            ),
          ),
          const SizedBox(height: 20),
          PrimaryButton('Cevapları incele', icon: Icons.fact_check_outlined, onPressed: () {
            Navigator.of(context).push(MaterialPageRoute(builder: (_) => ExamReviewScreen(session: session)));
          }),
          const SizedBox(height: 10),
          GhostButton('Ana sayfa', onPressed: () => Navigator.of(context).pop()),
          const SizedBox(height: 12),
          const Text('Yanlış ve boş bıraktığın sorular akıllı tekrar listene eklendi.',
              textAlign: TextAlign.center, style: TextStyle(fontSize: 13, color: C.muted)),
        ],
      ),
    );
  }

  Widget _catRow(String label, int c, int t) {
    final v = t == 0 ? 0.0 : c / t;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          SizedBox(width: 132, child: Text(label, style: const TextStyle(fontSize: 14))),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: v,
                minHeight: 8,
                color: v >= 0.75 ? C.good : (v < 0.5 ? C.bad : C.accent),
                backgroundColor: C.track,
              ),
            ),
          ),
          SizedBox(
            width: 48,
            child: Text('$c/$t',
                textAlign: TextAlign.right,
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, fontFeatures: tabular)),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// İnceleme
// ---------------------------------------------------------------------------
class ExamReviewScreen extends StatefulWidget {
  final ExamSession session;
  const ExamReviewScreen({super.key, required this.session});

  @override
  State<ExamReviewScreen> createState() => _ExamReviewScreenState();
}

class _ExamReviewScreenState extends State<ExamReviewScreen> {
  String filter = 'wrong'; // all, wrong, blank

  @override
  Widget build(BuildContext context) {
    final e = widget.session;
    final idx = <int>[
      for (var k = 0; k < e.questions.length; k++)
        if (filter == 'all' ||
            (filter == 'wrong' && e.answers[k] != null && e.answers[k] != e.questions[k].ans) ||
            (filter == 'blank' && e.answers[k] == null))
          k,
    ];
    Widget chip(String key, String label) => Padding(
          padding: const EdgeInsets.only(right: 6),
          child: ChoiceChip(
            label: Text(label),
            selected: filter == key,
            showCheckmark: false,
            onSelected: (_) => setState(() => filter = key),
            selectedColor: C.ink,
            backgroundColor: C.surface,
            side: BorderSide(color: filter == key ? C.ink : C.line),
            shape: const StadiumBorder(),
            labelStyle: TextStyle(
                fontFamily: kBody,
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: filter == key ? Colors.white : C.muted),
          ),
        );
    return Scaffold(
      appBar: AppBar(title: const Text('Cevapları incele')),
      body: Column(
        children: [
          SizedBox(
            height: 52,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
              children: [chip('wrong', 'Yanlışlar'), chip('blank', 'Boşlar'), chip('all', 'Tümü')],
            ),
          ),
          Expanded(
            child: idx.isEmpty
                ? const Center(
                    child: Text('Bu grupta soru yok.', style: TextStyle(fontSize: 15, color: C.muted)))
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                    itemCount: idx.length,
                    separatorBuilder: (_, __) => const Padding(
                      padding: EdgeInsets.symmetric(vertical: 18),
                      child: Divider(height: 1, color: C.line),
                    ),
                    itemBuilder: (c, n) {
                      final k = idx[n];
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text('Soru ${k + 1}',
                              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: C.muted)),
                          const SizedBox(height: 6),
                          QuestionView(q: e.questions[k], chosen: e.answers[k], reveal: true),
                        ],
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
