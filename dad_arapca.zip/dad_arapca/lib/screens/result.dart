import 'package:flutter/material.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'quiz.dart';

class ResultScreen extends StatelessWidget {
  final SetResult result;
  final List<Question> missedQuestions;
  const ResultScreen({super.key, required this.result, required this.missedQuestions});

  static const _pace = 135; // YDS: 80 soru / 180 dakika = soru başına 2:15

  @override
  Widget build(BuildContext context) {
    final r = result;
    final avg = r.total == 0 ? 0 : r.sec / r.total;
    final onPace = avg <= _pace;
    final when = DateTime.fromMillisecondsSinceEpoch(r.ts);
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 6, 12, 0),
              child: Row(
                children: [
                  IconButton(
                    tooltip: 'Kapat',
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close_rounded, color: C.ink),
                  ),
                  const Text('Set sonucu', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
                children: [
                  Row(
                    children: [
                      SizedBox(
                        width: 128,
                        height: 128,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            SizedBox(
                              width: 116,
                              height: 116,
                              child: CircularProgressIndicator(
                                value: r.total == 0 ? 0.0 : r.correct / r.total,
                                strokeWidth: 12,
                                strokeCap: StrokeCap.round,
                                color: C.accent,
                                backgroundColor: C.track,
                              ),
                            ),
                            Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text('%${r.pct}', style: display(32).copyWith(fontFeatures: tabular)),
                                Text('${r.correct} / ${r.total}',
                                    style: const TextStyle(
                                        fontSize: 13, color: C.muted, fontFeatures: tabular)),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 18),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('${r.name} tamamlandı', style: display(22)),
                            const SizedBox(height: 6),
                            Text('${trDate(when, weekday: true)} · ${two(when.hour)}:${two(when.minute)}',
                                style: const TextStyle(fontSize: 13, color: C.muted)),
                            const SizedBox(height: 8),
                            onPace
                                ? const Pill('Sınav temposunda', bg: C.goodSoft, fg: C.good)
                                : const Pill('Biraz hızlanmalısın', bg: C.goldSoft, fg: C.gold),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      Expanded(child: _Stat(fmtSec(r.sec), 'Toplam süre')),
                      const SizedBox(width: 8),
                      Expanded(child: _Stat(fmtSec(avg), 'Soru başına')),
                      const SizedBox(width: 8),
                      Expanded(child: _Stat(fmtSec(_pace), 'Sınav temposu', dim: true)),
                    ],
                  ),
                  if (r.cats.length > 1) ...[
                    const SizedBox(height: 20),
                    const SectionTitle('Bölümlere göre'),
                    const SizedBox(height: 10),
                    for (final e in kCat.entries)
                      if (r.cats[e.key] != null) _CatRow(e.value, r.cats[e.key]![0], r.cats[e.key]![1]),
                  ],
                  const SizedBox(height: 20),
                  SectionTitle(r.missed.isEmpty ? 'Hiç yanlışın yok' : 'Kaçırdıkların (${r.missed.length})'),
                  const SizedBox(height: 10),
                  for (final m in r.missed) ...[MissedCard(m), const SizedBox(height: 8)],
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 14),
              child: Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: GhostButton('Ana sayfa', onPressed: () => Navigator.of(context).pop()),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    flex: 3,
                    child: missedQuestions.isEmpty
                        ? PrimaryButton('Yeni set', icon: Icons.refresh_rounded, onPressed: () {
                            final key = kSets.any((s) => s.key == r.key) ? r.key : 'mix';
                            _go(context, key, AppState.I.buildSet(key), setDef(key).title);
                          })
                        : PrimaryButton('Yanlışları çöz', icon: Icons.replay_rounded, onPressed: () {
                            _go(context, 'redo', missedQuestions.map(AppState.I.prep).toList(),
                                'Yanlışları tekrar');
                          }),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _go(BuildContext context, String key, List<Question> qs, String name) {
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => QuizScreen(setKey: key, name: name, questions: qs),
    ));
  }
}

class _Stat extends StatelessWidget {
  final String value, label;
  final bool dim;
  const _Stat(this.value, this.label, {this.dim = false});

  @override
  Widget build(BuildContext context) => Panel(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        radius: 14,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(value,
                style: display(22, color: dim ? C.muted : C.ink).copyWith(fontFeatures: tabular)),
            Text(label, style: const TextStyle(fontSize: 12, color: C.muted)),
          ],
        ),
      );
}

class _CatRow extends StatelessWidget {
  final String label;
  final int c, t;
  const _CatRow(this.label, this.c, this.t);

  @override
  Widget build(BuildContext context) {
    final v = t == 0 ? 0.0 : c / t;
    final color = v == 1 ? C.good : (v == 0 ? C.bad : C.accent);
    return Padding(
      padding: const EdgeInsets.only(bottom: 9),
      child: Row(
        children: [
          SizedBox(width: 104, child: Text(label, style: const TextStyle(fontSize: 14))),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: v,
                minHeight: 8,
                color: color,
                backgroundColor: C.track,
              ),
            ),
          ),
          SizedBox(
            width: 44,
            child: Text('$c/$t',
                textAlign: TextAlign.right,
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    fontFeatures: tabular,
                    color: v == 0 ? C.bad : C.ink)),
          ),
        ],
      ),
    );
  }
}
