import 'package:flutter/material.dart';

import '../models.dart';
import '../notify.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _toggle(BuildContext context, bool on) async {
    final st = AppState.I;
    final messenger = ScaffoldMessenger.of(context);
    try {
      if (on) {
        final granted = await Reminder.requestPermission();
        if (!granted) {
          messenger.showSnackBar(const SnackBar(
              content: Text('Bildirim izni verilmedi. Telefon ayarlarından Dâd Arapça için bildirimlere izin verebilirsin.')));
          return;
        }
        await Reminder.schedule(st.remindHour, st.remindMinute);
        st.setReminder(on: true);
        messenger.showSnackBar(SnackBar(
            content: Text('Her gün ${two(st.remindHour)}:${two(st.remindMinute)} için hatırlatma kuruldu.')));
      } else {
        await Reminder.cancel();
        st.setReminder(on: false);
      }
    } catch (e) {
      final msg = e.toString();
      messenger.showSnackBar(SnackBar(
          content: Text('Hatırlatma ayarlanamadı. (${msg.length > 120 ? msg.substring(0, 120) : msg})')));
    }
  }

  Future<void> _pickTime(BuildContext context) async {
    final st = AppState.I;
    final t = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: st.remindHour, minute: st.remindMinute),
      helpText: 'Hatırlatma saati',
      builder: (c, child) => MediaQuery(
        data: MediaQuery.of(c).copyWith(alwaysUse24HourFormat: true),
        child: child!,
      ),
    );
    if (t == null) return;
    st.setReminder(on: st.remindOn, hour: t.hour, minute: t.minute);
    if (st.remindOn) {
      try {
        await Reminder.schedule(t.hour, t.minute);
      } catch (_) {}
    }
  }

  Future<void> _pickExamDate(BuildContext context) async {
    final st = AppState.I;
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: st.examDate,
      firstDate: DateTime(now.year - 1),
      lastDate: DateTime(now.year + 3, 12, 31),
      helpText: 'YDS Arapça sınav tarihi',
    );
    if (d != null) st.setExamDate(d);
  }

  Future<void> _reset(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('İlerleme sıfırlansın mı?'),
        content: const Text(
            'Bütün sonuçların, tekrar listen, işaretlediğin sorular ve yarım kalan deneme silinir. Kaydettiğin kelimeler kalır. Bu işlem geri alınamaz.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: C.bad),
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Sıfırla'),
          ),
        ],
      ),
    );
    if (ok == true) await AppState.I.resetProgress();
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          return Scaffold(
            appBar: AppBar(title: const Text('Ayarlar')),
            body: ListView(
              padding: EdgeInsets.fromLTRB(16, 4, 16, 32 + MediaQuery.of(context).padding.bottom),
              children: [
                const Text('SINAV', style: labelCaps),
                const SizedBox(height: 8),
                Panel(
                  padding: EdgeInsets.zero,
                  child: ListTile(
                    onTap: () => _pickExamDate(context),
                    title: const Text('Sınav tarihi', style: TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text(st.daysLeft >= 0
                        ? 'Ana sayfadaki geri sayım bu tarihe göre her gün güncellenir.'
                        : 'Sınav tarihi geçti. Bir sonraki sınavın tarihini seç.'),
                    trailing: Text('${trDate(st.examDate)} ${st.examDate.year}',
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                  ),
                ),
                const SizedBox(height: 22),
                const Text('HATIRLATMA', style: labelCaps),
                const SizedBox(height: 8),
                Panel(
                  padding: EdgeInsets.zero,
                  child: Column(
                    children: [
                      SwitchListTile(
                        value: st.remindOn,
                        onChanged: (v) => _toggle(context, v),
                        title: const Text('Günlük çalışma hatırlatması',
                            style: TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: const Text('Her gün aynı saatte bildirim gelir.'),
                        activeColor: C.accent,
                      ),
                      const Divider(height: 1, color: C.sunk),
                      ListTile(
                        enabled: st.remindOn,
                        onTap: () => _pickTime(context),
                        title: const Text('Saat'),
                        trailing: Text('${two(st.remindHour)}:${two(st.remindMinute)}',
                            style: const TextStyle(
                                fontSize: 17, fontWeight: FontWeight.w700, fontFeatures: tabular)),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 22),
                const Text('AKILLI TEKRAR', style: labelCaps),
                const SizedBox(height: 8),
                Panel(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Listede ${st.srsTotal} soru ve kelime var.',
                          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 6),
                      const Text(
                        'Yanlış yaptığın her soru ve kelime ertesi gün tekrar karşına çıkar. Doğru bildikçe aralık uzar: '
                        '1, 3, 7, 16 ve 35 gün. Beş kez üst üste doğru bildiğin öğe listeden çıkar.',
                        style: TextStyle(fontSize: 14, height: 1.5, color: C.muted),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 22),
                const Text('İÇERİK', style: labelCaps),
                const SizedBox(height: 8),
                Panel(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${st.questions.length} soru · ${st.passages.length} parça · ${st.topics.length} konu · ${st.words.length} kelime',
                          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Text('Harf-i cerli kalıplar: ${st.prepVerbs.length} fiil, ${st.prepPhrases.length} ifade',
                          style: const TextStyle(fontSize: 14, color: C.muted)),
                    ],
                  ),
                ),
                const SizedBox(height: 22),
                const Text('VERİLER', style: labelCaps),
                const SizedBox(height: 8),
                GhostButton('İlerlemeyi sıfırla', icon: Icons.restart_alt_rounded, onPressed: () => _reset(context)),
                const SizedBox(height: 28),
                Container(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
                  decoration: BoxDecoration(
                    color: C.goldSoft,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: C.gold.withValues(alpha: 0.25)),
                  ),
                  child: const Column(
                    children: [
                      Icon(Icons.favorite_rounded, color: C.gold, size: 22),
                      SizedBox(height: 10),
                      Text(
                        'Müstefid olmanız dileğiyle.\nHayır dualarınızda unutmayınız.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 15.5, height: 1.5, color: C.ink),
                      ),
                      SizedBox(height: 10),
                      Text(
                        'İsmail Akdoğan',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: C.gold),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  'Dâd Arapça 1.5.1 · Yazı tipleri: Amiri, Figtree, Bricolage Grotesque (SIL Open Font License).',
                  style: TextStyle(fontSize: 12, color: C.muted),
                ),
              ],
            ),
          );
        },
      );
}
