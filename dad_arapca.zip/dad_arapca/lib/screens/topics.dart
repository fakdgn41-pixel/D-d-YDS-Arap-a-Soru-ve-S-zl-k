import 'package:flutter/material.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'quiz.dart';

/// Konular sekmesi: dilbilgisi konuları gruplara ayrılmış liste.
class TopicsScreen extends StatelessWidget {
  const TopicsScreen({super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          final groups = <String, List<Topic>>{};
          for (final t in st.topics) {
            groups.putIfAbsent(t.group, () => []).add(t);
          }
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),
            children: [
              Text('Konular', style: display(26)),
              const SizedBox(height: 4),
              Text('${st.topics.length} dilbilgisi konusu · kural, örnek ve o konunun soruları',
                  style: const TextStyle(fontSize: 13, color: C.muted)),
              for (final g in groups.entries) ...[
                const SizedBox(height: 20),
                Text(g.key.toUpperCase(), style: labelCaps),
                const SizedBox(height: 8),
                Container(
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                    color: C.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: C.line),
                  ),
                  child: Column(
                    children: [
                      for (var i = 0; i < g.value.length; i++)
                        _TopicRow(topic: g.value[i], last: i == g.value.length - 1),
                    ],
                  ),
                ),
              ],
            ],
          );
        },
      );
}

class _TopicRow extends StatelessWidget {
  final Topic topic;
  final bool last;
  const _TopicRow({required this.topic, required this.last});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final n = st.topicQuestions(topic).length;
    final s = st.topicStats(topic);
    final pct = s.seen == 0 ? null : (s.right * 100 / s.seen).round();
    return InkWell(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => TopicScreen(topic: topic))),
      child: Container(
        decoration: BoxDecoration(border: last ? null : const Border(bottom: BorderSide(color: C.sunk))),
        padding: const EdgeInsets.fromLTRB(16, 12, 12, 12),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(topic.title, style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 2),
                  Text('$n soru', style: const TextStyle(fontSize: 13, color: C.muted)),
                ],
              ),
            ),
            if (pct != null) scorePill(pct),
            const SizedBox(width: 4),
            const Icon(Icons.chevron_right_rounded, color: C.faint),
          ],
        ),
      ),
    );
  }
}

/// Tek konu: kurallar, örnekler ve "bu konudan soru çöz".
class TopicScreen extends StatelessWidget {
  final Topic topic;
  const TopicScreen({super.key, required this.topic});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final n = st.topicQuestions(topic).length;
    return Scaffold(
      appBar: AppBar(title: Text(topic.group, style: const TextStyle(fontSize: 15, color: C.muted))),
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                children: [
                  Text(topic.title, style: display(26)),
                  const SizedBox(height: 8),
                  Text(topic.intro, style: const TextStyle(fontSize: 16, height: 1.5)),
                  const SizedBox(height: 8),
                  for (final b in topic.blocks) _block(b),
                ],
              ),
            ),
            if (n > 0)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 14),
                child: SizedBox(
                  width: double.infinity,
                  child: PrimaryButton(
                    'Bu konudan soru çöz ($n)',
                    icon: Icons.play_arrow_rounded,
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => QuizScreen(setKey: 'konu', name: topic.title, questions: st.topicSet(topic)),
                    )),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _block(TopicBlock b) {
    if (b.h != null) {
      return Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 6),
        child: Text(b.h!, style: display(18)),
      );
    }
    if (b.b != null) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.only(top: 9, right: 10),
              child: SizedBox(width: 6, height: 6, child: DecoratedBox(decoration: BoxDecoration(color: C.accent, shape: BoxShape.circle))),
            ),
            Expanded(child: Text(b.b!, style: const TextStyle(fontSize: 15.5, height: 1.5))),
          ],
        ),
      );
    }
    if (b.ar != null) {
      return Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.fromLTRB(14, 4, 14, 10),
        decoration: BoxDecoration(color: C.sunk, borderRadius: BorderRadius.circular(14)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Ar(b.ar!, size: 24, height: 1.8),
            Text(b.tr ?? '', style: const TextStyle(fontSize: 14, color: C.muted)),
          ],
        ),
      );
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(b.t ?? '', style: const TextStyle(fontSize: 15.5, height: 1.5)),
    );
  }
}
