import 'package:flutter/material.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'quiz.dart';

class WordScreen extends StatelessWidget {
  final Word word;
  const WordScreen({super.key, required this.word});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          final w = word;
          final saved = st.saved.contains(w.id);
          final related = st.sameRoot(w);
          final asked = st.seen[w.id] ?? 0;
          final ok = st.right[w.id] ?? 0;
          return Scaffold(
            body: SafeArea(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(4, 6, 8, 0),
                    child: Row(
                      children: [
                        IconButton(
                          tooltip: 'Geri',
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(Icons.arrow_back_rounded, color: C.ink),
                        ),
                        const Spacer(),
                        IconButton.filledTonal(
                          tooltip: saved ? 'Kayıtlılardan çıkar' : 'Kaydet',
                          isSelected: saved,
                          onPressed: () => st.toggleSaved(w.id),
                          style: IconButton.styleFrom(
                            backgroundColor: saved ? C.accentSoft : C.surface,
                            foregroundColor: C.accent,
                          ),
                          icon: Icon(saved ? Icons.bookmark_rounded : Icons.bookmark_border_rounded),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                      children: [
                        Ar(w.ar, size: 54, height: 1.6, align: TextAlign.center),
                        if (w.extra.isNotEmpty)
                          Ar(w.extra, size: 24, height: 1.6, color: C.muted, align: TextAlign.center),
                        const SizedBox(height: 6),
                        Text(w.tr, textAlign: TextAlign.center, style: display(24)),
                        const SizedBox(height: 10),
                        Center(child: posPill(w.pos)),
                        const SizedBox(height: 18),
                        if (w.ex.isNotEmpty) ...[
                          Panel(
                            radius: 18,
                            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                const Text('ÖRNEK CÜMLE', style: labelCaps),
                                Ar(w.ex, size: 24, height: 1.8),
                                Text(w.ext, style: const TextStyle(fontSize: 15, color: C.muted)),
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),
                        ],
                        if (w.root.isNotEmpty)
                          Panel(
                            radius: 18,
                            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                const Text('KÖK', style: labelCaps),
                                Ar(w.rootSpaced, size: 32, height: 1.5, color: C.gold, wordSpacing: 8),
                                if (related.isNotEmpty) ...[
                                  const SizedBox(height: 4),
                                  const Divider(height: 1, color: C.line),
                                  const SizedBox(height: 8),
                                  const Text('AYNI KÖKTEN', style: labelCaps),
                                  for (final r in related)
                                    InkWell(
                                      onTap: () => Navigator.of(context).pushReplacement(
                                          MaterialPageRoute(builder: (_) => WordScreen(word: r))),
                                      child: ConstrainedBox(
                                        constraints: const BoxConstraints(minHeight: 44),
                                        child: Row(
                                          children: [
                                            Expanded(
                                                child: Text(r.tr, style: const TextStyle(fontSize: 15))),
                                            const SizedBox(width: 12),
                                            Flexible(child: Ar(r.ar, size: 23, height: 1.6)),
                                          ],
                                        ),
                                      ),
                                    ),
                                ],
                              ],
                            ),
                          ),
                        const SizedBox(height: 14),
                        Text(
                          asked == 0
                              ? 'Bu kelime testlerde henüz çıkmadı.'
                              : 'Testlerde $asked kez çıktı · $ok doğru, ${asked - ok} yanlış',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 13, color: C.muted, fontFeatures: tabular),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 14),
                    child: SizedBox(
                      width: double.infinity,
                      child: PrimaryButton(
                        related.isEmpty ? 'Bu kelimeyle test çöz' : 'Bu kökten kelimelerle test çöz',
                        onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => QuizScreen(
                              setKey: 'kok', name: 'Kök testi', questions: st.rootSet(w)),
                        )),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
}
