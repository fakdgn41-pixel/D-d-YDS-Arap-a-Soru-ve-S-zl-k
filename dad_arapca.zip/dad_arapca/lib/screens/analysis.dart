import 'package:flutter/material.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'quiz.dart';
import 'topics.dart';

/// Zayıf nokta analizi: tahmini puan, bölüm başarıları, zorlanılan konular, deneme geçmişi.
class AnalysisView extends StatelessWidget {
  const AnalysisView({super.key});

  String _score(double s) {
    final r = (s * 4).round() / 4; // 1,25'in katlarına yakın gösterim
    final t = r.toStringAsFixed(2).replaceAll('.', ',');
    return t.endsWith(',00') ? t.substring(0, t.length - 3) : (t.endsWith('0') ? t.substring(0, t.length - 1) : t);
  }

  void _practice(BuildContext context, String cat) {
    final def = setDef(cat);
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => QuizScreen(setKey: cat, name: def.title, questions: AppState.I.buildSet(cat)),
    ));
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          final stats = st.catStats();
          final pred = st.predictedScore();
          final rows = kCat.keys
              .where((c) => stats[c] != null && stats[c]!.t > 0)
              .map((c) => (cat: c, c: stats[c]!.c, t: stats[c]!.t))
              .toList()
            ..sort((a, b) => (a.c / a.t).compareTo(b.c / b.t));
          final untouched = kCat.keys.where((c) => stats[c] == null || stats[c]!.t == 0).toList();
          final weakTopics = st.topics
              .map((t) => (topic: t, s: st.topicStats(t)))
              .where((x) => x.s.seen >= 3)
              .toList()
            ..sort((a, b) => (a.s.right / a.s.seen).compareTo(b.s.right / b.s.seen));
          final exams = st.examResults.reversed.take(6).toList();

          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            children: [
              // Tahmini puan
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(color: C.accent, borderRadius: BorderRadius.circular(22)),
                child: pred == null
                    ? const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('TAHMİNİ YDS PUANI',
                              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1, color: C.onAccent)),
                          SizedBox(height: 6),
                          Text('Tahmin için en az 30 soru çöz. Ne kadar çok bölümden soru çözersen tahmin o kadar isabetli olur.',
                              style: TextStyle(fontSize: 15, color: Colors.white, height: 1.45)),
                        ],
                      )
                    : Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('TAHMİNİ YDS PUANI',
                                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1, color: C.onAccent)),
                                Text(_score(pred.score),
                                    style: display(52, color: Colors.white).copyWith(height: 1.05, fontFeatures: tabular)),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 150,
                            child: Text(
                              '${pred.answered} cevaba göre, bölüm başarıların 80 soruluk sınav düzenine uygulandı.',
                              style: const TextStyle(fontSize: 12.5, color: C.onAccent, height: 1.4),
                            ),
                          ),
                        ],
                      ),
              ),
              const SizedBox(height: 20),

              // Bölümler
              const SectionTitle('Bölümlere göre başarı'),
              const SizedBox(height: 4),
              const Text('En zayıftan en güçlüye. Bir bölüme dokunarak hemen çalışabilirsin.',
                  style: TextStyle(fontSize: 13, color: C.muted)),
              const SizedBox(height: 10),
              if (rows.isEmpty)
                const Panel(child: Text('Henüz sonuç yok. Birkaç set çözdüğünde bölüm başarıların burada görünür.',
                    style: TextStyle(fontSize: 14.5, color: C.muted, height: 1.45)))
              else
                Container(
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                    color: C.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: C.line),
                  ),
                  child: Column(
                    children: [
                      for (var i = 0; i < rows.length; i++)
                        _CatRow(
                          label: kCat[rows[i].cat]!,
                          c: rows[i].c,
                          t: rows[i].t,
                          weakest: i == 0 && rows.length > 1,
                          last: i == rows.length - 1,
                          onTap: () => _practice(context, rows[i].cat),
                        ),
                    ],
                  ),
                ),
              if (untouched.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text('Henüz denenmeyen: ${untouched.map((c) => kCat[c]).join(', ')}',
                    style: const TextStyle(fontSize: 13, color: C.muted)),
              ],

              // Konular
              if (weakTopics.isNotEmpty) ...[
                const SizedBox(height: 22),
                const SectionTitle('Zorlandığın konular'),
                const SizedBox(height: 10),
                for (final x in weakTopics.take(3)) ...[
                  Material(
                    color: C.surface,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14), side: const BorderSide(color: C.line)),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () => Navigator.of(context)
                          .push(MaterialPageRoute(builder: (_) => TopicScreen(topic: x.topic))),
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(14, 12, 10, 12),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(x.topic.title,
                                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                                  Text('${x.s.right}/${x.s.seen} doğru · konu anlatımını aç',
                                      style: const TextStyle(fontSize: 13, color: C.muted)),
                                ],
                              ),
                            ),
                            scorePill((x.s.right * 100 / x.s.seen).round()),
                            const Icon(Icons.chevron_right_rounded, color: C.faint),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
              ],

              // Denemeler
              const SizedBox(height: 22),
              const SectionTitle('Deneme sınavları'),
              const SizedBox(height: 10),
              if (exams.isEmpty)
                const Panel(child: Text('Henüz deneme sınavı çözmedin. Ana sayfadaki “Deneme sınavı” kartından başlayabilirsin.',
                    style: TextStyle(fontSize: 14.5, color: C.muted, height: 1.45)))
              else
                Panel(
                  padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
                  child: Column(
                    children: [
                      for (final r in exams)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Row(
                            children: [
                              SizedBox(
                                width: 70,
                                child: Text(trDate(parseDay(r.day)),
                                    style: const TextStyle(fontSize: 13, color: C.muted)),
                              ),
                              Expanded(
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(4),
                                  child: LinearProgressIndicator(
                                    value: r.correct / r.total,
                                    minHeight: 10,
                                    color: C.accent,
                                    backgroundColor: C.track,
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 56,
                                child: Text(_score(r.correct * 1.25),
                                    textAlign: TextAlign.right,
                                    style: const TextStyle(
                                        fontSize: 15, fontWeight: FontWeight.w800, fontFeatures: tabular)),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
            ],
          );
        },
      );
}

class _CatRow extends StatelessWidget {
  final String label;
  final int c, t;
  final bool weakest, last;
  final VoidCallback onTap;
  const _CatRow({
    required this.label,
    required this.c,
    required this.t,
    required this.weakest,
    required this.last,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final v = c / t;
    final pct = (v * 100).round();
    final color = v >= 0.75 ? C.good : (v < 0.5 ? C.bad : C.accent);
    return InkWell(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: weakest ? C.badSoft : null,
          border: last ? null : const Border(bottom: BorderSide(color: C.sunk)),
        ),
        padding: const EdgeInsets.fromLTRB(14, 10, 10, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(label, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600)),
                ),
                Text('$c/$t',
                    style: const TextStyle(fontSize: 13, color: C.muted, fontFeatures: tabular)),
                const SizedBox(width: 10),
                SizedBox(
                  width: 44,
                  child: Text('%$pct',
                      textAlign: TextAlign.right,
                      style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w800, color: color, fontFeatures: tabular)),
                ),
                const Icon(Icons.chevron_right_rounded, color: C.faint, size: 20),
              ],
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(value: v, minHeight: 7, color: color, backgroundColor: C.track),
                  ),
                ),
                if (weakest) ...[
                  const SizedBox(width: 10),
                  const Text('Şimdi çalış', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800, color: C.bad)),
                  const SizedBox(width: 20),
                ] else
                  const SizedBox(width: 20),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
