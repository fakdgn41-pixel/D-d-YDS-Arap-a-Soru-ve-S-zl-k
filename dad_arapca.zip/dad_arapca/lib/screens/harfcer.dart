import 'package:flutter/material.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'cards.dart';
import 'quiz.dart';
import 'topics.dart';
import 'word.dart';

/// Harf-i cerli fiiller ve kalıp ifadeler: liste, test, kartlar.
class HarfcerScreen extends StatefulWidget {
  const HarfcerScreen({super.key});

  @override
  State<HarfcerScreen> createState() => _HarfcerScreenState();
}

class _HarfcerScreenState extends State<HarfcerScreen> {
  int view = 0; // 0: fiil + edat, 1: kalıp ifadeler
  String? prep; // null: hepsi

  void _test(BuildContext context) {
    final qs = AppState.I.buildSet('harfcer');
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => QuizScreen(setKey: 'harfcer', name: 'Harf-i cerli kalıplar', questions: qs),
    ));
  }

  void _cards(BuildContext context) {
    final words = AppState.I.cardSession('h');
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => CardSessionScreen(title: 'Harf-i cerli kalıplar', words: words),
    ));
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          final topic = st.prepTopic;
          final score = st.lastScore('harfcer');
          final due = st.deckDue('h');
          final list = view == 0
              ? st.prepVerbs.where((w) => prep == null || w.tag == prep).toList()
              : st.prepPhrases;
          return Scaffold(
            appBar: AppBar(title: const Text('Harf-i cerli kalıplar')),
            body: ListView(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              children: [
                const Text(
                  'Fiillerin hangi edatla kullanıldığını ve edat değişince anlamın nasıl değiştiğini öğren. '
                  'Sınavda sık çıkan harf-i cerli kalıp ifadeler de burada.',
                  style: TextStyle(fontSize: 14.5, color: C.muted, height: 1.5),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: PrimaryButton('Test çöz', icon: Icons.play_arrow_rounded, onPressed: () => _test(context)),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: GhostButton('Kartlar', icon: Icons.style_outlined, onPressed: () => _cards(context)),
                    ),
                  ],
                ),
                if (score != null || due > 0) ...[
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 6,
                    children: [
                      if (score != null) Pill('Son test %$score', bg: C.accentSoft, fg: C.accentDark),
                      if (due > 0) Pill('$due kart tekrar bekliyor', bg: C.goldSoft, fg: C.gold),
                    ],
                  ),
                ],
                if (topic != null) ...[
                  const SizedBox(height: 6),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton.icon(
                      onPressed: () => Navigator.of(context)
                          .push(MaterialPageRoute(builder: (_) => TopicScreen(topic: topic))),
                      icon: const Icon(Icons.school_outlined, size: 19),
                      label: const Text('Konu anlatımı'),
                    ),
                  ),
                ],
                const SizedBox(height: 8),
                SegmentedButton<int>(
                  segments: const [
                    ButtonSegment(value: 0, label: Text('Fiil + edat')),
                    ButtonSegment(value: 1, label: Text('Kalıp ifadeler')),
                  ],
                  selected: {view},
                  showSelectedIcon: false,
                  onSelectionChanged: (v) => setState(() => view = v.first),
                ),
                if (view == 0) ...[
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 46,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        _chip(null, 'Tümü', ar: false),
                        for (final e in kPreps.entries) _chip(e.key, e.value),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 10),
                Container(
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                    color: C.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: C.line),
                  ),
                  child: Column(
                    children: [
                      for (var i = 0; i < list.length; i++) _row(context, list[i], i == list.length - 1),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      );

  Widget _chip(String? key, String label, {bool ar = true}) {
    final sel = prep == key;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(
          label,
          textDirection: ar ? TextDirection.rtl : TextDirection.ltr,
          style: ar
              ? TextStyle(fontFamily: kArabic, letterSpacing: 0, fontSize: 19, height: 1.2, color: sel ? Colors.white : C.ink)
              : TextStyle(fontWeight: FontWeight.w600, color: sel ? Colors.white : C.ink),
        ),
        selected: sel,
        showCheckmark: false,
        selectedColor: C.ink,
        backgroundColor: C.surface,
        side: BorderSide(color: sel ? C.ink : C.line),
        onSelected: (_) => setState(() => prep = key),
      ),
    );
  }

  Widget _row(BuildContext context, Word w, bool last) => InkWell(
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => WordScreen(word: w))),
        child: Container(
          decoration: BoxDecoration(border: last ? null : const Border(bottom: BorderSide(color: C.sunk))),
          padding: const EdgeInsets.fromLTRB(16, 6, 12, 10),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Ar(w.ar, size: 24, height: 1.7),
                    Text(w.tr, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              const Icon(Icons.chevron_right_rounded, color: C.faint),
            ],
          ),
        ),
      );
}
