import 'package:flutter/material.dart';

import '../export.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

class DailyScreen extends StatefulWidget {
  const DailyScreen({super.key});

  @override
  State<DailyScreen> createState() => _DailyScreenState();
}

class _DailyScreenState extends State<DailyScreen> {
  String? day;
  bool exporting = false;

  Future<void> _export() async {
    setState(() => exporting = true);
    try {
      await shareExcel();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Excel dosyası hazırlanamadı. Tekrar dene.')),
        );
      }
    } finally {
      if (mounted) setState(() => exporting = false);
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AppState.I,
        builder: (context, _) {
          final st = AppState.I;
          final days = st.days;
          final header = Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: Row(
              children: [
                Expanded(child: Text('Sonuçlar', style: display(26))),
                if (days.isNotEmpty)
                  OutlinedButton.icon(
                    onPressed: exporting ? null : _export,
                    style: OutlinedButton.styleFrom(
                      backgroundColor: C.surface,
                      foregroundColor: C.ink,
                      side: const BorderSide(color: C.line),
                      minimumSize: const Size(0, 44),
                      textStyle: const TextStyle(
                          fontFamily: kBody, fontSize: 14, fontWeight: FontWeight.w700),
                    ),
                    icon: exporting
                        ? const SizedBox(
                            width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.file_download_outlined, size: 19),
                    label: const Text('Excel olarak paylaş'),
                  ),
              ],
            ),
          );

          if (days.isEmpty) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                header,
                const Padding(
                  padding: EdgeInsets.fromLTRB(32, 60, 32, 0),
                  child: Text(
                    'Henüz çözülmüş set yok. Pratik sekmesinden bir set çözdüğünde günün tablosu burada oluşur.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 15, color: C.muted, height: 1.5),
                  ),
                ),
              ],
            );
          }

          final sel = (day != null && days.contains(day)) ? day! : days.first;
          final sets = st.resultsOn(sel);
          final tot = st.dayTotals(sel);
          final pct = tot.total == 0 ? 0 : (tot.correct * 100 / tot.total).round();
          final today = dayKey();

          return ListView(
            padding: const EdgeInsets.only(bottom: 24),
            children: [
              header,
              SizedBox(
                height: 56,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
                  children: [
                    for (final d in days.take(30))
                      Padding(
                        padding: const EdgeInsets.only(right: 6),
                        child: ChoiceChip(
                          label: Text(d == today ? 'Bugün' : trDate(parseDay(d))),
                          selected: d == sel,
                          showCheckmark: false,
                          onSelected: (_) => setState(() => day = d),
                          selectedColor: C.ink,
                          backgroundColor: C.surface,
                          side: BorderSide(color: d == sel ? C.ink : C.line),
                          shape: const StadiumBorder(),
                          labelStyle: TextStyle(
                            fontFamily: kBody,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: d == sel ? Colors.white : C.muted,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(trDate(parseDay(sel), weekday: true),
                        style: const TextStyle(fontSize: 13, color: C.muted)),
                    const SizedBox(height: 8),
                    Panel(
                      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
                      child: Row(
                        children: [
                          _Sum('${tot.sets}', 'set'),
                          _Sum('${tot.correct}/${tot.total}', 'doğru', divider: true),
                          _Sum('%$pct', 'başarı', divider: true, color: C.accent),
                          _Sum(fmtSec(tot.sec), 'süre', divider: true),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    _WeekChart(endDay: sel),
                    const SizedBox(height: 12),
                    _SetTable(sets: sets, tot: tot, pct: pct),
                    if (sets.any((r) => r.missed.isNotEmpty)) ...[
                      const SizedBox(height: 20),
                      SectionTitle('Bu günün yanlışları (${tot.total - tot.correct})'),
                      const SizedBox(height: 10),
                      for (final r in sets)
                        for (final m in r.missed) ...[
                          MissedCard(m, prefix: r.name),
                          const SizedBox(height: 8),
                        ],
                    ],
                  ],
                ),
              ),
            ],
          );
        },
      );
}

class _Sum extends StatelessWidget {
  final String value, label;
  final bool divider;
  final Color color;
  const _Sum(this.value, this.label, {this.divider = false, this.color = C.ink});

  @override
  Widget build(BuildContext context) => Expanded(
        child: Container(
          decoration: BoxDecoration(
            border: divider ? const Border(left: BorderSide(color: C.sunk)) : null,
          ),
          child: Column(
            children: [
              FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(value, style: display(21, color: color).copyWith(fontFeatures: tabular)),
              ),
              Text(label, style: const TextStyle(fontSize: 12, color: C.muted)),
            ],
          ),
        ),
      );
}

class _WeekChart extends StatelessWidget {
  final String endDay;
  const _WeekChart({required this.endDay});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final end = parseDay(endDay);
    final days = [for (var k = 6; k >= 0; k--) end.subtract(Duration(days: k))];
    final vals = days.map((d) {
      final x = st.dayTotals(dayKey(d));
      return x.total == 0 ? null : (x.correct * 100 / x.total).round();
    }).toList();
    final present = vals.whereType<int>().toList();
    const maxH = 90.0;

    return Panel(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text('Son 7 gün başarı', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
              ),
              if (present.length > 1)
                Text('%${present.first} → %${present.last}',
                    style: const TextStyle(fontSize: 12, color: C.muted, fontFeatures: tabular)),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: maxH + 22,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (var k = 0; k < 7; k++) ...[
                  if (k > 0) const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(vals[k] == null ? '–' : '${vals[k]}',
                            style: TextStyle(
                              fontSize: 11,
                              fontFeatures: tabular,
                              fontWeight: k == 6 ? FontWeight.w800 : FontWeight.w400,
                              color: k == 6 ? C.accent : C.muted,
                            )),
                        const SizedBox(height: 3),
                        Container(
                          height: vals[k] == null ? 2.0 : (maxH * vals[k]! / 100).clamp(4.0, maxH).toDouble(),
                          decoration: BoxDecoration(
                            color: vals[k] == null ? C.line : (k == 6 ? C.accent : C.accentBar),
                            borderRadius: vals[k] == null
                                ? null
                                : const BorderRadius.vertical(top: Radius.circular(6)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
          Container(height: 1, color: C.line),
          const SizedBox(height: 6),
          Row(
            children: [
              for (var k = 0; k < 7; k++) ...[
                if (k > 0) const SizedBox(width: 10),
                Expanded(
                  child: Text(kWeekShort[days[k].weekday - 1],
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: k == 6 ? FontWeight.w800 : FontWeight.w400,
                        color: k == 6 ? C.ink : C.muted,
                      )),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

class _SetTable extends StatelessWidget {
  final List<SetResult> sets;
  final ({int sets, int correct, int total, int sec}) tot;
  final int pct;
  const _SetTable({required this.sets, required this.tot, required this.pct});

  @override
  Widget build(BuildContext context) {
    const head = TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 0.7, color: C.muted);
    TextStyle cell({bool bold = false, Color color = C.ink}) => TextStyle(
        fontSize: 14,
        fontFeatures: tabular,
        fontWeight: bold ? FontWeight.w800 : FontWeight.w400,
        color: color);
    Color pc(int p) => p >= 75 ? C.good : (p < 50 ? C.bad : C.ink);

    Widget row(List<Widget> cells, {Color? bg, bool top = true}) => Container(
          decoration: BoxDecoration(
            color: bg,
            border: top ? const Border(top: BorderSide(color: C.sunk)) : null,
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          child: Row(children: cells),
        );
    Widget c(String s, TextStyle st, {int flex = 2, bool left = false}) => Expanded(
          flex: flex,
          child: Text(s, textAlign: left ? TextAlign.left : TextAlign.right, style: st),
        );

    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: C.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: C.line),
      ),
      child: Column(
        children: [
          row([
            c('SET', head, flex: 5, left: true),
            c('DOĞRU', head),
            c('%', head),
            c('SÜRE', head),
          ], bg: C.soft, top: false),
          for (final r in sets)
            row([
              c(r.name, cell(), flex: 5, left: true),
              c('${r.correct}/${r.total}', cell()),
              c('${r.pct}', cell(bold: true, color: pc(r.pct))),
              c(fmtSec(r.sec), cell()),
            ]),
          row([
            c('Gün toplamı', cell(bold: true), flex: 5, left: true),
            c('${tot.correct}/${tot.total}', cell(bold: true)),
            c('$pct', cell(bold: true)),
            c(fmtSec(tot.sec), cell(bold: true)),
          ], bg: C.soft),
        ],
      ),
    );
  }
}
