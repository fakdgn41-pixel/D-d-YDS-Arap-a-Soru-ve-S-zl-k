import 'dart:async';

import 'package:flutter/material.dart';

import '../models.dart';
import '../question_view.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'result.dart';

class QuizScreen extends StatefulWidget {
  final String setKey, name;
  final List<Question> questions;
  const QuizScreen({super.key, required this.setKey, required this.name, required this.questions});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int i = 0;
  int? chosen; // seçilen şık; null + answered = boş bırakıldı
  bool answered = false;
  final List<bool> results = [];
  final List<Question> missed = [];
  final Map<String, List<int>> cats = {};
  final DateTime start = DateTime.now();
  int elapsed = 0;
  Timer? timer;
  final scroll = ScrollController();

  List<Question> get qs => widget.questions;
  Question get q => qs[i];
  bool get last => i == qs.length - 1;

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => elapsed = DateTime.now().difference(start).inSeconds);
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    scroll.dispose();
    super.dispose();
  }

  void answer(int? idx) {
    if (answered) return;
    final ok = idx == q.ans;
    setState(() {
      answered = true;
      chosen = idx;
      results.add(ok);
      final c = cats.putIfAbsent(q.cat, () => [0, 0]);
      c[1]++;
      if (ok) c[0]++;
      if (!ok) missed.add(q);
    });
    AppState.I.recordAnswer(q.id, ok);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) {
        scroll.animateTo(scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 320), curve: Curves.easeOut);
      }
    });
  }

  void next() {
    if (last) {
      finish();
      return;
    }
    // Aynı parçanın sonraki sorusunda parça yerinde kalsın diye en başa dönülür.
    setState(() {
      i++;
      answered = false;
      chosen = null;
    });
    if (scroll.hasClients) scroll.jumpTo(0);
  }

  void finish() {
    timer?.cancel();
    if (results.isEmpty) {
      Navigator.of(context).pop();
      return;
    }
    final sec = DateTime.now().difference(start).inSeconds;
    final r = SetResult(
      day: dayKey(),
      ts: DateTime.now().millisecondsSinceEpoch,
      key: widget.setKey,
      name: widget.name,
      correct: results.where((x) => x).length,
      total: results.length,
      sec: sec,
      missed: missed.map(Missed.of).toList(),
      cats: cats,
    );
    AppState.I.addResult(r);
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => ResultScreen(result: r, missedQuestions: List.of(missed)),
    ));
  }

  Future<void> confirmExit() async {
    if (results.isEmpty) {
      Navigator.of(context).pop();
      return;
    }
    final end = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Seti bitirmek istiyor musun?'),
        content: Text('${results.length} soru cevapladın. Bu sorular sonuçlarına kaydedilecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Devam et')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Bitir ve kaydet')),
        ],
      ),
    );
    if (end == true && mounted) finish();
  }

  @override
  Widget build(BuildContext context) {
    if (qs.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: Text(widget.name)),
        body: const Center(
          child: Padding(
            padding: EdgeInsets.all(32),
            child: Text('Bu sette şu an çözülecek soru yok.',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 16, color: C.muted)),
          ),
        ),
      );
    }
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) confirmExit();
      },
      child: Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              _topBar(),
              _progress(),
              Expanded(
                child: ListView(
                  controller: scroll,
                  padding: const EdgeInsets.fromLTRB(16, 18, 16, 20),
                  children: [
                    QuestionView(
                      key: ValueKey('q$i'),
                      q: q,
                      chosen: chosen,
                      reveal: answered,
                      onSelect: answered ? null : answer,
                    ),
                  ],
                ),
              ),
              _bottomBar(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _topBar() => Padding(
        padding: const EdgeInsets.fromLTRB(4, 6, 12, 0),
        child: Row(
          children: [
            IconButton(
              tooltip: 'Seti bitir',
              onPressed: confirmExit,
              icon: const Icon(Icons.close_rounded, color: C.ink),
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                  Text('Soru ${i + 1} / ${qs.length}',
                      style: const TextStyle(fontSize: 12, color: C.muted, fontFeatures: tabular)),
                ],
              ),
            ),
            const HarakatToggle(),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                color: C.surface,
                borderRadius: BorderRadius.circular(99),
                border: Border.all(color: C.line),
              ),
              child: Row(
                children: [
                  const Icon(Icons.timer_outlined, size: 16, color: C.ink),
                  const SizedBox(width: 6),
                  Text(fmtSec(elapsed),
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, fontFeatures: tabular)),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _progress() {
    final n = qs.length;
    if (n > 24) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(3),
          child: LinearProgressIndicator(
            value: results.length / n,
            minHeight: 6,
            color: C.accent,
            backgroundColor: C.track,
          ),
        ),
      );
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Semantics(
        label: 'İlerleme: ${results.length} soru cevaplandı, ${results.where((x) => x).length} doğru',
        child: Row(
          children: [
            for (var k = 0; k < n; k++) ...[
              if (k > 0) const SizedBox(width: 4),
              Expanded(
                child: Container(
                  height: 6,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(3),
                    color: k < results.length
                        ? (results[k] ? C.good : C.bad)
                        : (k == i ? C.accent : C.track),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _bottomBar() {
    final st = AppState.I;
    final w = q.word;
    final Widget content;
    if (answered) {
      content = PrimaryButton(last ? 'Sonucu gör' : 'Sonraki soru',
          icon: Icons.arrow_forward_rounded, onPressed: next);
    } else {
      final marked = w != null ? st.saved.contains(w.id) : st.flagged.contains(q.id);
      content = Row(
        children: [
          Expanded(
            child: GhostButton(
              w != null ? (marked ? 'Kaydedildi' : 'Kelimeyi kaydet') : (marked ? 'İşaretlendi' : 'İşaretle'),
              icon: marked ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
              onPressed: () {
                if (w != null) {
                  st.toggleSaved(w.id);
                } else {
                  st.toggleFlag(q.id);
                }
                setState(() {});
              },
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: GhostButton('Boş bırak',
                icon: Icons.arrow_forward_rounded, iconAfter: true, onPressed: () => answer(null)),
          ),
        ],
      );
    }
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
      decoration: const BoxDecoration(
        color: C.paper,
        border: Border(top: BorderSide(color: C.line)),
      ),
      child: content,
    );
  }
}
