import 'dart:async';

import 'package:flutter/material.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'result.dart';
import 'word.dart';

class QuizScreen extends StatefulWidget {
  final String setKey, name;
  final List<Question> questions;
  const QuizScreen({super.key, required this.setKey, required this.name, required this.questions});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int i = 0;
  int? chosen; // seçilen şık; null + answered = boş bırakıldı
  bool answered = false;
  final List<bool> results = [];
  final List<Question> missed = [];
  final Map<String, List<int>> cats = {};
  final DateTime start = DateTime.now();
  int elapsed = 0;
  Timer? timer;
  final scroll = ScrollController();

  List<Question> get qs => widget.questions;
  Question get q => qs[i];
  bool get last => i == qs.length - 1;

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => elapsed = DateTime.now().difference(start).inSeconds);
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    scroll.dispose();
    super.dispose();
  }

  void answer(int? idx) {
    if (answered) return;
    final ok = idx == q.ans;
    setState(() {
      answered = true;
      chosen = idx;
      results.add(ok);
      final c = cats.putIfAbsent(q.cat, () => [0, 0]);
      c[1]++;
      if (ok) c[0]++;
      if (!ok) missed.add(q);
    });
    AppState.I.recordAnswer(q.id, ok);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) {
        scroll.animateTo(scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 320), curve: Curves.easeOut);
      }
    });
  }

  void next() {
    if (last) {
      finish();
      return;
    }
    setState(() {
      i++;
      answered = false;
      chosen = null;
    });
    if (scroll.hasClients) scroll.jumpTo(0);
  }

  void finish() {
    timer?.cancel();
    if (results.isEmpty) {
      Navigator.of(context).pop();
      return;
    }
    final sec = DateTime.now().difference(start).inSeconds;
    final r = SetResult(
      day: dayKey(),
      ts: DateTime.now().millisecondsSinceEpoch,
      key: widget.setKey,
      name: widget.name,
      correct: results.where((x) => x).length,
      total: results.length,
      sec: sec,
      missed: missed.map(Missed.of).toList(),
      cats: cats,
    );
    AppState.I.addResult(r);
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => ResultScreen(result: r, missedQuestions: List.of(missed)),
    ));
  }

  Future<void> confirmExit() async {
    if (results.isEmpty) {
      Navigator.of(context).pop();
      return;
    }
    final end = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Seti bitirmek istiyor musun?'),
        content: Text('${results.length} soru cevapladın. Bu sorular sonuçlarına kaydedilecek.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Devam et')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Bitir ve kaydet')),
        ],
      ),
    );
    if (end == true && mounted) finish();
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop) confirmExit();
        },
        child: Scaffold(
          body: SafeArea(
            child: Column(
              children: [
                _topBar(),
                _progress(),
                Expanded(
                  child: ListView(
                    controller: scroll,
                    padding: const EdgeInsets.fromLTRB(16, 18, 16, 20),
                    children: [
                      Text(q.kind.toUpperCase(),
                          style: labelCaps.copyWith(color: C.gold, letterSpacing: 1)),
                      const SizedBox(height: 8),
                      Text(q.prompt,
                          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, height: 1.4)),
                      const SizedBox(height: 14),
                      _stem(),
                      const SizedBox(height: 14),
                      for (var j = 0; j < q.opts.length; j++) ...[
                        _option(j),
                        const SizedBox(height: 8),
                      ],
                      if (answered) ...[const SizedBox(height: 6), _feedback()],
                    ],
                  ),
                ),
                _bottomBar(),
              ],
            ),
          ),
        ),
      );

  Widget _topBar() => Padding(
        padding: const EdgeInsets.fromLTRB(4, 6, 12, 0),
        child: Row(
          children: [
            IconButton(
              tooltip: 'Seti bitir',
              onPressed: confirmExit,
              icon: const Icon(Icons.close_rounded, color: C.ink),
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                  Text('Soru ${i + 1} / ${qs.length}',
                      style: const TextStyle(fontSize: 12, color: C.muted, fontFeatures: tabular)),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                color: C.surface,
                borderRadius: BorderRadius.circular(99),
                border: Border.all(color: C.line),
              ),
              child: Row(
                children: [
                  const Icon(Icons.timer_outlined, size: 16, color: C.ink),
                  const SizedBox(width: 6),
                  Text(fmtSec(elapsed),
                      style: const TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w700, fontFeatures: tabular)),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _progress() {
    final n = qs.length;
    if (n > 24) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(3),
          child: LinearProgressIndicator(
            value: results.length / n,
            minHeight: 6,
            color: C.accent,
            backgroundColor: C.track,
          ),
        ),
      );
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Semantics(
        label: 'İlerleme: ${results.length} soru cevaplandı, ${results.where((x) => x).length} doğru',
        child: Row(
          children: [
            for (var k = 0; k < n; k++) ...[
              if (k > 0) const SizedBox(width: 4),
              Expanded(
                child: Container(
                  height: 6,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(3),
                    color: k < results.length
                        ? (results[k] ? C.good : C.bad)
                        : (k == i ? C.accent : C.track),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _stem() {
    final children = <Widget>[];
    for (final l in q.lines) {
      if (l.tr != null) {
        children.add(Text(l.tr!, style: const TextStyle(fontSize: 16.5, height: 1.5)));
      } else if (l.num != null) {
        children.add(Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 30,
              child: Padding(
                padding: const EdgeInsets.only(top: 14),
                child: Text(l.num!,
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: C.muted)),
              ),
            ),
            Expanded(child: ArStem(l.ar ?? '', size: 22)),
          ],
        ));
      } else if (l.passage) {
        children.add(Container(
          padding: const EdgeInsets.only(bottom: 10),
          margin: const EdgeInsets.only(bottom: 6),
          decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: C.line))),
          child: ArStem(l.ar ?? '', size: 22),
        ));
      } else {
        children.add(ArStem(l.ar ?? '', target: q.target, size: 26));
      }
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(color: C.sunk, borderRadius: BorderRadius.circular(18)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children),
    );
  }

  Widget _option(int j) {
    final isAns = j == q.ans;
    final isChosen = j == chosen;
    Color bg = C.surface, border = C.line, letterBg = C.sunk, letterFg = C.muted, text = C.ink;
    double bw = 1;
    String? tag;
    if (answered) {
      if (isAns) {
        bg = C.goodSoft;
        border = C.good;
        letterBg = C.good;
        letterFg = Colors.white;
        bw = 1.5;
        tag = 'Doğru cevap';
      } else if (isChosen) {
        bg = C.badSoft;
        border = C.bad;
        letterBg = C.bad;
        letterFg = Colors.white;
        bw = 1.5;
        tag = 'Senin cevabın';
      } else {
        text = C.faint;
        letterBg = C.soft;
        letterFg = C.faint;
      }
    }
    final letter = String.fromCharCode(65 + j);
    return Material(
      color: bg,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: border, width: bw),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: answered ? null : () => answer(j),
        child: ConstrainedBox(
          constraints: const BoxConstraints(minHeight: 56),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 6, 16, 6),
            child: Row(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: letterBg, shape: BoxShape.circle),
                  child: Text(letter,
                      style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: letterFg)),
                ),
                const SizedBox(width: 12),
                if (tag != null) ...[
                  Text(tag,
                      style: TextStyle(
                          fontSize: 12, fontWeight: FontWeight.w700, color: isAns ? C.good : C.bad)),
                  const SizedBox(width: 10),
                ],
                Expanded(
                  child: q.optAr
                      ? Ar(q.opts[j], size: 24, color: text, height: 1.7)
                      : Text(q.opts[j], style: TextStyle(fontSize: 15.5, height: 1.4, color: text)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _feedback() {
    final ok = chosen == q.ans;
    final skipped = chosen == null;
    final color = ok ? C.good : C.bad;
    final w = q.word;
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: C.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: C.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(height: 3, color: color),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
            child: _feedbackBody(ok, skipped, color, w),
          ),
        ],
      ),
    );
  }

  Widget _feedbackBody(bool ok, bool skipped, Color color, Word? w) {
    return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                child: Icon(ok ? Icons.check_rounded : Icons.close_rounded, color: Colors.white, size: 18),
              ),
              const SizedBox(width: 10),
              Text(ok ? 'Doğru' : (skipped ? 'Boş bıraktın' : 'Yanlış'),
                  style: display(20, color: color)),
            ],
          ),
          if (!ok) ...[
            const SizedBox(height: 10),
            Text('Doğru cevap: ${String.fromCharCode(65 + q.ans)}',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: C.good)),
          ],
          for (final e in q.exp) ...[
            const SizedBox(height: 8),
            if (e.ar)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
                decoration: BoxDecoration(color: C.goodSoft, borderRadius: BorderRadius.circular(12)),
                child: Ar(e.text, size: 23, height: 1.7),
              )
            else
              Text(e.text, style: const TextStyle(fontSize: 15, height: 1.5)),
          ],
          if (q.gloss.isNotEmpty && w == null) ...[
            const SizedBox(height: 12),
            const Divider(height: 1, color: C.line),
            const SizedBox(height: 8),
            const Text('KELİMELER', style: labelCaps),
            for (final g in q.gloss) _glossRow(g[0], g[1]),
          ],
          if (w != null) ...[
            const SizedBox(height: 12),
            const Divider(height: 1, color: C.line),
            const SizedBox(height: 8),
            const Text('KELİME KARTI', style: labelCaps),
            const SizedBox(height: 4),
            Ar(w.ar, size: 30, height: 1.6),
            if (w.extra.isNotEmpty) Ar(w.extra, size: 21, color: C.muted, height: 1.6),
            const SizedBox(height: 2),
            Text('${w.tr} · ${kPos[w.pos]}',
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            if (w.root.isNotEmpty) ...[
              const SizedBox(height: 8),
              const Text('KÖK', style: labelCaps),
              Ar(w.rootSpaced, size: 24, color: C.gold, wordSpacing: 6),
            ],
            const SizedBox(height: 6),
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: () => Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => WordScreen(word: w))),
                icon: const Icon(Icons.menu_book_outlined, size: 18),
                label: const Text('Sözlükte aç'),
              ),
            ),
          ],
        ],
    );
  }

  Widget _glossRow(String ar, String tr) => Container(
        decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: C.soft))),
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          children: [
            Expanded(child: Text(tr, style: const TextStyle(fontSize: 14.5, color: C.muted))),
            const SizedBox(width: 12),
            Flexible(child: Ar(ar, size: 22, height: 1.7)),
          ],
        ),
      );

  Widget _bottomBar() {
    final st = AppState.I;
    final w = q.word;
    final Widget content;
    if (answered) {
      content = PrimaryButton(last ? 'Sonucu gör' : 'Sonraki soru',
          icon: Icons.arrow_forward_rounded, onPressed: next);
    } else {
      final marked = w != null ? st.saved.contains(w.id) : st.flagged.contains(q.id);
      content = Row(
        children: [
          Expanded(
            child: GhostButton(
              w != null ? (marked ? 'Kaydedildi' : 'Kelimeyi kaydet') : (marked ? 'İşaretlendi' : 'İşaretle'),
              icon: marked ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
              onPressed: () {
                if (w != null) {
                  st.toggleSaved(w.id);
                } else {
                  st.toggleFlag(q.id);
                }
                setState(() {});
              },
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: GhostButton('Boş bırak',
                icon: Icons.arrow_forward_rounded, iconAfter: true, onPressed: () => answer(null)),
          ),
        ],
      );
    }
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
      decoration: const BoxDecoration(
        color: C.paper,
        border: Border(top: BorderSide(color: C.line)),
      ),
      child: content,
    );
  }
}
