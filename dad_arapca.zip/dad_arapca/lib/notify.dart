import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

/// Günlük çalışma hatırlatması.
class Reminder {
  static final FlutterLocalNotificationsPlugin _p = FlutterLocalNotificationsPlugin();
  static bool _ready = false;
  static const int _id = 1;

  static Future<void> init() async {
    if (_ready) return;
    tzdata.initializeTimeZones();
    try {
      tz.setLocalLocation(tz.getLocation('Europe/Istanbul'));
    } catch (_) {}
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _p.initialize(const InitializationSettings(android: android));
    _ready = true;
  }

  /// Android 13 ve sonrasında bildirim izni ister. İzin verilirse true.
  static Future<bool> requestPermission() async {
    await init();
    final a = _p.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    final ok = await a?.requestNotificationsPermission();
    return ok ?? true;
  }

  static Future<void> schedule(int hour, int minute) async {
    await init();
    await _p.cancel(_id);
    final now = tz.TZDateTime.now(tz.local);
    var t = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    if (!t.isAfter(now)) t = t.add(const Duration(days: 1));
    await _p.zonedSchedule(
      _id,
      'Dâd Arapça',
      'Bugünkü çalışma zamanı: tekrar listen ve yeni sorular seni bekliyor.',
      t,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'gunluk_hatirlatma',
          'Günlük hatırlatma',
          channelDescription: 'Her gün aynı saatte çalışma hatırlatması',
          importance: Importance.defaultImportance,
          priority: Priority.defaultPriority,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  static Future<void> cancel() async {
    await init();
    await _p.cancel(_id);
  }
}
