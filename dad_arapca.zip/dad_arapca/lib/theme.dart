// ignore: unnecessary_import
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';

/// Renkler: tasarımdaki tokenlarla birebir.
class C {
  static const paper = Color(0xFFF2F5F4);
  static const surface = Color(0xFFFFFFFF);
  static const sunk = Color(0xFFE4ECEA);
  static const soft = Color(0xFFEEF3F2);
  static const ink = Color(0xFF12232A);
  static const muted = Color(0xFF4E6367);
  static const faint = Color(0xFF7A8C8F);
  static const line = Color(0xFFD6E0DE);
  static const track = Color(0xFFDCE5E3);
  static const accent = Color(0xFF0C6A61);
  static const accentDark = Color(0xFF0A574F);
  static const accentSoft = Color(0xFFD7ECE8);
  static const accentBar = Color(0xFF9FCDC6);
  static const onAccent = Color(0xFFD9EEEA);
  static const gold = Color(0xFF8F5A0E);
  static const goldLine = Color(0xFFB07418);
  static const goldSoft = Color(0xFFFBF0DD);
  static const today = Color(0xFFF2C46B);
  static const good = Color(0xFF1B6E42);
  static const goodSoft = Color(0xFFE0F2E7);
  static const bad = Color(0xFFA8261D);
  static const badSoft = Color(0xFFFAE3E0);
}

const String kBody = 'Figtree';
const String kDisplay = 'Bricolage';
const String kArabic = 'Scheherazade';

TextStyle display(double size, {Color color = C.ink}) => TextStyle(
      fontFamily: kDisplay,
      fontWeight: FontWeight.w800,
      fontSize: size,
      height: 1.15,
      color: color,
    );

const TextStyle labelCaps = TextStyle(
  fontFamily: kBody,
  fontSize: 12,
  fontWeight: FontWeight.w700,
  letterSpacing: 0.9,
  color: C.muted,
);

const List<FontFeature> tabular = [FontFeature.tabularFigures()];

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: C.accent,
    primary: C.accent,
    onPrimary: Colors.white,
    surface: C.paper,
    onSurface: C.ink,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    fontFamily: kBody,
    scaffoldBackgroundColor: C.paper,
    splashFactory: InkRipple.splashFactory,
    appBarTheme: const AppBarTheme(
      backgroundColor: C.paper,
      surfaceTintColor: Colors.transparent,
      foregroundColor: C.ink,
      elevation: 0,
      scrolledUnderElevation: 0,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: C.surface,
      surfaceTintColor: Colors.transparent,
      indicatorColor: C.accentSoft,
      height: 72,
      labelTextStyle: WidgetStateProperty.resolveWith((s) {
        final sel = s.contains(WidgetState.selected);
        return TextStyle(
          fontFamily: kBody,
          fontSize: 12,
          fontWeight: sel ? FontWeight.w700 : FontWeight.w600,
          color: sel ? C.accent : C.muted,
        );
      }),
      iconTheme: WidgetStateProperty.resolveWith((s) => IconThemeData(
            color: s.contains(WidgetState.selected) ? C.accent : C.muted,
          )),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: C.surface,
      hintStyle: const TextStyle(color: Color(0xFF6A7E81)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: C.line),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: C.line),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: C.accent, width: 2),
      ),
    ),
    snackBarTheme: const SnackBarThemeData(
      backgroundColor: C.ink,
      behavior: SnackBarBehavior.floating,
    ),
  );
}
