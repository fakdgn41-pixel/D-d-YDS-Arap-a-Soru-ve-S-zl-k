import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

/// Uygulamanın tek durum nesnesi: soru bankası, sözlük, sonuç geçmişi.
class AppState extends ChangeNotifier {
  static final AppState I = AppState._();
  AppState._();

  static const _kLog = 'log.v1';
  static const _kSeen = 'seen.v1';
  static const _kRight = 'right.v1';
  static const _kSaved = 'saved.v1';
  static const _kFlag = 'flag.v1';

  SharedPreferences? _p;
  final Random rnd = Random();

  List<Question> questions = [];
  List<Word> words = [];
  Map<String, Word> wordById = {};
  List<SetResult> log = [];
  Map<String, int> seen = {};
  Map<String, int> right = {};
  Set<String> saved = {};
  Set<String> flagged = {};

  /// Sınav tarihi: 22 Kasım 2026.
  final DateTime examDate = DateTime(2026, 11, 22);

  Future<void> init() async {
    final qRaw = jsonDecode(await rootBundle.loadString('assets/data/questions.json')) as List;
    questions = qRaw.map((e) => Question.fromJson(e as Map<String, dynamic>)).toList();
    final wRaw = jsonDecode(await rootBundle.loadString('assets/data/words.json')) as List;
    words = wRaw.map((e) => Word.fromJson(e as Map<String, dynamic>)).toList();
    wordById = {for (final w in words) w.id: w};

    try {
      _p = await SharedPreferences.getInstance();
      final l = _p!.getString(_kLog);
      if (l != null) {
        log = (jsonDecode(l) as List)
            .map((e) => SetResult.fromJson(e as Map<String, dynamic>))
            .toList();
      }
      seen = _readCounts(_kSeen);
      right = _readCounts(_kRight);
      saved = (_p!.getStringList(_kSaved) ?? const []).toSet();
      flagged = (_p!.getStringList(_kFlag) ?? const []).toSet();
    } catch (_) {
      // Kayıt okunamazsa uygulama boş geçmişle açılır.
    }
  }

  Map<String, int> _readCounts(String k) {
    final s = _p?.getString(k);
    if (s == null) return {};
    return (jsonDecode(s) as Map).map((a, b) => MapEntry(a as String, b as int));
  }

  void _save() {
    final p = _p;
    if (p == null) return;
    p.setString(_kLog, jsonEncode(log.map((e) => e.toJson()).toList()));
    p.setString(_kSeen, jsonEncode(seen));
    p.setString(_kRight, jsonEncode(right));
    p.setStringList(_kSaved, saved.toList());
    p.setStringList(_kFlag, flagged.toList());
  }

  // ---------- kayıt işlemleri ----------
  void recordAnswer(String id, bool ok) {
    seen[id] = (seen[id] ?? 0) + 1;
    if (ok) right[id] = (right[id] ?? 0) + 1;
    _save();
  }

  void addResult(SetResult r) {
    log.add(r);
    _save();
    notifyListeners();
  }

  void toggleSaved(String wordId) {
    saved.contains(wordId) ? saved.remove(wordId) : saved.add(wordId);
    _save();
    notifyListeners();
  }

  void toggleFlag(String qid) {
    flagged.contains(qid) ? flagged.remove(qid) : flagged.add(qid);
    _save();
    notifyListeners();
  }

  // ---------- özetler ----------
  int get daysLeft {
    final n = DateTime.now();
    final today = DateTime(n.year, n.month, n.day);
    return examDate.difference(today).inDays;
  }

  List<SetResult> resultsOn(String day) => log.where((r) => r.day == day).toList();

  List<String> get days {
    final s = log.map((r) => r.day).toSet().toList()..sort();
    return s.reversed.toList();
  }

  /// Bir set türünün son skoru (yüzde), hiç çözülmediyse null.
  int? lastScore(String key) {
    for (var i = log.length - 1; i >= 0; i--) {
      if (log[i].key == key) return log[i].pct;
    }
    return null;
  }

  ({int sets, int correct, int total, int sec}) dayTotals(String day) {
    var c = 0, t = 0, s = 0, n = 0;
    for (final r in log) {
      if (r.day != day) continue;
      n++;
      c += r.correct;
      t += r.total;
      s += r.sec;
    }
    return (sets: n, correct: c, total: t, sec: s);
  }

  List<Word> sameRoot(Word w) =>
      w.root.isEmpty ? [] : words.where((x) => x.root == w.root && x.id != w.id).toList();

  // ---------- set oluşturma ----------
  List<T> shuffled<T>(List<T> a) => List<T>.of(a)..shuffle(rnd);

  /// Az görülenler önce, eşitler arasında rastgele sıra.
  List<T> leastSeen<T>(List<T> pool, String Function(T) id) {
    final tie = <String, double>{for (final x in pool) id(x): rnd.nextDouble()};
    final out = List<T>.of(pool);
    out.sort((a, b) {
      final d = (seen[id(a)] ?? 0) - (seen[id(b)] ?? 0);
      return d != 0 ? d : tie[id(a)]!.compareTo(tie[id(b)]!);
    });
    return out;
  }

  Question prep(Question q) {
    if (q.noShuffle) return q;
    final order = shuffled(List<int>.generate(q.opts.length, (i) => i));
    return q.withOptions([for (final i in order) q.opts[i]], order.indexOf(q.ans));
  }

  List<Question> vocabQuestions(int n, {List<Word>? from}) {
    final pool = from ?? words;
    final picks = leastSeen(pool, (Word w) => w.id).take(n);
    return picks.map((e) {
      var same = words.where((x) => x.id != e.id && x.tr != e.tr && x.pos == e.pos).toList();
      if (same.length < 4) same = words.where((x) => x.id != e.id).toList();
      final all = [e, ...shuffled(same).take(4)];
      final ar2tr = rnd.nextBool();
      return Question(
        id: e.id,
        cat: 'kelime',
        kind: ar2tr ? 'Sözlük · Kelime anlamı' : 'Sözlük · Arapça karşılık',
        prompt: ar2tr
            ? 'Kelimenin Türkçe karşılığı hangisidir?'
            : 'Türkçe karşılığı verilen kelimenin Arapçası hangisidir?',
        lines: [ar2tr ? Line(ar: e.ar) : Line(tr: e.tr)],
        opts: all.map((x) => ar2tr ? x.tr : x.ar).toList(),
        optAr: !ar2tr,
        ans: 0,
        gloss: all.map((x) => [x.ar, x.tr]).toList(),
        word: e,
      );
    }).toList();
  }

  List<Question> buildSet(String key) {
    List<Question> qs;
    String qid(Question q) => q.id;
    switch (key) {
      case 'sozluk':
        qs = vocabQuestions(10);
      case 'mix':
        final lists = kCat.keys
            .map((c) => leastSeen(questions.where((q) => q.cat == c).toList(), qid))
            .toList();
        final picked = <Question>[];
        var i = 0;
        while (picked.length < 8 && i < 80) {
          final l = lists[i % lists.length];
          if (l.isNotEmpty) picked.add(l.removeAt(0));
          i++;
        }
        qs = shuffled([...picked, ...vocabQuestions(4)]);
      case 'kelime':
        final h = leastSeen(questions.where((q) => q.cat == 'kelime').toList(), qid)
            .take(5)
            .toList();
        qs = shuffled([...h, ...vocabQuestions(10 - h.length)]);
      default:
        qs = leastSeen(questions.where((q) => q.cat == key).toList(), qid);
    }
    return qs.map(prep).toList();
  }

  /// Bir kelime ve aynı kökten gelenlerle kısa test.
  List<Question> rootSet(Word w) {
    final pool = [w, ...sameRoot(w)];
    final extra = leastSeen(words.where((x) => !pool.contains(x)).toList(), (Word x) => x.id)
        .take(max(0, 5 - pool.length))
        .toList();
    return vocabQuestions(pool.length + extra.length, from: [...pool, ...extra]).map(prep).toList();
  }

  List<Question> flaggedSet() =>
      questions.where((q) => flagged.contains(q.id)).map(prep).toList();
}
