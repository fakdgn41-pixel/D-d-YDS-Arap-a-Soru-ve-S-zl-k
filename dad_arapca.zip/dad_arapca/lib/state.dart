import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

/// Kaydedilmiş, yarım kalmış deneme sınavı.
class ExamSession {
  final List<Question> questions;
  final List<List<int>> orders; // her soru için şık sırası
  final List<int?> answers;
  final Set<int> flags;
  final int startedAt; // ms
  int current;

  ExamSession({
    required this.questions,
    required this.orders,
    required this.answers,
    required this.flags,
    required this.startedAt,
    this.current = 0,
  });

  int get remaining {
    final used = (DateTime.now().millisecondsSinceEpoch - startedAt) ~/ 1000;
    return max(0, kExamSeconds - used);
  }

  int get answeredCount => answers.where((a) => a != null).length;

  Map<String, dynamic> toJson() => {
        'ids': questions.map((q) => q.id).toList(),
        'orders': orders,
        'answers': answers,
        'flags': flags.toList(),
        'startedAt': startedAt,
        'current': current,
      };
}

/// Uygulamanın tek durum nesnesi: soru bankası, sözlük, sonuç geçmişi, tekrar listesi.
class AppState extends ChangeNotifier {
  static final AppState I = AppState._();
  AppState._();

  static const _kLog = 'log.v1';
  static const _kSeen = 'seen.v1';
  static const _kRight = 'right.v1';
  static const _kSaved = 'saved.v1';
  static const _kFlag = 'flag.v1';
  static const _kSrs = 'srs.v1';
  static const _kExam = 'exam.v1';
  static const _kRemind = 'remind.v1';

  /// Akıllı tekrar aralıkları (gün): kutu 1..5.
  static const List<int> srsDays = [0, 1, 3, 7, 16, 35];

  SharedPreferences? _p;
  final Random rnd = Random();

  List<Question> questions = [];
  Map<String, Question> questionById = {};
  Map<String, Passage> passages = {};
  List<Word> words = [];
  Map<String, Word> wordById = {};
  List<SetResult> log = [];
  Map<String, int> seen = {};
  Map<String, int> right = {};
  Set<String> saved = {};
  Set<String> flagged = {};
  Map<String, List<int>> srs = {}; // kimlik -> [kutu, vade günü]
  ExamSession? exam;
  bool remindOn = false;
  int remindHour = 20;
  int remindMinute = 0;

  /// Sınav tarihi: 22 Kasım 2026.
  final DateTime examDate = DateTime(2026, 11, 22);

  Future<void> init() async {
    final qRaw = jsonDecode(await rootBundle.loadString('assets/data/questions.json')) as List;
    questions = qRaw.map((e) => Question.fromJson(e as Map<String, dynamic>)).toList();
    questionById = {for (final q in questions) q.id: q};
    final pRaw = jsonDecode(await rootBundle.loadString('assets/data/passages.json')) as List;
    passages = {
      for (final e in pRaw) (e as Map<String, dynamic>)['id'] as String: Passage.fromJson(e),
    };
    final wRaw = jsonDecode(await rootBundle.loadString('assets/data/words.json')) as List;
    words = wRaw.map((e) => Word.fromJson(e as Map<String, dynamic>)).toList();
    wordById = {for (final w in words) w.id: w};

    try {
      _p = await SharedPreferences.getInstance();
      final p = _p!;
      final l = p.getString(_kLog);
      if (l != null) {
        log = (jsonDecode(l) as List)
            .map((e) => SetResult.fromJson(e as Map<String, dynamic>))
            .toList();
      }
      seen = _readCounts(_kSeen);
      right = _readCounts(_kRight);
      saved = (p.getStringList(_kSaved) ?? const []).toSet();
      flagged = (p.getStringList(_kFlag) ?? const []).toSet();
      final s = p.getString(_kSrs);
      if (s != null) {
        srs = (jsonDecode(s) as Map).map((k, v) =>
            MapEntry(k as String, (v as List).map((x) => x as int).toList()));
      }
      final r = p.getString(_kRemind);
      if (r != null) {
        final m = jsonDecode(r) as Map;
        remindOn = m['on'] == true;
        remindHour = (m['h'] as int?) ?? 20;
        remindMinute = (m['m'] as int?) ?? 0;
      }
      exam = _readExam();
    } catch (_) {
      // Kayıt okunamazsa uygulama boş geçmişle açılır.
    }
  }

  Map<String, int> _readCounts(String k) {
    final s = _p?.getString(k);
    if (s == null) return {};
    return (jsonDecode(s) as Map).map((a, b) => MapEntry(a as String, b as int));
  }

  ExamSession? _readExam() {
    final s = _p?.getString(_kExam);
    if (s == null) return null;
    final m = jsonDecode(s) as Map;
    final ids = (m['ids'] as List).map((e) => e as String).toList();
    final orders = (m['orders'] as List).map((o) => (o as List).map((x) => x as int).toList()).toList();
    final qs = <Question>[];
    for (var i = 0; i < ids.length; i++) {
      final q = questionById[ids[i]];
      if (q == null) return null; // soru bankası değişmiş: eski denemeyi bırak
      qs.add(_applyOrder(q, orders[i]));
    }
    return ExamSession(
      questions: qs,
      orders: orders,
      answers: (m['answers'] as List).map((a) => a as int?).toList(),
      flags: (m['flags'] as List).map((x) => x as int).toSet(),
      startedAt: m['startedAt'] as int,
      current: (m['current'] as int?) ?? 0,
    );
  }

  void _save() {
    final p = _p;
    if (p == null) return;
    p.setString(_kLog, jsonEncode(log.map((e) => e.toJson()).toList()));
    p.setString(_kSeen, jsonEncode(seen));
    p.setString(_kRight, jsonEncode(right));
    p.setStringList(_kSaved, saved.toList());
    p.setStringList(_kFlag, flagged.toList());
    p.setString(_kSrs, jsonEncode(srs));
  }

  // ---------- kayıt işlemleri ----------
  /// Cevabı kaydeder ve akıllı tekrar listesini günceller:
  /// yanlış cevap yarın tekrar gelir, doğru cevap bir sonraki kutuya geçer.
  void recordAnswer(String id, bool ok, {bool notify = false}) {
    seen[id] = (seen[id] ?? 0) + 1;
    if (ok) right[id] = (right[id] ?? 0) + 1;
    final today = epochDay();
    final s = srs[id];
    if (!ok) {
      srs[id] = [1, today + 1];
    } else if (s != null) {
      final box = s[0] + 1;
      if (box >= srsDays.length) {
        srs.remove(id);
      } else {
        srs[id] = [box, today + srsDays[box]];
      }
    }
    _save();
    if (notify) notifyListeners();
  }

  void addResult(SetResult r) {
    log.add(r);
    _save();
    notifyListeners();
  }

  void toggleSaved(String wordId) {
    saved.contains(wordId) ? saved.remove(wordId) : saved.add(wordId);
    _save();
    notifyListeners();
  }

  void toggleFlag(String qid) {
    flagged.contains(qid) ? flagged.remove(qid) : flagged.add(qid);
    _save();
    notifyListeners();
  }

  void setReminder({required bool on, int? hour, int? minute}) {
    remindOn = on;
    remindHour = hour ?? remindHour;
    remindMinute = minute ?? remindMinute;
    _p?.setString(_kRemind, jsonEncode({'on': remindOn, 'h': remindHour, 'm': remindMinute}));
    notifyListeners();
  }

  Future<void> resetProgress() async {
    log = [];
    seen = {};
    right = {};
    flagged = {};
    srs = {};
    exam = null;
    _p?.remove(_kExam);
    _save();
    notifyListeners();
  }

  // ---------- deneme sınavı ----------
  void saveExam() {
    final e = exam;
    if (e == null) {
      _p?.remove(_kExam);
    } else {
      _p?.setString(_kExam, jsonEncode(e.toJson()));
    }
  }

  void clearExam() {
    exam = null;
    _p?.remove(_kExam);
    notifyListeners();
  }

  ExamSession newExam() {
    final qs = <Question>[];
    final orders = <List<int>>[];
    for (final (cat, n) in kExamPlan) {
      final picked = kGroupCats.contains(cat) ? _pickGroups(cat, n) : _pickSingles(cat, n);
      for (final q in picked) {
        final order = q.noShuffle
            ? List<int>.generate(q.opts.length, (i) => i)
            : shuffled(List<int>.generate(q.opts.length, (i) => i));
        orders.add(order);
        qs.add(_applyOrder(q, order));
      }
    }
    final e = ExamSession(
      questions: qs,
      orders: orders,
      answers: List<int?>.filled(qs.length, null),
      flags: {},
      startedAt: DateTime.now().millisecondsSinceEpoch,
    );
    exam = e;
    saveExam();
    notifyListeners();
    return e;
  }

  Question _applyOrder(Question q, List<int> order) =>
      q.withOptions([for (final i in order) q.opts[i]], order.indexOf(q.ans));

  List<Question> _pickSingles(String cat, int n) =>
      leastSeen(questions.where((q) => q.cat == cat).toList(), (Question q) => q.id).take(n).toList();

  /// Parça soruları: az görülen parçalar seçilir, soruları sırasıyla eklenir.
  List<Question> _pickGroups(String cat, int n) {
    final byPid = <String, List<Question>>{};
    for (final q in questions) {
      if (q.cat == cat && q.pid != null) byPid.putIfAbsent(q.pid!, () => []).add(q);
    }
    int seenOf(String pid) => byPid[pid]!.fold(0, (a, q) => a + (seen[q.id] ?? 0));
    final tie = {for (final k in byPid.keys) k: rnd.nextDouble()};
    final pids = byPid.keys.toList()
      ..sort((a, b) {
        final d = seenOf(a) - seenOf(b);
        return d != 0 ? d : tie[a]!.compareTo(tie[b]!);
      });
    final out = <Question>[];
    for (final pid in pids) {
      if (out.length >= n) break;
      out.addAll(byPid[pid]!);
    }
    return out.take(n).toList();
  }

  // ---------- özetler ----------
  int get daysLeft {
    final n = DateTime.now();
    final today = DateTime(n.year, n.month, n.day);
    return examDate.difference(today).inDays;
  }

  List<SetResult> resultsOn(String day) => log.where((r) => r.day == day).toList();

  List<String> get days {
    final s = log.map((r) => r.day).toSet().toList()..sort();
    return s.reversed.toList();
  }

  /// Bir set türünün son skoru (yüzde), hiç çözülmediyse null.
  int? lastScore(String key) {
    for (var i = log.length - 1; i >= 0; i--) {
      if (log[i].key == key) return log[i].pct;
    }
    return null;
  }

  ({int sets, int correct, int total, int sec}) dayTotals(String day) {
    var c = 0, t = 0, s = 0, n = 0;
    for (final r in log) {
      if (r.day != day) continue;
      n++;
      c += r.correct;
      t += r.total;
      s += r.sec;
    }
    return (sets: n, correct: c, total: t, sec: s);
  }

  int countIn(String cat) => questions.where((q) => q.cat == cat).length;

  List<Word> sameRoot(Word w) =>
      w.root.isEmpty ? [] : words.where((x) => x.root == w.root && x.id != w.id).toList();

  // ---------- akıllı tekrar ----------
  List<String> get dueIds {
    final today = epochDay();
    final ids = srs.entries
        .where((e) => e.value[1] <= today && (questionById.containsKey(e.key) || wordById.containsKey(e.key)))
        .toList()
      ..sort((a, b) => a.value[1].compareTo(b.value[1]));
    return ids.map((e) => e.key).toList();
  }

  int get srsTotal => srs.length;

  /// Vadesi gelmemiş en yakın tekrar kaç gün sonra.
  int? get nextDueIn {
    if (srs.isEmpty) return null;
    final today = epochDay();
    return srs.values.map((v) => v[1] - today).reduce(min);
  }

  List<Question> reviewSet({int limit = 20}) {
    final out = <Question>[];
    for (final id in dueIds.take(limit)) {
      final q = questionById[id];
      if (q != null) {
        out.add(prep(q));
      } else {
        final w = wordById[id];
        if (w != null) out.addAll(vocabQuestions(1, from: [w]).map(prep));
      }
    }
    return out;
  }

  // ---------- set oluşturma ----------
  List<T> shuffled<T>(List<T> a) => List<T>.of(a)..shuffle(rnd);

  /// Az görülenler önce, eşitler arasında rastgele sıra.
  List<T> leastSeen<T>(List<T> pool, String Function(T) id) {
    final tie = <String, double>{for (final x in pool) id(x): rnd.nextDouble()};
    final out = List<T>.of(pool);
    out.sort((a, b) {
      final d = (seen[id(a)] ?? 0) - (seen[id(b)] ?? 0);
      return d != 0 ? d : tie[id(a)]!.compareTo(tie[id(b)]!);
    });
    return out;
  }

  Question prep(Question q) {
    if (q.noShuffle) return q;
    final order = shuffled(List<int>.generate(q.opts.length, (i) => i));
    return _applyOrder(q, order);
  }

  List<Question> vocabQuestions(int n, {List<Word>? from}) {
    final pool = from ?? words;
    final picks = leastSeen(pool, (Word w) => w.id).take(n);
    return picks.map((e) {
      var same = words.where((x) => x.id != e.id && x.tr != e.tr && x.pos == e.pos).toList();
      if (same.length < 4) same = words.where((x) => x.id != e.id).toList();
      final all = [e, ...shuffled(same).take(4)];
      final ar2tr = rnd.nextBool();
      return Question(
        id: e.id,
        cat: 'kelime',
        kind: ar2tr ? 'Sözlük · Kelime anlamı' : 'Sözlük · Arapça karşılık',
        prompt: ar2tr
            ? 'Kelimenin Türkçe karşılığı hangisidir?'
            : 'Türkçe karşılığı verilen kelimenin Arapçası hangisidir?',
        lines: [ar2tr ? Line(ar: e.ar) : Line(tr: e.tr)],
        opts: all.map((x) => ar2tr ? x.tr : x.ar).toList(),
        optAr: !ar2tr,
        ans: 0,
        gloss: all.map((x) => [x.ar, x.tr]).toList(),
        word: e,
      );
    }).toList();
  }

  List<Question> buildSet(String key) {
    List<Question> qs;
    String qid(Question q) => q.id;
    switch (key) {
      case 'sozluk':
        qs = vocabQuestions(10);
      case 'mix':
        final cats = kCat.keys.where((c) => !kGroupCats.contains(c)).toList();
        final picked = <Question>[];
        for (final c in cats) {
          final l = leastSeen(questions.where((q) => q.cat == c).toList(), qid);
          if (l.isNotEmpty) picked.add(l.first);
        }
        qs = shuffled([...picked, ...vocabQuestions(12 - picked.length)]);
      case 'kelime':
        final h = leastSeen(questions.where((q) => q.cat == 'kelime').toList(), qid).take(6).toList();
        qs = shuffled([...h, ...vocabQuestions(10 - h.length)]);
      case 'cloze':
        qs = _pickGroups('cloze', 10);
      case 'okuma':
        qs = _pickGroups('okuma', 8);
      default:
        qs = leastSeen(questions.where((q) => q.cat == key).toList(), qid).take(10).toList();
    }
    return qs.map(prep).toList();
  }

  /// Bir kelime ve aynı kökten gelenlerle kısa test.
  List<Question> rootSet(Word w) {
    final pool = [w, ...sameRoot(w).take(6)];
    final extra = leastSeen(words.where((x) => !pool.contains(x)).toList(), (Word x) => x.id)
        .take(max(0, 5 - pool.length))
        .toList();
    return vocabQuestions(pool.length + extra.length, from: [...pool, ...extra]).map(prep).toList();
  }

  List<Question> flaggedSet() => questions.where((q) => flagged.contains(q.id)).map(prep).toList();
}
