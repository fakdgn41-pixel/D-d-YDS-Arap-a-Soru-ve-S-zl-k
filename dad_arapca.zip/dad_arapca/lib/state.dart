import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

/// Kaydedilmiş, yarım kalmış deneme sınavı.
class ExamSession {
  final List<Question> questions;
  final List<List<int>> orders; // her soru için şık sırası
  final List<int?> answers;
  final Set<int> flags;
  final int startedAt; // ms
  int current;

  ExamSession({
    required this.questions,
    required this.orders,
    required this.answers,
    required this.flags,
    required this.startedAt,
    this.current = 0,
  });

  int get remaining {
    final used = (DateTime.now().millisecondsSinceEpoch - startedAt) ~/ 1000;
    return max(0, kExamSeconds - used);
  }

  int get answeredCount => answers.where((a) => a != null).length;

  Map<String, dynamic> toJson() => {
        'ids': questions.map((q) => q.id).toList(),
        'orders': orders,
        'answers': answers,
        'flags': flags.toList(),
        'startedAt': startedAt,
        'current': current,
      };
}

/// Uygulamanın tek durum nesnesi: soru bankası, sözlük, sonuç geçmişi, tekrar listesi.
class AppState extends ChangeNotifier {
  static final AppState I = AppState._();
  AppState._();

  static const _kLog = 'log.v1';
  static const _kSeen = 'seen.v1';
  static const _kRight = 'right.v1';
  static const _kSaved = 'saved.v1';
  static const _kFlag = 'flag.v1';
  static const _kSrs = 'srs.v1';
  static const _kExam = 'exam.v1';
  static const _kRemind = 'remind.v1';
  static const _kCards = 'cards.v1';
  static const _kExamDate = 'examdate.v1';
  static const _kHareke = 'hareke.v1';

  /// Akıllı tekrar aralıkları (gün): kutu 1..5.
  static const List<int> srsDays = [0, 1, 3, 7, 16, 35];

  SharedPreferences? _p;
  final Random rnd = Random();

  List<Question> questions = [];
  Map<String, Question> questionById = {};
  Map<String, Passage> passages = {};
  List<Word> words = [];
  Map<String, Word> wordById = {};
  List<SetResult> log = [];
  Map<String, int> seen = {};
  Map<String, int> right = {};
  Set<String> saved = {};
  Set<String> flagged = {};
  Map<String, List<int>> srs = {}; // kimlik -> [kutu, vade günü]
  Map<String, List<int>> cards = {}; // kelime kartları: kimlik -> [kutu, vade günü]
  List<Topic> topics = [];
  Map<String, Topic> topicByKind = {};
  SarfData sarf = SarfData.empty;

  /// Arapça metinlerde harekeli hâli göster (varsayılan: harekesiz, sınavdaki gibi).
  bool showHarakat = false;
  void toggleHarakat() {
    showHarakat = !showHarakat;
    _p?.setBool(_kHareke, showHarakat);
    notifyListeners();
  }

  /// Harekeli hâl varsa ve açıksa onu, yoksa düz metni verir.
  String arText(String plain, String? h) => showHarakat && h != null && h.isNotEmpty ? h : plain;
  BasData bas = BasData.empty;

  /// Sıfırdan Arapça: dersin soruları, alıştırma seti ve tamamlanma durumu (%70 ve üstü).
  List<Question> lessonQuestions(String lid) => questions.where((q) => q.id.startsWith('bl_${lid}_')).toList();
  List<Question> lessonSet(String lid) =>
      shuffled(lessonQuestions(lid)).take(10).map(prep).toList();
  bool lessonDone(String lid) => (bestScore('bl_$lid') ?? 0) >= 70;
  int? bestScore(String key) {
    int? b;
    for (final r in log) {
      if (r.key == key && (b == null || r.pct > b)) b = r.pct;
    }
    return b;
  }

  int get lessonsDone => bas.units.fold(0, (a, u) => a + u.lessons.where((l) => lessonDone(l.id)).length);
  int get lessonsTotal => bas.units.fold(0, (a, u) => a + u.lessons.length);
  BasLesson? get nextLesson {
    for (final u in bas.units) {
      for (final l in u.lessons) {
        if (!lessonDone(l.id)) return l;
      }
    }
    return null;
  }
  List<Topic> get sarfTopics => topics.where((t) => t.id.startsWith('sarf_')).toList();
  ExamSession? exam;
  bool remindOn = false;
  int remindHour = 20;
  int remindMinute = 0;

  /// Sınav tarihi. Varsayılan 22 Kasım 2026; Ayarlar'dan değiştirilebilir.
  DateTime examDate = DateTime(2026, 11, 22);

  Future<void> init() async {
    final qRaw = jsonDecode(await rootBundle.loadString('assets/data/questions.json')) as List;
    questions = qRaw.map((e) => Question.fromJson(e as Map<String, dynamic>)).toList();
    questionById = {for (final q in questions) q.id: q};
    final pRaw = jsonDecode(await rootBundle.loadString('assets/data/passages.json')) as List;
    passages = {
      for (final e in pRaw) (e as Map<String, dynamic>)['id'] as String: Passage.fromJson(e),
    };
    final wRaw = jsonDecode(await rootBundle.loadString('assets/data/words.json')) as List;
    words = wRaw.map((e) => Word.fromJson(e as Map<String, dynamic>)).toList();
    wordById = {for (final w in words) w.id: w};
    final tRaw = jsonDecode(await rootBundle.loadString('assets/data/topics.json')) as List;
    topics = tRaw.map((e) => Topic.fromJson(e as Map<String, dynamic>)).toList();
    try {
      sarf = SarfData.fromJson(
          jsonDecode(await rootBundle.loadString('assets/data/sarf.json')) as Map<String, dynamic>);
    } catch (_) {
      sarf = SarfData.empty;
    }
    try {
      bas = BasData.fromJson(
          jsonDecode(await rootBundle.loadString('assets/data/baslangic.json')) as Map<String, dynamic>);
    } catch (_) {
      bas = BasData.empty;
    }
    topicByKind = {
      for (final t in topics)
        for (final k in t.kinds) k: t,
    };

    try {
      _p = await SharedPreferences.getInstance();
      final p = _p!;
      final l = p.getString(_kLog);
      if (l != null) {
        log = (jsonDecode(l) as List)
            .map((e) => SetResult.fromJson(e as Map<String, dynamic>))
            .toList();
      }
      seen = _readCounts(_kSeen);
      right = _readCounts(_kRight);
      saved = (p.getStringList(_kSaved) ?? const []).toSet();
      flagged = (p.getStringList(_kFlag) ?? const []).toSet();
      final s = p.getString(_kSrs);
      if (s != null) {
        srs = (jsonDecode(s) as Map).map((k, v) =>
            MapEntry(k as String, (v as List).map((x) => x as int).toList()));
      }
      final cs = p.getString(_kCards);
      if (cs != null) {
        cards = (jsonDecode(cs) as Map).map((k, v) =>
            MapEntry(k as String, (v as List).map((x) => x as int).toList()));
      }
      final r = p.getString(_kRemind);
      if (r != null) {
        final m = jsonDecode(r) as Map;
        remindOn = m['on'] == true;
        remindHour = (m['h'] as int?) ?? 20;
        remindMinute = (m['m'] as int?) ?? 0;
      }
      exam = _readExam();
      showHarakat = p.getBool(_kHareke) ?? false;
      final ed = p.getString(_kExamDate);
      if (ed != null) examDate = parseDay(ed);
    } catch (_) {
      // Kayıt okunamazsa uygulama boş geçmişle açılır.
    }
  }

  Map<String, int> _readCounts(String k) {
    final s = _p?.getString(k);
    if (s == null) return {};
    return (jsonDecode(s) as Map).map((a, b) => MapEntry(a as String, b as int));
  }

  ExamSession? _readExam() {
    final s = _p?.getString(_kExam);
    if (s == null) return null;
    final m = jsonDecode(s) as Map;
    final ids = (m['ids'] as List).map((e) => e as String).toList();
    final orders = (m['orders'] as List).map((o) => (o as List).map((x) => x as int).toList()).toList();
    final qs = <Question>[];
    for (var i = 0; i < ids.length; i++) {
      final q = questionById[ids[i]];
      if (q == null) return null; // soru bankası değişmiş: eski denemeyi bırak
      qs.add(_applyOrder(q, orders[i]));
    }
    return ExamSession(
      questions: qs,
      orders: orders,
      answers: (m['answers'] as List).map((a) => a as int?).toList(),
      flags: (m['flags'] as List).map((x) => x as int).toSet(),
      startedAt: m['startedAt'] as int,
      current: (m['current'] as int?) ?? 0,
    );
  }

  void _save() {
    final p = _p;
    if (p == null) return;
    p.setString(_kLog, jsonEncode(log.map((e) => e.toJson()).toList()));
    p.setString(_kSeen, jsonEncode(seen));
    p.setString(_kRight, jsonEncode(right));
    p.setStringList(_kSaved, saved.toList());
    p.setStringList(_kFlag, flagged.toList());
    p.setString(_kSrs, jsonEncode(srs));
    p.setString(_kCards, jsonEncode(cards));
  }

  // ---------- kayıt işlemleri ----------
  /// Cevabı kaydeder ve akıllı tekrar listesini günceller:
  /// yanlış cevap yarın tekrar gelir, doğru cevap bir sonraki kutuya geçer.
  void recordAnswer(String id, bool ok, {bool notify = false}) {
    seen[id] = (seen[id] ?? 0) + 1;
    if (ok) right[id] = (right[id] ?? 0) + 1;
    final today = epochDay();
    final s = srs[id];
    if (!ok) {
      srs[id] = [1, today + 1];
    } else if (s != null) {
      final box = s[0] + 1;
      if (box >= srsDays.length) {
        srs.remove(id);
      } else {
        srs[id] = [box, today + srsDays[box]];
      }
    }
    _save();
    if (notify) notifyListeners();
  }

  void addResult(SetResult r) {
    log.add(r);
    _save();
    notifyListeners();
  }

  void toggleSaved(String wordId) {
    saved.contains(wordId) ? saved.remove(wordId) : saved.add(wordId);
    _save();
    notifyListeners();
  }

  void toggleFlag(String qid) {
    flagged.contains(qid) ? flagged.remove(qid) : flagged.add(qid);
    _save();
    notifyListeners();
  }

  void setReminder({required bool on, int? hour, int? minute}) {
    remindOn = on;
    remindHour = hour ?? remindHour;
    remindMinute = minute ?? remindMinute;
    _p?.setString(_kRemind, jsonEncode({'on': remindOn, 'h': remindHour, 'm': remindMinute}));
    notifyListeners();
  }

  void setExamDate(DateTime d) {
    examDate = DateTime(d.year, d.month, d.day);
    _p?.setString(_kExamDate, dayKey(examDate));
    notifyListeners();
  }

  Future<void> resetProgress() async {
    log = [];
    seen = {};
    right = {};
    flagged = {};
    srs = {};
    cards = {};
    exam = null;
    _p?.remove(_kExam);
    _save();
    notifyListeners();
  }

  // ---------- deneme sınavı ----------
  void saveExam() {
    final e = exam;
    if (e == null) {
      _p?.remove(_kExam);
    } else {
      _p?.setString(_kExam, jsonEncode(e.toJson()));
    }
  }

  void clearExam() {
    exam = null;
    _p?.remove(_kExam);
    notifyListeners();
  }

  ExamSession newExam() {
    final qs = <Question>[];
    final orders = <List<int>>[];
    for (final (cat, n) in kExamPlan) {
      final picked = kGroupCats.contains(cat) ? _pickGroups(cat, n) : _pickSingles(cat, n);
      for (final q in picked) {
        final order = q.noShuffle
            ? List<int>.generate(q.opts.length, (i) => i)
            : shuffled(List<int>.generate(q.opts.length, (i) => i));
        orders.add(order);
        qs.add(_applyOrder(q, order));
      }
    }
    final e = ExamSession(
      questions: qs,
      orders: orders,
      answers: List<int?>.filled(qs.length, null),
      flags: {},
      startedAt: DateTime.now().millisecondsSinceEpoch,
    );
    exam = e;
    saveExam();
    notifyListeners();
    return e;
  }

  Question _applyOrder(Question q, List<int> order) =>
      q.withOptions([for (final i in order) q.opts[i]], order.indexOf(q.ans),
          oh: q.optsH == null || q.optsH!.length != q.opts.length ? null : [for (final i in order) q.optsH![i]]);

  List<Question> _pickSingles(String cat, int n) =>
      leastSeen(questions.where((q) => q.cat == cat).toList(), (Question q) => q.id).take(n).toList();

  /// Parça soruları: az görülen parçalar seçilir, soruları sırasıyla eklenir.
  List<Question> _pickGroups(String cat, int n) {
    final byPid = <String, List<Question>>{};
    for (final q in questions) {
      if (q.cat == cat && q.pid != null) byPid.putIfAbsent(q.pid!, () => []).add(q);
    }
    int seenOf(String pid) => byPid[pid]!.fold(0, (a, q) => a + (seen[q.id] ?? 0));
    final tie = {
      for (final k in byPid.keys) k: rnd.nextDouble() - (byPid[k]!.any((q) => q.hard) ? 1 : 0)
    };
    final pids = byPid.keys.toList()
      ..sort((a, b) {
        final d = seenOf(a) - seenOf(b);
        return d != 0 ? d : tie[a]!.compareTo(tie[b]!);
      });
    final out = <Question>[];
    for (final pid in pids) {
      if (out.length >= n) break;
      out.addAll(byPid[pid]!);
    }
    return out.take(n).toList();
  }

  // ---------- özetler ----------
  int get daysLeft {
    final n = DateTime.now();
    final today = DateTime(n.year, n.month, n.day);
    return examDate.difference(today).inDays;
  }

  List<SetResult> resultsOn(String day) => log.where((r) => r.day == day).toList();

  List<String> get days {
    final s = log.map((r) => r.day).toSet().toList()..sort();
    return s.reversed.toList();
  }

  /// Bir set türünün son skoru (yüzde), hiç çözülmediyse null.
  int? lastScore(String key) {
    for (var i = log.length - 1; i >= 0; i--) {
      if (log[i].key == key) return log[i].pct;
    }
    return null;
  }

  ({int sets, int correct, int total, int sec}) dayTotals(String day) {
    var c = 0, t = 0, s = 0, n = 0;
    for (final r in log) {
      if (r.day != day) continue;
      n++;
      c += r.correct;
      t += r.total;
      s += r.sec;
    }
    return (sets: n, correct: c, total: t, sec: s);
  }

  int countIn(String cat) => questions.where((q) => q.cat == cat).length;

  List<Word> sameRoot(Word w) =>
      w.root.isEmpty ? [] : words.where((x) => x.root == w.root && x.id != w.id).toList();

  // ---------- akıllı tekrar ----------
  List<String> get dueIds {
    final today = epochDay();
    final ids = srs.entries
        .where((e) => e.value[1] <= today && (questionById.containsKey(e.key) || wordById.containsKey(e.key)))
        .toList()
      ..sort((a, b) => a.value[1].compareTo(b.value[1]));
    return ids.map((e) => e.key).toList();
  }

  int get srsTotal => srs.length;

  /// Vadesi gelmemiş en yakın tekrar kaç gün sonra.
  int? get nextDueIn {
    if (srs.isEmpty) return null;
    final today = epochDay();
    return srs.values.map((v) => v[1] - today).reduce(min);
  }

  List<Question> reviewSet({int limit = 20}) {
    final out = <Question>[];
    for (final id in dueIds.take(limit)) {
      final q = questionById[id];
      if (q != null) {
        out.add(prep(q));
      } else {
        final w = wordById[id];
        if (w != null) out.addAll(vocabQuestions(1, from: [w]).map(prep));
      }
    }
    return out;
  }

  // ---------- set oluşturma ----------
  List<T> shuffled<T>(List<T> a) => List<T>.of(a)..shuffle(rnd);

  /// Az görülenler önce, eşitler arasında rastgele sıra.
  List<T> leastSeen<T>(List<T> pool, String Function(T) id) {
    // Eşit görülme sayısında YDS düzeyi sorular öne alınır.
    final tie = <String, double>{
      for (final x in pool) id(x): rnd.nextDouble() - (x is Question && x.hard ? 1 : 0)
    };
    final out = List<T>.of(pool);
    out.sort((a, b) {
      final d = (seen[id(a)] ?? 0) - (seen[id(b)] ?? 0);
      return d != 0 ? d : tie[id(a)]!.compareTo(tie[id(b)]!);
    });
    return out;
  }

  Question prep(Question q) {
    if (q.noShuffle) return q;
    final order = shuffled(List<int>.generate(q.opts.length, (i) => i));
    return _applyOrder(q, order);
  }

  /// Sözlük soruları. Harf-i cerli kalıpların kendi soruları olduğundan burada kullanılmaz.
  List<Question> vocabQuestions(int n, {List<Word>? from}) {
    final pool = (from ?? words).where((w) => w.pos != 'h').toList();
    final picks = leastSeen(pool, (Word w) => w.id).take(n);
    return picks.map((e) {
      var same = words.where((x) => x.id != e.id && x.tr != e.tr && x.pos == e.pos).toList();
      if (same.length < 4) same = words.where((x) => x.id != e.id && x.pos != 'h').toList();
      final all = [e, ...shuffled(same).take(4)];
      final ar2tr = rnd.nextBool();
      return Question(
        id: e.id,
        cat: 'kelime',
        kind: ar2tr ? 'Sözlük · Kelime anlamı' : 'Sözlük · Arapça karşılık',
        prompt: ar2tr
            ? 'Kelimenin Türkçe karşılığı hangisidir?'
            : 'Türkçe karşılığı verilen kelimenin Arapçası hangisidir?',
        lines: [ar2tr ? Line(ar: e.ar) : Line(tr: e.tr)],
        opts: all.map((x) => ar2tr ? x.tr : x.ar).toList(),
        optAr: !ar2tr,
        ans: 0,
        gloss: all.map((x) => [x.ar, x.tr]).toList(),
        word: e,
      );
    }).toList();
  }

  List<Question> buildSet(String key) {
    List<Question> qs;
    String qid(Question q) => q.id;
    switch (key) {
      case 'sozluk':
        qs = vocabQuestions(10);
      case 'mix':
        final cats = kCat.keys.where((c) => !kGroupCats.contains(c)).toList();
        final picked = <Question>[];
        for (final c in cats) {
          final l = leastSeen(questions.where((q) => q.cat == c).toList(), qid);
          if (l.isNotEmpty) picked.add(l.first);
        }
        qs = shuffled([...picked, ...vocabQuestions(12 - picked.length)]);
      case 'kelime':
        final h = leastSeen(questions.where((q) => q.cat == 'kelime').toList(), qid).take(6).toList();
        qs = shuffled([...h, ...vocabQuestions(10 - h.length)]);
      case 'cloze':
        qs = _pickGroups('cloze', 10);
      case 'okuma':
        qs = _pickGroups('okuma', 8);
      default:
        qs = leastSeen(questions.where((q) => q.cat == key).toList(), qid).take(10).toList();
    }
    return qs.map(prep).toList();
  }

  /// Bir kelime ve aynı kökten gelenlerle kısa test.
  List<Question> rootSet(Word w) {
    final pool = [w, ...sameRoot(w).where((x) => x.pos != 'h').take(6)].where((x) => x.pos != 'h').toList();
    final extra = leastSeen(words.where((x) => !pool.contains(x) && x.pos != 'h').toList(), (Word x) => x.id)
        .take(max(0, 5 - pool.length))
        .toList();
    return vocabQuestions(pool.length + extra.length, from: [...pool, ...extra]).map(prep).toList();
  }

  // ---------- güncel okuma metinleri ----------
  List<Passage> get readings => passages.values.where((p) => p.topic != null).toList();

  List<Question> passageQuestions(String pid) => questions.where((q) => q.pid == pid).toList();

  /// Bir metnin sorularındaki son durum: kaç soru çözüldü, kaçı en az bir kez doğru.
  ({int done, int right, int total}) readingStats(String pid) {
    final qs = passageQuestions(pid);
    var d = 0, r = 0;
    for (final q in qs) {
      if ((seen[q.id] ?? 0) > 0) d++;
      if ((right[q.id] ?? 0) > 0) r++;
    }
    return (done: d, right: r, total: qs.length);
  }

  // ---------- harf-i cerli kalıplar ----------
  List<Word> get prepVerbs => words.where((w) => w.pos == 'h' && w.tag != 'kalip').toList();
  List<Word> get prepPhrases => words.where((w) => w.pos == 'h' && w.tag == 'kalip').toList();
  Topic? get prepTopic {
    for (final t in topics) {
      if (t.id == 'harfcer') return t;
    }
    return null;
  }

  List<Question> flaggedSet() => questions.where((q) => flagged.contains(q.id)).map(prep).toList();

  // ---------- konular ----------
  Topic? topicFor(String kind) => topicByKind[kind];

  List<Question> topicQuestions(Topic t) => questions.where((q) => t.kinds.contains(q.kind)).toList();

  List<Question> topicSet(Topic t) =>
      leastSeen(topicQuestions(t), (Question q) => q.id).take(10).map(prep).toList();

  ({int right, int seen}) topicStats(Topic t) {
    var r = 0, s = 0;
    for (final q in topicQuestions(t)) {
      s += seen[q.id] ?? 0;
      r += right[q.id] ?? 0;
    }
    return (right: r, seen: s);
  }

  // ---------- kelime kartları ----------
  List<Word> deckPool(String key) {
    switch (key) {
      case 'all':
        return words;
      case 'hard':
        return words.where((w) => cards[w.id] != null && cards[w.id]![0] <= 1).toList();
      case 'saved':
        return words.where((w) => saved.contains(w.id)).toList();
      case 'yds':
        return words.where((w) => w.yds.isNotEmpty).toList();
      default:
        if (key.startsWith('k:')) {
          final k = key.substring(2);
          return words.where((w) => w.konu == k).toList();
        }
        return words.where((w) => w.pos == key).toList();
    }
  }

  int deckDue(String key) {
    final today = epochDay();
    return deckPool(key).where((w) => cards[w.id] != null && cards[w.id]![1] <= today).length;
  }

  int get cardsSeen => cards.length;

  /// Oturum: önce vadesi gelenler, sonra hiç görülmemiş kartlar.
  List<Word> cardSession(String key, {int size = 20}) {
    final today = epochDay();
    final pool = deckPool(key);
    final due = pool.where((w) => cards[w.id] != null && cards[w.id]![1] <= today).toList()
      ..sort((a, b) => cards[a.id]![1].compareTo(cards[b.id]![1]));
    final fresh = shuffled(pool.where((w) => cards[w.id] == null).toList());
    final out = [...due, ...fresh].take(size).toList();
    if (out.length < size) {
      final rest = shuffled(pool.where((w) => !out.contains(w)).toList());
      out.addAll(rest.take(size - out.length));
    }
    return out;
  }

  /// Biliyorum: bir sonraki kutu. Bilmiyorum: ilk kutu, bugün yine sorulur.
  void rateCard(String id, bool known) {
    final today = epochDay();
    final c = cards[id];
    if (known) {
      final box = min(max(c?[0] ?? 1, 1) + 1, srsDays.length - 1);
      cards[id] = [box, today + srsDays[box]];
    } else {
      cards[id] = [1, today];
    }
    _save();
  }

  void cardsChanged() => notifyListeners();

  // ---------- analiz ----------
  Map<String, ({int c, int t})> catStats() {
    final m = <String, List<int>>{};
    for (final r in log) {
      r.cats.forEach((k, v) {
        final x = m.putIfAbsent(k, () => [0, 0]);
        x[0] += v[0];
        x[1] += v[1];
      });
    }
    return m.map((k, v) => MapEntry(k, (c: v[0], t: v[1])));
  }

  /// Bölüm başarılarını deneme düzenine uygular. En az 30 cevap gerekir.
  ({double score, int answered})? predictedScore() {
    final s = catStats();
    var tc = 0, tt = 0;
    for (final v in s.values) {
      tc += v.c;
      tt += v.t;
    }
    if (tt < 30) return null;
    final overall = tc / tt;
    var expected = 0.0;
    for (final (cat, n) in kExamPlan) {
      final v = s[cat];
      final acc = (v != null && v.t >= 5) ? v.c / v.t : overall;
      expected += n * acc;
    }
    return (score: expected * 1.25, answered: tt);
  }

  List<SetResult> get examResults => log.where((r) => r.key == 'deneme').toList();
}
