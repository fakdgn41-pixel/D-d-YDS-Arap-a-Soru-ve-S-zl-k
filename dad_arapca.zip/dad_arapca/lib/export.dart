import 'dart:io';

import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import 'models.dart';
import 'state.dart';

/// Tüm çalışma günlerini bir Excel dosyasına yazar ve paylaşım menüsünü açar.
/// "Özet" sayfası gün toplamlarını, her gün sayfası set ayrıntılarını ve
/// kaçırılan soruları içerir.
Future<void> shareExcel() async {
  final st = AppState.I;
  final excel = Excel.createExcel();
  final first = excel.getDefaultSheet() ?? 'Sheet1';
  excel.rename(first, 'Özet');

  CellValue t(String s) => TextCellValue(s);
  CellValue n(int v) => IntCellValue(v);

  final ozet = excel['Özet'];
  ozet.appendRow([t('Tarih'), t('Set sayısı'), t('Doğru'), t('Toplam'), t('Başarı %'), t('Süre (dk:sn)')]);
  for (final d in st.days) {
    final x = st.dayTotals(d);
    ozet.appendRow([
      t(_trDay(d)),
      n(x.sets),
      n(x.correct),
      n(x.total),
      n(x.total == 0 ? 0 : (x.correct * 100 / x.total).round()),
      t(fmtSec(x.sec)),
    ]);
  }

  for (final d in st.days) {
    final sheet = excel[_trDay(d)];
    sheet.appendRow([t('Set'), t('Doğru'), t('Toplam'), t('Başarı %'), t('Süre (dk:sn)'), t('Kaçırılan')]);
    for (final r in st.resultsOn(d)) {
      sheet.appendRow([
        t(r.name),
        n(r.correct),
        n(r.total),
        n(r.pct),
        t(fmtSec(r.sec)),
        n(r.missed.length),
      ]);
    }
    final x = st.dayTotals(d);
    sheet.appendRow([
      t('GÜN TOPLAMI'),
      n(x.correct),
      n(x.total),
      n(x.total == 0 ? 0 : (x.correct * 100 / x.total).round()),
      t(fmtSec(x.sec)),
      n(x.total - x.correct),
    ]);
    final missed = [for (final r in st.resultsOn(d)) for (final m in r.missed) (r.name, m)];
    if (missed.isNotEmpty) {
      sheet.appendRow([t('')]);
      sheet.appendRow([t('Kaçırılan sorular')]);
      sheet.appendRow([t('Set'), t('Soru türü'), t('Soru'), t('Doğru cevap')]);
      for (final (name, m) in missed) {
        sheet.appendRow([t(name), t(m.kind), t(m.stem), t(m.answer)]);
      }
    }
  }
  excel.setDefaultSheet('Özet');

  final bytes = excel.save();
  if (bytes == null) throw Exception('Excel dosyası oluşturulamadı');
  final dir = await getTemporaryDirectory();
  final file = File('${dir.path}/dad-arapca-sonuclar-${dayKey()}.xlsx');
  await file.writeAsBytes(bytes, flush: true);
  await Share.shareXFiles(
    [XFile(file.path, mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')],
    subject: 'Dâd Arapça çalışma sonuçları',
  );
}

String _trDay(String key) {
  final d = parseDay(key);
  return '${two(d.day)}.${two(d.month)}.${d.year}';
}
