import 'dart:convert';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;

import 'theme.dart';

/// Arapça seslendirmeler: assets/audio/<anahtar>.mp3, metin -> anahtar eşlemesi index.json'da.
class Sound {
  Sound._();
  static final Sound I = Sound._();

  Map<String, String> _index = {};
  AudioPlayer? _player;

  /// Şu an çalan metin (yoksa null).
  final ValueNotifier<String?> playing = ValueNotifier(null);

  Future<void> load() async {
    try {
      final raw = jsonDecode(await rootBundle.loadString('assets/audio/index.json'));
      if (raw is Map) _index = raw.map((k, v) => MapEntry(k as String, v as String));
    } catch (_) {
      _index = {};
    }
  }

  bool has(String text) => _index.containsKey(text);

  Future<void> toggle(String text) async {
    final k = _index[text];
    if (k == null) return;
    final p = _player ??= AudioPlayer()..onPlayerComplete.listen((_) => playing.value = null);
    if (playing.value == text) {
      await p.stop();
      playing.value = null;
      return;
    }
    try {
      await p.stop();
      playing.value = text;
      await p.play(AssetSource('audio/$k.mp3'));
    } catch (_) {
      playing.value = null;
    }
  }

  Future<void> stop() async {
    await _player?.stop();
    playing.value = null;
  }
}

/// Küçük hoparlör düğmesi. Ses dosyası yoksa hiç görünmez.
class SpeakButton extends StatelessWidget {
  final String text;
  final double size;
  const SpeakButton(this.text, {super.key, this.size = 22});

  @override
  Widget build(BuildContext context) {
    if (!Sound.I.has(text)) return const SizedBox.shrink();
    return ValueListenableBuilder<String?>(
      valueListenable: Sound.I.playing,
      builder: (context, now, _) {
        final on = now == text;
        return IconButton(
          visualDensity: VisualDensity.compact,
          tooltip: on ? 'Durdur' : 'Dinle',
          onPressed: () => Sound.I.toggle(text),
          icon: Icon(on ? Icons.stop_circle_rounded : Icons.volume_up_rounded,
              size: size, color: on ? C.gold : C.accent),
        );
      },
    );
  }
}

/// Okuma metni için geniş "Dinle" düğmesi.
class ListenButton extends StatelessWidget {
  final String text;
  const ListenButton(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    if (!Sound.I.has(text)) return const SizedBox.shrink();
    return ValueListenableBuilder<String?>(
      valueListenable: Sound.I.playing,
      builder: (context, now, _) {
        final on = now == text;
        return TextButton.icon(
          onPressed: () => Sound.I.toggle(text),
          icon: Icon(on ? Icons.stop_rounded : Icons.volume_up_rounded, size: 20),
          label: Text(on ? 'Durdur' : 'Metni dinle'),
        );
      },
    );
  }
}
