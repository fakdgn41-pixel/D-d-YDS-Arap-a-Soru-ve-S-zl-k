import 'package:flutter/material.dart';

import 'models.dart';
import 'screens/topics.dart';
import 'screens/word.dart';
import 'state.dart';
import 'theme.dart';
import 'widgets.dart';

/// Bir sorunun tamamı: parça, kök, şıklar ve (istenirse) açıklama.
/// - Pratik: [reveal] cevap verilince true olur.
/// - Deneme: [reveal] false, seçili şık vurgulanır, değiştirilebilir.
/// - İnceleme: [reveal] true, [onSelect] null.
class QuestionView extends StatelessWidget {
  final Question q;
  final int? chosen;
  final bool reveal;
  final ValueChanged<int>? onSelect;
  final bool showFeedback;

  const QuestionView({
    super.key,
    required this.q,
    this.chosen,
    this.reveal = false,
    this.onSelect,
    this.showFeedback = true,
  });

  @override
  Widget build(BuildContext context) {
    final passage = q.pid == null ? null : AppState.I.passages[q.pid];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(q.kind.toUpperCase(), style: labelCaps.copyWith(color: C.gold, letterSpacing: 1)),
        const SizedBox(height: 8),
        if (passage != null) ...[
          PassageCard(passage: passage, activeBlank: q.blank),
          const SizedBox(height: 12),
        ],
        Text(q.promptText, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, height: 1.4)),
        const SizedBox(height: 12),
        if (q.lines.isNotEmpty) ...[_stem(), const SizedBox(height: 14)],
        for (var j = 0; j < q.opts.length; j++) ...[_option(j), const SizedBox(height: 8)],
        if (reveal && showFeedback) ...[const SizedBox(height: 6), FeedbackCard(q: q, chosen: chosen)],
      ],
    );
  }

  Widget _stem() {
    final children = <Widget>[];
    for (final l in q.lines) {
      if (l.tr != null) {
        children.add(Text(l.tr!, style: const TextStyle(fontSize: 16.5, height: 1.5)));
      } else if (l.num != null) {
        children.add(Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 30,
              child: Padding(
                padding: const EdgeInsets.only(top: 14),
                child: Text(l.num!,
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: C.muted)),
              ),
            ),
            Expanded(child: ArStem(l.ar ?? '', size: 22)),
          ],
        ));
      } else {
        children.add(ArStem(l.ar ?? '', target: q.target, size: q.lines.length > 1 ? 22 : 26));
      }
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(color: C.sunk, borderRadius: BorderRadius.circular(18)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children),
    );
  }

  Widget _option(int j) {
    final isAns = j == q.ans;
    final isChosen = j == chosen;
    Color bg = C.surface, border = C.line, letterBg = C.sunk, letterFg = C.muted, text = C.ink;
    double bw = 1;
    String? tag;
    if (reveal) {
      if (isAns) {
        bg = C.goodSoft;
        border = C.good;
        letterBg = C.good;
        letterFg = Colors.white;
        bw = 1.5;
        tag = 'Doğru cevap';
      } else if (isChosen) {
        bg = C.badSoft;
        border = C.bad;
        letterBg = C.bad;
        letterFg = Colors.white;
        bw = 1.5;
        tag = 'Senin cevabın';
      } else {
        text = C.faint;
        letterBg = C.soft;
        letterFg = C.faint;
      }
    } else if (isChosen) {
      bg = C.accentSoft;
      border = C.accent;
      letterBg = C.accent;
      letterFg = Colors.white;
      bw = 1.5;
    }
    final letter = String.fromCharCode(65 + j);
    return Material(
      color: bg,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: border, width: bw),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onSelect == null ? null : () => onSelect!(j),
        child: ConstrainedBox(
          constraints: const BoxConstraints(minHeight: 56),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 6, 16, 6),
            child: Row(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: letterBg, shape: BoxShape.circle),
                  child: Text(letter,
                      style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: letterFg)),
                ),
                const SizedBox(width: 12),
                if (tag != null) ...[
                  Text(tag,
                      style: TextStyle(
                          fontSize: 12, fontWeight: FontWeight.w700, color: isAns ? C.good : C.bad)),
                  const SizedBox(width: 10),
                ],
                Expanded(
                  child: q.optAr
                      ? Ar(q.opts[j], size: 24, color: text, height: 1.7)
                      : Text(q.opts[j], style: TextStyle(fontSize: 15.5, height: 1.4, color: text)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Parça kartı. Cloze metnindeki [n] işaretleri numaralı boşluğa dönüşür;
/// sorulan boşluk vurgulanır.
class PassageCard extends StatefulWidget {
  final Passage passage;
  final int? activeBlank;
  const PassageCard({super.key, required this.passage, this.activeBlank});

  @override
  State<PassageCard> createState() => _PassageCardState();
}

class _PassageCardState extends State<PassageCard> {
  bool open = true;

  @override
  Widget build(BuildContext context) {
    final p = widget.passage;
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: C.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: C.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          InkWell(
            onTap: () => setState(() => open = !open),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 8, 10),
              child: Row(
                children: [
                  Expanded(
                      child: Text(p.cat == 'cloze' ? 'PARÇA (BOŞLUKLU)' : 'OKUMA PARÇASI', style: labelCaps)),
                  Text(open ? 'Gizle' : 'Göster',
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: C.accent)),
                  Icon(open ? Icons.expand_less_rounded : Icons.expand_more_rounded, color: C.accent),
                ],
              ),
            ),
          ),
          if (open)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
              child: _text(p.text),
            ),
        ],
      ),
    );
  }

  Widget _text(String s) {
    const size = 21.0;
    final base = const TextStyle(fontFamily: kArabic, fontSize: size, height: 2.0, color: C.ink);
    final spans = <InlineSpan>[];
    final re = RegExp(r'\[(\d)\]');
    var last = 0;
    for (final m in re.allMatches(s)) {
      spans.add(TextSpan(text: s.substring(last, m.start)));
      final n = int.parse(m.group(1)!);
      final active = n == widget.activeBlank;
      spans.add(WidgetSpan(
        alignment: PlaceholderAlignment.middle,
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 4),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 1),
          decoration: BoxDecoration(
            color: active ? C.goldSoft : C.soft,
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: active ? C.goldLine : C.line, width: active ? 2 : 1),
          ),
          child: Text('($n)',
              style: TextStyle(
                  fontFamily: kBody,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: active ? C.gold : C.muted)),
        ),
      ));
      last = m.end;
    }
    spans.add(TextSpan(text: s.substring(last)));
    return SizedBox(
      width: double.infinity,
      child: Text.rich(
        TextSpan(children: spans, style: base),
        textDirection: TextDirection.rtl,
        textAlign: TextAlign.justify,
        locale: const Locale('ar'),
      ),
    );
  }
}

/// Cevaptan sonra gösterilen açıklama kartı.
class FeedbackCard extends StatelessWidget {
  final Question q;
  final int? chosen;
  const FeedbackCard({super.key, required this.q, required this.chosen});

  @override
  Widget build(BuildContext context) {
    final ok = chosen == q.ans;
    final skipped = chosen == null;
    final color = ok ? C.good : C.bad;
    final w = q.word;
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: C.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: C.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(height: 3, color: color),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                      child: Icon(ok ? Icons.check_rounded : Icons.close_rounded,
                          color: Colors.white, size: 18),
                    ),
                    const SizedBox(width: 10),
                    Text(ok ? 'Doğru' : (skipped ? 'Boş bıraktın' : 'Yanlış'),
                        style: display(20, color: color)),
                  ],
                ),
                if (!ok) ...[
                  const SizedBox(height: 10),
                  Text('Doğru cevap: ${String.fromCharCode(65 + q.ans)}',
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: C.good)),
                ],
                for (final e in q.exp) ...[
                  const SizedBox(height: 8),
                  if (e.ar)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
                      decoration:
                          BoxDecoration(color: C.goodSoft, borderRadius: BorderRadius.circular(12)),
                      child: Ar(e.text, size: 23, height: 1.7),
                    )
                  else
                    Text(e.text, style: const TextStyle(fontSize: 15, height: 1.5)),
                ],
                if (AppState.I.topicFor(q.kind) != null) ...[
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton.icon(
                      onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => TopicScreen(topic: AppState.I.topicFor(q.kind)!))),
                      icon: const Icon(Icons.school_outlined, size: 18),
                      label: Text('Konu anlatımı: ${AppState.I.topicFor(q.kind)!.title}'),
                    ),
                  ),
                ],
                if (q.gloss.isNotEmpty && w == null) ...[
                  const SizedBox(height: 12),
                  const Divider(height: 1, color: C.line),
                  const SizedBox(height: 8),
                  const Text('KELİMELER', style: labelCaps),
                  for (final g in q.gloss) _glossRow(g[0], g[1]),
                ],
                if (w != null) ...[
                  const SizedBox(height: 12),
                  const Divider(height: 1, color: C.line),
                  const SizedBox(height: 8),
                  const Text('KELİME KARTI', style: labelCaps),
                  const SizedBox(height: 4),
                  Ar(w.ar, size: 30, height: 1.6),
                  if (w.extra.isNotEmpty) Ar(w.extra, size: 21, color: C.muted, height: 1.6),
                  const SizedBox(height: 2),
                  Text('${w.tr} · ${kPos[w.pos]}',
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                  if (w.ex.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Ar(w.ex, size: 21, height: 1.7),
                    Text(w.ext, style: const TextStyle(fontSize: 14, color: C.muted)),
                  ],
                  const SizedBox(height: 6),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton.icon(
                      onPressed: () => Navigator.of(context)
                          .push(MaterialPageRoute(builder: (_) => WordScreen(word: w))),
                      icon: const Icon(Icons.menu_book_outlined, size: 18),
                      label: const Text('Sözlükte aç'),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _glossRow(String ar, String tr) => Container(
        decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: C.soft))),
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          children: [
            Expanded(child: Text(tr, style: const TextStyle(fontSize: 14.5, color: C.muted))),
            const SizedBox(width: 12),
            Flexible(child: Ar(ar, size: 22, height: 1.7)),
          ],
        ),
      );
}
