/// Boşluk işareti: soru metinlerinde bu dizgi boşluk çizgisine dönüşür.
const String kBlank = '------';

class Line {
  final String? ar; // Arapça satır
  final String? tr; // Türkçe satır
  final String? num; // I, II ... (paragraf soruları)
  final bool passage; // okuma parçası

  const Line({this.ar, this.tr, this.num, this.passage = false});

  factory Line.fromJson(Map<String, dynamic> j) => Line(
        ar: j['a'] as String?,
        tr: j['t'] as String?,
        num: j['n'] as String?,
        passage: j['p'] == true,
      );
}

/// Açıklama parçası: Türkçe cümle ya da kendi satırında duran Arapça örnek.
class Exp {
  final String text;
  final bool ar;
  const Exp(this.text, this.ar);

  factory Exp.fromJson(Map<String, dynamic> j) =>
      j['a'] != null ? Exp(j['a'] as String, true) : Exp(j['t'] as String, false);
}

class Word {
  final String id, ar, root, extra, tr, pos;
  const Word({
    required this.id,
    required this.ar,
    required this.root,
    required this.extra,
    required this.tr,
    required this.pos,
  });

  factory Word.fromJson(Map<String, dynamic> j) => Word(
        id: j['id'] as String,
        ar: j['ar'] as String,
        root: (j['root'] as String?) ?? '',
        extra: (j['extra'] as String?) ?? '',
        tr: j['tr'] as String,
        pos: j['pos'] as String,
      );

  /// Kök harflerini aralarında boşlukla yazar.
  String get rootSpaced => root.split('').join(' ');
}

const Map<String, String> kPos = {
  'f': 'Fiil',
  'i': 'İsim',
  's': 'Sıfat',
  'b': 'Bağlaç',
};

const Map<String, String> kCat = {
  'kelime': 'Kelime',
  'gramer': 'Dilbilgisi',
  'ceviri': 'Çeviri',
  'tamamlama': 'Tamamlama',
  'okuma': 'Okuma',
};

class Question {
  final String id, cat, kind, prompt;
  final List<Line> lines;
  final List<String> opts;
  final bool optAr;
  final int ans;
  final List<Exp> exp;
  final List<List<String>> gloss;
  final String? target;
  final bool noShuffle;
  final Word? word;

  const Question({
    required this.id,
    required this.cat,
    required this.kind,
    required this.prompt,
    required this.lines,
    required this.opts,
    required this.optAr,
    required this.ans,
    this.exp = const [],
    this.gloss = const [],
    this.target,
    this.noShuffle = false,
    this.word,
  });

  factory Question.fromJson(Map<String, dynamic> j) => Question(
        id: j['id'] as String,
        cat: j['cat'] as String,
        kind: j['kind'] as String,
        prompt: j['prompt'] as String,
        lines: (j['lines'] as List)
            .map((e) => Line.fromJson(e as Map<String, dynamic>))
            .toList(),
        opts: (j['opts'] as List).map((e) => e as String).toList(),
        optAr: j['optAr'] == true,
        ans: j['ans'] as int,
        exp: ((j['exp'] as List?) ?? const [])
            .map((e) => Exp.fromJson(e as Map<String, dynamic>))
            .toList(),
        gloss: ((j['gloss'] as List?) ?? const [])
            .map((e) => (e as List).map((x) => x as String).toList())
            .toList(),
        target: j['target'] as String?,
        noShuffle: j['noShuffle'] == true,
      );

  Question withOptions(List<String> o, int a) => Question(
        id: id,
        cat: cat,
        kind: kind,
        prompt: prompt,
        lines: lines,
        opts: o,
        optAr: optAr,
        ans: a,
        exp: exp,
        gloss: gloss,
        target: target,
        noShuffle: noShuffle,
        word: word,
      );

  /// Sonuç ekranında gösterilecek kök cümle (son satır).
  Line get stemLine => lines.last;
}

class Missed {
  final String kind, stem, answer;
  final bool stemAr, answerAr;
  const Missed({
    required this.kind,
    required this.stem,
    required this.stemAr,
    required this.answer,
    required this.answerAr,
  });

  factory Missed.of(Question q) {
    final l = q.stemLine;
    return Missed(
      kind: q.kind,
      stem: (l.ar ?? l.tr ?? '').replaceAll(kBlank, '…'),
      stemAr: l.ar != null,
      answer: q.opts[q.ans],
      answerAr: q.optAr,
    );
  }

  Map<String, dynamic> toJson() =>
      {'k': kind, 's': stem, 'sa': stemAr, 'a': answer, 'aa': answerAr};

  factory Missed.fromJson(Map<String, dynamic> j) => Missed(
        kind: j['k'] as String,
        stem: j['s'] as String,
        stemAr: j['sa'] == true,
        answer: j['a'] as String,
        answerAr: j['aa'] == true,
      );
}

class SetResult {
  final String day; // 2026-10-16
  final int ts;
  final String key, name;
  final int correct, total, sec;
  final List<Missed> missed;
  final Map<String, List<int>> cats; // kategori -> [doğru, toplam]

  const SetResult({
    required this.day,
    required this.ts,
    required this.key,
    required this.name,
    required this.correct,
    required this.total,
    required this.sec,
    required this.missed,
    required this.cats,
  });

  int get pct => total == 0 ? 0 : (correct * 100 / total).round();

  Map<String, dynamic> toJson() => {
        'd': day,
        'ts': ts,
        'key': key,
        'name': name,
        'c': correct,
        't': total,
        'sec': sec,
        'missed': missed.map((m) => m.toJson()).toList(),
        'cats': cats,
      };

  factory SetResult.fromJson(Map<String, dynamic> j) => SetResult(
        day: j['d'] as String,
        ts: j['ts'] as int,
        key: (j['key'] as String?) ?? 'mix',
        name: j['name'] as String,
        correct: j['c'] as int,
        total: j['t'] as int,
        sec: j['sec'] as int,
        missed: ((j['missed'] as List?) ?? const [])
            .map((e) => Missed.fromJson(e as Map<String, dynamic>))
            .toList(),
        cats: ((j['cats'] as Map?) ?? const {}).map((k, v) => MapEntry(
            k as String, (v as List).map((x) => x as int).toList())),
      );
}

class SetDef {
  final String key, title, desc;
  final int count;
  const SetDef(this.key, this.title, this.desc, this.count);
}

const List<SetDef> kSets = [
  SetDef('mix', 'Karışık deneme', 'her bölümden', 12),
  SetDef('kelime', 'Kelime ve edat', 'boşluk, eş ve zıt anlam', 10),
  SetDef('gramer', 'Dilbilgisi', 'kâne, inne, sayılar, şart', 8),
  SetDef('ceviri', 'Çeviri', 'iki yönlü', 5),
  SetDef('tamamlama', 'Tamamlama ve diyalog', 'cümle ve diyalog', 5),
  SetDef('okuma', 'Okuma ve paragraf', 'parça ve akış', 3),
  SetDef('sozluk', 'Sözlük testi', 'sözlükten anlam soruları', 10),
];

// ---------- tarih ve süre yardımcıları ----------
String two(int n) => n.toString().padLeft(2, '0');
String dayKey([DateTime? d]) {
  final x = d ?? DateTime.now();
  return '${x.year}-${two(x.month)}-${two(x.day)}';
}

DateTime parseDay(String k) {
  final p = k.split('-').map(int.parse).toList();
  return DateTime(p[0], p[1], p[2]);
}

const List<String> kMonths = [
  'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
  'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'
];
const List<String> kWeekdays = [
  'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'
];
const List<String> kWeekShort = ['Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct', 'Pz'];

String trDate(DateTime d, {bool weekday = false}) =>
    '${d.day} ${kMonths[d.month - 1]}${weekday ? ', ${kWeekdays[d.weekday - 1]}' : ''}';

String fmtSec(num s) {
  final t = s.round();
  return '${t ~/ 60}:${two(t % 60)}';
}
