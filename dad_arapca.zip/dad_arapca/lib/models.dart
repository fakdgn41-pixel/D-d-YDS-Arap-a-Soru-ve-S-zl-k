/// Boşluk işareti: soru metinlerinde bu dizgi boşluk çizgisine dönüşür.
const String kBlank = '------';

class Line {
  final String? ar; // Arapça satır
  final String? tr; // Türkçe satır
  final String? num; // I, II ... (paragraf soruları)
  final bool passage; // okuma parçası

  const Line({this.ar, this.tr, this.num, this.passage = false});

  factory Line.fromJson(Map<String, dynamic> j) => Line(
        ar: j['a'] as String?,
        tr: j['t'] as String?,
        num: j['n'] as String?,
        passage: j['p'] == true,
      );
}

/// Açıklama parçası: Türkçe cümle ya da kendi satırında duran Arapça örnek.
class Exp {
  final String text;
  final bool ar;
  const Exp(this.text, this.ar);

  factory Exp.fromJson(Map<String, dynamic> j) =>
      j['a'] != null ? Exp(j['a'] as String, true) : Exp(j['t'] as String, false);
}

/// Okuma ya da paragraf boşluk doldurma parçası. Cloze metninde boşluklar [1]..[5].
class Passage {
  final String id, cat, text;
  final String? tr;
  const Passage({required this.id, required this.cat, required this.text, this.tr});

  factory Passage.fromJson(Map<String, dynamic> j) => Passage(
        id: j['id'] as String,
        cat: j['cat'] as String,
        text: j['text'] as String,
        tr: j['tr'] as String?,
      );
}

class Word {
  final String id, ar, root, extra, tr, pos;
  final String ex, ext; // örnek cümle ve çevirisi
  const Word({
    required this.id,
    required this.ar,
    required this.root,
    required this.extra,
    required this.tr,
    required this.pos,
    this.ex = '',
    this.ext = '',
  });

  factory Word.fromJson(Map<String, dynamic> j) => Word(
        id: j['id'] as String,
        ar: j['ar'] as String,
        root: (j['root'] as String?) ?? '',
        extra: (j['extra'] as String?) ?? '',
        tr: j['tr'] as String,
        pos: j['pos'] as String,
        ex: (j['ex'] as String?) ?? '',
        ext: (j['ext'] as String?) ?? '',
      );

  /// Kök harflerini aralarında boşlukla yazar.
  String get rootSpaced => root.split('').join(' ');
}

const Map<String, String> kPos = {
  'f': 'Fiil',
  'i': 'İsim',
  's': 'Sıfat',
  'b': 'Edat ve zarf',
};

/// Bölümler, YDS'deki sıralarıyla.
const Map<String, String> kCat = {
  'kelime': 'Kelime',
  'gramer': 'Dilbilgisi',
  'cloze': 'Paragrafta boşluk',
  'tamamlama': 'Cümle tamamlama',
  'ceviri': 'Çeviri',
  'okuma': 'Okuma',
  'diyalog': 'Diyalog',
  'anlam': 'Anlamca yakın',
  'paragraf': 'Paragraf tamamlama',
  'akis': 'Akışı bozan',
};

/// Parça soruları (aynı metne bağlı birden fazla soru).
const Set<String> kGroupCats = {'cloze', 'okuma'};

/// Deneme sınavı düzeni: bölüm -> soru sayısı (toplam 80).
const List<(String, int)> kExamPlan = [
  ('kelime', 6),
  ('gramer', 10),
  ('cloze', 10),
  ('tamamlama', 10),
  ('ceviri', 6),
  ('okuma', 20),
  ('diyalog', 5),
  ('anlam', 4),
  ('paragraf', 4),
  ('akis', 5),
];
const int kExamSeconds = 180 * 60;

class Question {
  final String id, cat, kind, prompt;
  final List<Line> lines;
  final List<String> opts;
  final bool optAr;
  final int ans;
  final List<Exp> exp;
  final List<List<String>> gloss;
  final String? target;
  final bool noShuffle;
  final Word? word;
  final String? pid; // bağlı olduğu parça
  final int? blank; // cloze: parçadaki boşluk numarası

  const Question({
    required this.id,
    required this.cat,
    required this.kind,
    required this.prompt,
    required this.lines,
    required this.opts,
    required this.optAr,
    required this.ans,
    this.exp = const [],
    this.gloss = const [],
    this.target,
    this.noShuffle = false,
    this.word,
    this.pid,
    this.blank,
  });

  /// Cloze sorularında yönergeye boşluk numarası eklenir.
  String get promptText =>
      blank == null ? prompt : 'Parçadaki ($blank) numaralı boşluğa uygun düşen ifade hangisidir?';

  factory Question.fromJson(Map<String, dynamic> j) => Question(
        id: j['id'] as String,
        cat: j['cat'] as String,
        kind: j['kind'] as String,
        prompt: j['prompt'] as String,
        lines: (j['lines'] as List)
            .map((e) => Line.fromJson(e as Map<String, dynamic>))
            .toList(),
        opts: (j['opts'] as List).map((e) => e as String).toList(),
        optAr: j['optAr'] == true,
        ans: j['ans'] as int,
        exp: ((j['exp'] as List?) ?? const [])
            .map((e) => Exp.fromJson(e as Map<String, dynamic>))
            .toList(),
        gloss: ((j['gloss'] as List?) ?? const [])
            .map((e) => (e as List).map((x) => x as String).toList())
            .toList(),
        target: j['target'] as String?,
        noShuffle: j['noShuffle'] == true,
        pid: j['pid'] as String?,
        blank: j['b'] as int?,
      );

  Question withOptions(List<String> o, int a) => Question(
        id: id,
        cat: cat,
        kind: kind,
        prompt: prompt,
        lines: lines,
        opts: o,
        optAr: optAr,
        ans: a,
        exp: exp,
        gloss: gloss,
        target: target,
        noShuffle: noShuffle,
        word: word,
        pid: pid,
        blank: blank,
      );

  /// Sonuç ekranında gösterilecek kök cümle (son satır).
  Line? get stemLine => lines.isEmpty ? null : lines.last;
}

class Missed {
  final String kind, stem, answer;
  final bool stemAr, answerAr;
  const Missed({
    required this.kind,
    required this.stem,
    required this.stemAr,
    required this.answer,
    required this.answerAr,
  });

  factory Missed.of(Question q) {
    final l = q.stemLine;
    final stem = l == null
        ? 'Parçadaki (${q.blank ?? '?'}) numaralı boşluk'
        : (l.ar ?? l.tr ?? '').replaceAll(kBlank, '…');
    return Missed(
      kind: q.kind,
      stem: stem,
      stemAr: l?.ar != null,
      answer: q.opts[q.ans],
      answerAr: q.optAr,
    );
  }

  Map<String, dynamic> toJson() =>
      {'k': kind, 's': stem, 'sa': stemAr, 'a': answer, 'aa': answerAr};

  factory Missed.fromJson(Map<String, dynamic> j) => Missed(
        kind: j['k'] as String,
        stem: j['s'] as String,
        stemAr: j['sa'] == true,
        answer: j['a'] as String,
        answerAr: j['aa'] == true,
      );
}

class SetResult {
  final String day; // 2026-10-16
  final int ts;
  final String key, name;
  final int correct, total, sec;
  final List<Missed> missed;
  final Map<String, List<int>> cats; // kategori -> [doğru, toplam]

  const SetResult({
    required this.day,
    required this.ts,
    required this.key,
    required this.name,
    required this.correct,
    required this.total,
    required this.sec,
    required this.missed,
    required this.cats,
  });

  int get pct => total == 0 ? 0 : (correct * 100 / total).round();

  Map<String, dynamic> toJson() => {
        'd': day,
        'ts': ts,
        'key': key,
        'name': name,
        'c': correct,
        't': total,
        'sec': sec,
        'missed': missed.map((m) => m.toJson()).toList(),
        'cats': cats,
      };

  factory SetResult.fromJson(Map<String, dynamic> j) => SetResult(
        day: j['d'] as String,
        ts: j['ts'] as int,
        key: (j['key'] as String?) ?? 'mix',
        name: j['name'] as String,
        correct: j['c'] as int,
        total: j['t'] as int,
        sec: j['sec'] as int,
        missed: ((j['missed'] as List?) ?? const [])
            .map((e) => Missed.fromJson(e as Map<String, dynamic>))
            .toList(),
        cats: ((j['cats'] as Map?) ?? const {}).map((k, v) => MapEntry(
            k as String, (v as List).map((x) => x as int).toList())),
      );
}

class SetDef {
  final String key, title, desc;
  final int count;
  const SetDef(this.key, this.title, this.desc, this.count);
}

const List<SetDef> kSets = [
  SetDef('mix', 'Karışık set', 'her bölümden', 12),
  SetDef('kelime', 'Kelime ve edat', 'boşluk, eş ve zıt anlam', 10),
  SetDef('gramer', 'Dilbilgisi', 'nahiv ve sarf', 10),
  SetDef('cloze', 'Paragrafta boşluk', '2 parça', 10),
  SetDef('tamamlama', 'Cümle tamamlama', 'şart, bağlaç, anlam', 10),
  SetDef('ceviri', 'Çeviri', 'iki yönlü', 10),
  SetDef('okuma', 'Okuma parçası', '2 parça', 8),
  SetDef('diyalog', 'Diyalog', 'boşluğu tamamla', 10),
  SetDef('anlam', 'Anlamca yakın cümle', 'aynı anlamı bul', 10),
  SetDef('paragraf', 'Paragraf tamamlama', 'akışa uygun cümle', 10),
  SetDef('akis', 'Akışı bozan cümle', 'konu dışını bul', 10),
  SetDef('sozluk', 'Sözlük testi', 'sözlükten anlam soruları', 10),
];

SetDef setDef(String key) => kSets.firstWhere((s) => s.key == key,
    orElse: () => SetDef(key, kSpecialNames[key] ?? 'Set', '', 10));

const Map<String, String> kSpecialNames = {
  'redo': 'Yanlışları tekrar',
  'flag': 'İşaretlediklerim',
  'srs': 'Akıllı tekrar',
  'kok': 'Kök testi',
  'deneme': 'Deneme sınavı',
};

/// Yerel takvim günü (gün sayısı olarak).
int epochDay([DateTime? d]) {
  final x = d ?? DateTime.now();
  return DateTime.utc(x.year, x.month, x.day).millisecondsSinceEpoch ~/ 86400000;
}

// ---------- tarih ve süre yardımcıları ----------
String two(int n) => n.toString().padLeft(2, '0');
String dayKey([DateTime? d]) {
  final x = d ?? DateTime.now();
  return '${x.year}-${two(x.month)}-${two(x.day)}';
}

DateTime parseDay(String k) {
  final p = k.split('-').map(int.parse).toList();
  return DateTime(p[0], p[1], p[2]);
}

const List<String> kMonths = [
  'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
  'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'
];
const List<String> kWeekdays = [
  'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'
];
const List<String> kWeekShort = ['Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct', 'Pz'];

String trDate(DateTime d, {bool weekday = false}) =>
    '${d.day} ${kMonths[d.month - 1]}${weekday ? ', ${kWeekdays[d.weekday - 1]}' : ''}';

String fmtSec(num s) {
  final t = s.round();
  return '${t ~/ 60}:${two(t % 60)}';
}
