/// Boşluk işareti: soru metinlerinde bu dizgi boşluk çizgisine dönüşür.
const String kBlank = '------';

class Line {
  final String? ar; // Arapça satır
  final String? tr; // Türkçe satır
  final String? num; // I, II ... (paragraf soruları)
  final bool passage; // okuma parçası

  const Line({this.ar, this.tr, this.num, this.passage = false});

  factory Line.fromJson(Map<String, dynamic> j) => Line(
        ar: j['a'] as String?,
        tr: j['t'] as String?,
        num: j['n'] as String?,
        passage: j['p'] == true,
      );
}

/// Açıklama parçası: Türkçe cümle ya da kendi satırında duran Arapça örnek.
class Exp {
  final String text;
  final bool ar;
  const Exp(this.text, this.ar);

  factory Exp.fromJson(Map<String, dynamic> j) =>
      j['a'] != null ? Exp(j['a'] as String, true) : Exp(j['t'] as String, false);
}

/// Okuma ya da paragraf boşluk doldurma parçası. Cloze metninde boşluklar [1]..[5].
class Passage {
  final String id, cat, text;
  final String? tr;
  final String? title, topic; // güncel okuma metinleri
  final List<List<String>> gloss; // önemli kelimeler: [Arapça, Türkçe]
  const Passage({
    required this.id,
    required this.cat,
    required this.text,
    this.tr,
    this.title,
    this.topic,
    this.gloss = const [],
  });

  factory Passage.fromJson(Map<String, dynamic> j) => Passage(
        id: j['id'] as String,
        cat: j['cat'] as String,
        text: j['text'] as String,
        tr: j['tr'] as String?,
        title: j['title'] as String?,
        topic: j['topic'] as String?,
        gloss: ((j['gloss'] as List?) ?? const [])
            .map((e) => (e as List).map((x) => x as String).toList())
            .toList(),
      );
}

/// Güncel okuma metinlerinin konuları.
const Map<String, String> kReadTopics = {
  'uzay': 'Uzay',
  'sanayi': 'Sanayi',
  'futbol': 'Futbol',
  'siyaset': 'Siyaset',
  'ekonomi': 'Ekonomi',
  'saglik': 'Sağlık',
  'teknoloji': 'Teknoloji',
  'cevre': 'Çevre',
  'egitim': 'Eğitim',
  'kultur': 'Kültür',
  'tarih': 'Tarih',
  'bilim': 'Bilim',
  'turizm': 'Turizm',
  'toplum': 'Toplum',
  'medya': 'Medya',
  'enerji': 'Enerji',
};

class Word {
  final String id, ar, root, extra, tr, pos;
  final String ex, ext; // örnek cümle ve çevirisi
  final String tag; // harf-i cerli kalıplarda edat ya da "kalip"
  const Word({
    required this.id,
    required this.ar,
    required this.root,
    required this.extra,
    required this.tr,
    required this.pos,
    this.ex = '',
    this.ext = '',
    this.tag = '',
  });

  factory Word.fromJson(Map<String, dynamic> j) => Word(
        id: j['id'] as String,
        ar: j['ar'] as String,
        root: (j['root'] as String?) ?? '',
        extra: (j['extra'] as String?) ?? '',
        tr: j['tr'] as String,
        pos: j['pos'] as String,
        ex: (j['ex'] as String?) ?? '',
        ext: (j['ext'] as String?) ?? '',
        tag: (j['tag'] as String?) ?? '',
      );

  /// Kök harflerini aralarında boşlukla yazar.
  String get rootSpaced => root.split('').join(' ');
}

const Map<String, String> kPos = {
  'f': 'Fiil',
  'i': 'İsim',
  's': 'Sıfat',
  'b': 'Edat ve zarf',
  'h': 'Harf-i cerli',
};

/// Harf-i cerli fiillerde edat anahtarı -> Arapça yazılışı.
const Map<String, String> kPreps = {
  'fi': 'في',
  'ala': 'على',
  'an': 'عن',
  'min': 'من',
  'ila': 'إلى',
  'bi': 'بـ',
  'li': 'لـ',
  'maa': 'مع',
};

/// Bölümler, YDS'deki sıralarıyla.
const Map<String, String> kCat = {
  'kelime': 'Kelime',
  'gramer': 'Dilbilgisi',
  'cloze': 'Paragrafta boşluk',
  'tamamlama': 'Cümle tamamlama',
  'ceviri': 'Çeviri',
  'okuma': 'Okuma',
  'diyalog': 'Diyalog',
  'anlam': 'Anlamca yakın',
  'paragraf': 'Paragraf tamamlama',
  'akis': 'Akışı bozan',
  'harfcer': 'Harf-i cerli',
  'sarf': 'Sarf',
};

/// Parça soruları (aynı metne bağlı birden fazla soru).
const Set<String> kGroupCats = {'cloze', 'okuma'};

/// Deneme sınavı düzeni: bölüm -> soru sayısı (toplam 80).
const List<(String, int)> kExamPlan = [
  ('kelime', 6),
  ('gramer', 10),
  ('cloze', 10),
  ('tamamlama', 10),
  ('ceviri', 6),
  ('okuma', 20),
  ('diyalog', 5),
  ('anlam', 4),
  ('paragraf', 4),
  ('akis', 5),
];
const int kExamSeconds = 180 * 60;

class Question {
  final String id, cat, kind, prompt;
  final List<Line> lines;
  final List<String> opts;
  final bool optAr;
  final int ans;
  final List<Exp> exp;
  final List<List<String>> gloss;
  final String? target;
  final bool noShuffle;
  final Word? word;
  final String? pid; // bağlı olduğu parça
  final int? blank; // cloze: parçadaki boşluk numarası
  final bool hard; // YDS düzeyi soru: testlerde öne alınır

  const Question({
    required this.id,
    required this.cat,
    required this.kind,
    required this.prompt,
    required this.lines,
    required this.opts,
    required this.optAr,
    required this.ans,
    this.exp = const [],
    this.gloss = const [],
    this.target,
    this.noShuffle = false,
    this.word,
    this.pid,
    this.blank,
    this.hard = false,
  });

  /// Cloze sorularında yönergeye boşluk numarası eklenir.
  String get promptText =>
      blank == null ? prompt : 'Parçadaki ($blank) numaralı boşluğa uygun düşen ifade hangisidir?';

  factory Question.fromJson(Map<String, dynamic> j) => Question(
        id: j['id'] as String,
        cat: j['cat'] as String,
        kind: j['kind'] as String,
        prompt: j['prompt'] as String,
        lines: (j['lines'] as List)
            .map((e) => Line.fromJson(e as Map<String, dynamic>))
            .toList(),
        opts: (j['opts'] as List).map((e) => e as String).toList(),
        optAr: j['optAr'] == true,
        ans: j['ans'] as int,
        exp: ((j['exp'] as List?) ?? const [])
            .map((e) => Exp.fromJson(e as Map<String, dynamic>))
            .toList(),
        gloss: ((j['gloss'] as List?) ?? const [])
            .map((e) => (e as List).map((x) => x as String).toList())
            .toList(),
        target: j['target'] as String?,
        noShuffle: j['noShuffle'] == true,
        pid: j['pid'] as String?,
        blank: j['b'] as int?,
        hard: j['hard'] == true,
      );

  Question withOptions(List<String> o, int a) => Question(
        id: id,
        cat: cat,
        kind: kind,
        prompt: prompt,
        lines: lines,
        opts: o,
        optAr: optAr,
        ans: a,
        exp: exp,
        gloss: gloss,
        target: target,
        noShuffle: noShuffle,
        word: word,
        pid: pid,
        blank: blank,
        hard: hard,
      );

  /// Sonuç ekranında gösterilecek kök cümle (son satır).
  Line? get stemLine => lines.isEmpty ? null : lines.last;
}

class Missed {
  final String kind, stem, answer;
  final bool stemAr, answerAr;
  const Missed({
    required this.kind,
    required this.stem,
    required this.stemAr,
    required this.answer,
    required this.answerAr,
  });

  factory Missed.of(Question q) {
    final l = q.stemLine;
    final stem = l == null
        ? 'Parçadaki (${q.blank ?? '?'}) numaralı boşluk'
        : (l.ar ?? l.tr ?? '').replaceAll(kBlank, '…');
    return Missed(
      kind: q.kind,
      stem: stem,
      stemAr: l?.ar != null,
      answer: q.opts[q.ans],
      answerAr: q.optAr,
    );
  }

  Map<String, dynamic> toJson() =>
      {'k': kind, 's': stem, 'sa': stemAr, 'a': answer, 'aa': answerAr};

  factory Missed.fromJson(Map<String, dynamic> j) => Missed(
        kind: j['k'] as String,
        stem: j['s'] as String,
        stemAr: j['sa'] == true,
        answer: j['a'] as String,
        answerAr: j['aa'] == true,
      );
}

class SetResult {
  final String day; // 2026-10-16
  final int ts;
  final String key, name;
  final int correct, total, sec;
  final List<Missed> missed;
  final Map<String, List<int>> cats; // kategori -> [doğru, toplam]

  const SetResult({
    required this.day,
    required this.ts,
    required this.key,
    required this.name,
    required this.correct,
    required this.total,
    required this.sec,
    required this.missed,
    required this.cats,
  });

  int get pct => total == 0 ? 0 : (correct * 100 / total).round();

  Map<String, dynamic> toJson() => {
        'd': day,
        'ts': ts,
        'key': key,
        'name': name,
        'c': correct,
        't': total,
        'sec': sec,
        'missed': missed.map((m) => m.toJson()).toList(),
        'cats': cats,
      };

  factory SetResult.fromJson(Map<String, dynamic> j) => SetResult(
        day: j['d'] as String,
        ts: j['ts'] as int,
        key: (j['key'] as String?) ?? 'mix',
        name: j['name'] as String,
        correct: j['c'] as int,
        total: j['t'] as int,
        sec: j['sec'] as int,
        missed: ((j['missed'] as List?) ?? const [])
            .map((e) => Missed.fromJson(e as Map<String, dynamic>))
            .toList(),
        cats: ((j['cats'] as Map?) ?? const {}).map((k, v) => MapEntry(
            k as String, (v as List).map((x) => x as int).toList())),
      );
}

class SetDef {
  final String key, title, desc;
  final int count;
  const SetDef(this.key, this.title, this.desc, this.count);
}

const List<SetDef> kSets = [
  SetDef('mix', 'Karışık set', 'her bölümden', 12),
  SetDef('kelime', 'Kelime ve edat', 'boşluk, eş ve zıt anlam', 10),
  SetDef('gramer', 'Dilbilgisi', 'nahiv ve sarf', 10),
  SetDef('cloze', 'Paragrafta boşluk', '2 parça', 10),
  SetDef('tamamlama', 'Cümle tamamlama', 'şart, bağlaç, anlam', 10),
  SetDef('ceviri', 'Çeviri', 'iki yönlü', 10),
  SetDef('okuma', 'Okuma parçası', '2 parça', 8),
  SetDef('diyalog', 'Diyalog', 'boşluğu tamamla', 10),
  SetDef('anlam', 'Anlamca yakın cümle', 'aynı anlamı bul', 10),
  SetDef('paragraf', 'Paragraf tamamlama', 'akışa uygun cümle', 10),
  SetDef('akis', 'Akışı bozan cümle', 'konu dışını bul', 10),
  SetDef('sozluk', 'Sözlük testi', 'sözlükten anlam soruları', 10),
  SetDef('harfcer', 'Harf-i cerli kalıplar', 'fiil + edat, kalıp ifadeler', 10),
  SetDef('sarf', 'Sarf', 'bab, çekim, türemiş isimler', 10),
];

SetDef setDef(String key) => kSets.firstWhere((s) => s.key == key,
    orElse: () => SetDef(key, kSpecialNames[key] ?? 'Set', '', 10));

const Map<String, String> kSpecialNames = {
  'redo': 'Yanlışları tekrar',
  'flag': 'İşaretlediklerim',
  'srs': 'Akıllı tekrar',
  'kok': 'Kök testi',
  'konu': 'Konu soruları',
  'deneme': 'Deneme sınavı',
};

/// Yerel takvim günü (gün sayısı olarak).
int epochDay([DateTime? d]) {
  final x = d ?? DateTime.now();
  return DateTime.utc(x.year, x.month, x.day).millisecondsSinceEpoch ~/ 86400000;
}

// ---------- tarih ve süre yardımcıları ----------
String two(int n) => n.toString().padLeft(2, '0');
String dayKey([DateTime? d]) {
  final x = d ?? DateTime.now();
  return '${x.year}-${two(x.month)}-${two(x.day)}';
}

DateTime parseDay(String k) {
  final p = k.split('-').map(int.parse).toList();
  return DateTime(p[0], p[1], p[2]);
}

const List<String> kMonths = [
  'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
  'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'
];
const List<String> kWeekdays = [
  'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'
];
const List<String> kWeekShort = ['Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct', 'Pz'];

String trDate(DateTime d, {bool weekday = false}) =>
    '${d.day} ${kMonths[d.month - 1]}${weekday ? ', ${kWeekdays[d.weekday - 1]}' : ''}';

String fmtSec(num s) {
  final t = s.round();
  return '${t ~/ 60}:${two(t % 60)}';
}

// ---------- konu anlatımı ----------
/// Konu bloğu: başlık, metin, madde ya da Arapça örnek ve çevirisi.
class TopicBlock {
  final String? h, t, b, ar, tr;
  const TopicBlock({this.h, this.t, this.b, this.ar, this.tr});

  factory TopicBlock.fromJson(Map<String, dynamic> j) => TopicBlock(
        h: j['h'] as String?,
        t: j['t'] as String?,
        b: j['b'] as String?,
        ar: j['a'] as String?,
        tr: j['tr'] as String?,
      );
}

class Topic {
  final String id, title, group, intro;
  final List<TopicBlock> blocks;
  final List<String> kinds;
  const Topic({
    required this.id,
    required this.title,
    required this.group,
    required this.intro,
    required this.blocks,
    required this.kinds,
  });

  factory Topic.fromJson(Map<String, dynamic> j) => Topic(
        id: j['id'] as String,
        title: j['title'] as String,
        group: j['group'] as String,
        intro: j['intro'] as String,
        blocks: (j['blocks'] as List).map((e) => TopicBlock.fromJson(e as Map<String, dynamic>)).toList(),
        kinds: (j['kinds'] as List).map((e) => e as String).toList(),
      );
}

/// Kelime kartı destesi.
class Deck {
  final String key, title, desc;
  const Deck(this.key, this.title, this.desc);
}

const List<Deck> kDecks = [
  Deck('all', 'Bütün kelimeler', 'Önce tekrarı gelenler, sonra yeni kartlar'),
  Deck('hard', 'Zorlandıklarım', 'Bilmiyorum dediğin kartlar'),
  Deck('saved', 'Kaydettiklerim', 'Sözlükte kaydettiğin kelimeler'),
  Deck('f', 'Fiiller', 'Muzari ve edatlarıyla'),
  Deck('i', 'İsimler', 'Çoğullarıyla'),
  Deck('s', 'Sıfatlar', ''),
  Deck('b', 'Edat, zarf ve kalıplar', 'YDS bağlaçları dahil'),
  Deck('h', 'Harf-i cerli kalıplar', 'Fiil + edat ve kalıp ifadeler'),
];


// ---------------------------------------------------------------- Sarf
class Bab {
  final String key, name, group;
  final List<String> forms; // mazi, muzari, masdar, fâil, mef‘ûl, emir
  final List<String> meanings;
  final List<List<String>> examples; // fiil, anlam, cümle, çeviri
  const Bab(this.key, this.name, this.group, this.forms, this.meanings, this.examples);

  factory Bab.fromJson(Map<String, dynamic> j) => Bab(
        j['key'] as String,
        j['name'] as String,
        j['group'] as String,
        (j['forms'] as List).map((e) => e as String).toList(),
        (j['meanings'] as List).map((e) => e as String).toList(),
        (j['examples'] as List).map((e) => (e as List).map((x) => x as String).toList()).toList(),
      );
}

class ConjTable {
  final String id, verb, tr, type, note;
  final Map<String, List<String>> t;
  const ConjTable(this.id, this.verb, this.tr, this.type, this.note, this.t);

  factory ConjTable.fromJson(Map<String, dynamic> j) => ConjTable(
        j['id'] as String,
        j['verb'] as String,
        j['tr'] as String,
        j['type'] as String,
        (j['note'] as String?) ?? '',
        (j['t'] as Map).map((k, v) => MapEntry(k as String, (v as List).map((x) => x as String).toList())),
      );
}

class SarfData {
  final List<String> persons, personsTr;
  final List<int> emirIdx;
  final List<(String, String)> tenses;
  final List<Bab> babs;
  final List<ConjTable> tables;
  const SarfData(this.persons, this.personsTr, this.emirIdx, this.tenses, this.babs, this.tables);

  static const empty = SarfData([], [], [], [], [], []);

  factory SarfData.fromJson(Map<String, dynamic> j) => SarfData(
        (j['persons'] as List).map((e) => e as String).toList(),
        (j['personsTr'] as List).map((e) => e as String).toList(),
        (j['emirIdx'] as List).map((e) => e as int).toList(),
        (j['tenses'] as List).map((e) => ((e as Map)['k'] as String, e['tr'] as String)).toList(),
        (j['babs'] as List).map((e) => Bab.fromJson(e as Map<String, dynamic>)).toList(),
        (j['tables'] as List).map((e) => ConjTable.fromJson(e as Map<String, dynamic>)).toList(),
      );
}

// ---------------------------------------------------------------- Sıfırdan Arapça
class BasLetter {
  final String ch, name, tr, note, ex, ext;
  final List<String> forms; // tek, baş, orta, son
  const BasLetter(this.ch, this.name, this.tr, this.note, this.ex, this.ext, this.forms);

  factory BasLetter.fromJson(Map<String, dynamic> j) => BasLetter(
        j['ch'] as String,
        j['name'] as String,
        j['tr'] as String,
        j['note'] as String,
        j['ex'] as String,
        j['ext'] as String,
        (j['forms'] as List).map((e) => e as String).toList(),
      );
}

class BasLesson {
  final String id, title, intro;
  final List<TopicBlock> blocks;
  const BasLesson(this.id, this.title, this.intro, this.blocks);

  factory BasLesson.fromJson(Map<String, dynamic> j) => BasLesson(
        j['id'] as String,
        j['title'] as String,
        j['intro'] as String,
        (j['blocks'] as List).map((e) => TopicBlock.fromJson(e as Map<String, dynamic>)).toList(),
      );
}

class BasUnit {
  final String id, title, desc;
  final List<BasLesson> lessons;
  const BasUnit(this.id, this.title, this.desc, this.lessons);

  factory BasUnit.fromJson(Map<String, dynamic> j) => BasUnit(
        j['id'] as String,
        j['title'] as String,
        j['desc'] as String,
        (j['lessons'] as List).map((e) => BasLesson.fromJson(e as Map<String, dynamic>)).toList(),
      );
}

class BasData {
  final List<BasLetter> letters;
  final List<BasUnit> units;
  const BasData(this.letters, this.units);
  static const empty = BasData([], []);

  factory BasData.fromJson(Map<String, dynamic> j) => BasData(
        (j['letters'] as List).map((e) => BasLetter.fromJson(e as Map<String, dynamic>)).toList(),
        (j['units'] as List).map((e) => BasUnit.fromJson(e as Map<String, dynamic>)).toList(),
      );
}
