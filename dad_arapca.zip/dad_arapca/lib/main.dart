import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'screens/analysis.dart';
import 'screens/daily.dart';
import 'screens/dictionary.dart';
import 'notify.dart';
import 'screens/home.dart';
import 'screens/topics.dart';
import 'state.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppState.I.init();
  if (AppState.I.remindOn) {
    // Hatırlatma kuruluysa saat dilimi veya güncelleme sonrası yeniden planlanır.
    Reminder.schedule(AppState.I.remindHour, AppState.I.remindMinute).catchError((_) {});
  }
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
    systemNavigationBarColor: C.surface,
    systemNavigationBarIconBrightness: Brightness.dark,
  ));
  runApp(const DadApp());
}

class DadApp extends StatelessWidget {
  const DadApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Dâd Arapça',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        themeMode: ThemeMode.light,
        locale: const Locale('tr'),
        supportedLocales: const [Locale('tr')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: const Shell(),
      );
}

/// Alt sekme çubuğu: Pratik, Sözlük, Sonuçlar.
class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          bottom: false,
          child: IndexedStack(
            index: tab,
            children: [
              HomeScreen(onOpenResults: () => setState(() => tab = 3)),
              const TopicsScreen(),
              const DictionaryScreen(),
              const ResultsTab(),
            ],
          ),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(
                icon: Icon(Icons.check_box_outlined),
                selectedIcon: Icon(Icons.check_box),
                label: 'Pratik'),
            NavigationDestination(
                icon: Icon(Icons.school_outlined),
                selectedIcon: Icon(Icons.school),
                label: 'Konular'),
            NavigationDestination(
                icon: Icon(Icons.menu_book_outlined),
                selectedIcon: Icon(Icons.menu_book),
                label: 'Sözlük'),
            NavigationDestination(
                icon: Icon(Icons.bar_chart_outlined),
                selectedIcon: Icon(Icons.bar_chart),
                label: 'Sonuçlar'),
          ],
        ),
      );
}

/// Sonuçlar sekmesi: analiz ve günlük tablo arasında geçiş.
class ResultsTab extends StatefulWidget {
  const ResultsTab({super.key});

  @override
  State<ResultsTab> createState() => _ResultsTabState();
}

class _ResultsTabState extends State<ResultsTab> {
  int view = 0;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 0, label: Text('Analiz'), icon: Icon(Icons.insights_rounded)),
                ButtonSegment(value: 1, label: Text('Günlük'), icon: Icon(Icons.table_chart_outlined)),
              ],
              selected: {view},
              showSelectedIcon: false,
              onSelectionChanged: (v) => setState(() => view = v.first),
            ),
          ),
          Expanded(child: view == 0 ? const AnalysisView() : const DailyScreen()),
        ],
      );
}
