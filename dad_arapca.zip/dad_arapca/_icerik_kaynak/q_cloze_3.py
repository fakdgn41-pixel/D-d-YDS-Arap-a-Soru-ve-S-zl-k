# Paragrafta boşluk 3: YDS düzeyi
def c(opts, exp=None, gloss=None):
    return q(None, opts, exp or [], gloss or [])

PS = [
P('يشهد العالم منذ مطلع القرن الحادي والعشرين تحولا عميقا في سوق العمل، [1] باتت الأتمتة والذكاء الاصطناعي يؤديان مهام كانت حكرا على الإنسان. ولا يقتصر هذا التحول على الأعمال اليدوية [2]، بل يمتد إلى مهن تتطلب مستوى عاليا من المعرفة كالمحاسبة والترجمة. ويرى بعض الاقتصاديين أن هذه التقنيات ستقضي على ملايين الوظائف، [3] يرى آخرون أنها ستخلق وظائف جديدة لم نكن نتخيلها. وأيا كان الأمر، فإن [4] المهارات باستمرار أصبح ضرورة لا غنى عنها. ولذلك تتجه الحكومات إلى الاستثمار في برامج التعليم المستمر [5] تأهيل العاملين لمتطلبات المرحلة المقبلة.',
  [c(['إذ', 'لئلا', 'لو', 'كأن', 'لعل'], ['Sonraki cümle dönüşümün sebebini açıklıyor; “zira” anlamındaki edat gelir.']),
   c(['الروتينية', 'الإبداعية', 'المعقدة', 'النادرة', 'الفكرية'], ['“Yalnızca rutin el işleri değil, bilakis bilgi gerektiren meslekler” karşıtlığı kuruluyor.', 'İkinci kısım “yüksek bilgi gerektiren” işler olduğuna göre ilk kısım bunun zıttı olmalı.'], [('روتيني', 'rutin'), ('إبداعي', 'yaratıcı')]),
   c(['في حين', 'لأن', 'كي', 'حتى', 'كلما'], ['İki karşıt görüş arasında “oysa, ... iken” anlamı gerekir.']),
   c(['تحديث', 'إهمال', 'تجميد', 'إخفاء', 'نسيان'], ['Sürekli değişen dünyada becerilerin güncellenmesi zorunlu hâle geldi.']),
   c(['بهدف', 'بدلا من', 'رغم', 'دون', 'خلافا لـ'], ['Yatırımın amacı çalışanları hazırlamak: “amacıyla”.'])],
  tr='Dünya yirmi birinci yüzyılın başından beri iş piyasasında derin bir dönüşüme tanık oluyor; zira otomasyon ve yapay zekâ, insana özgü olan görevleri yerine getirmeye başladı. Bu dönüşüm rutin el işleriyle sınırlı kalmıyor, muhasebe ve çeviri gibi yüksek bilgi düzeyi gerektiren mesleklere de uzanıyor. Bazı iktisatçılar bu teknolojilerin milyonlarca işi ortadan kaldıracağını düşünürken, diğerleri hayal bile edemediğimiz yeni işler yaratacağını düşünüyor. Durum ne olursa olsun, becerileri sürekli güncellemek vazgeçilmez bir zorunluluk hâline geldi. Bu yüzden hükümetler, çalışanları gelecek dönemin gereklerine hazırlamak amacıyla sürekli eğitim programlarına yatırım yapmaya yöneliyor.'),

P('عرفت الحضارة الإسلامية في عصرها الذهبي حركة ترجمة واسعة، [1] نقل العلماء إلى العربية أمهات الكتب اليونانية والفارسية والهندية. ولم يكتف هؤلاء العلماء بالترجمة، [2] شرحوا تلك الكتب وانتقدوها وأضافوا إليها إضافات أصيلة. وقد [3] بيت الحكمة في بغداد دورا محوريا في هذه الحركة، إذ كان مركزا يلتقي فيه العلماء من مختلف الأديان والأعراق. [4] انتقلت هذه المعارف لاحقا إلى أوروبا عبر الأندلس وصقلية، فأسهمت في [5] النهضة الأوروبية.',
  [c(['حيث', 'لكن', 'لولا', 'كي', 'إلا'], ['Önceki ifadeyi açıklayan “ki orada, -dığı” anlamındaki bağlaç gerekir.']),
   c(['بل', 'ثم', 'أو', 'حتى', 'لكن'], ['Olumsuz “yetinmedi” fiilinden sonra “bilakis”:', '@لم يكتفوا ... بل']),
   c(['أدى', 'أجرى', 'أبدى', 'أولى', 'أسدى'], ['Rol oynamak:', '@أدى دورا'], [('أدى دورا', 'rol oynamak'), ('أولى اهتماما', 'önem vermek')]),
   c(['ثم', 'لأن', 'لو', 'إن', 'لئلا'], ['Zaman sırası bildiren bağlaç gerekir: “sonra”.']),
   c(['قيام', 'سقوط', 'تأخير', 'منع', 'انهيار'], ['Bilgiler Avrupa Rönesansı’nın doğmasına katkıda bulundu.', '“Katkıda bulunmak” olumlu bir sonuç ister.'])],
  tr='İslam medeniyeti altın çağında geniş bir tercüme hareketine tanık oldu; bu harekette âlimler Yunan, Fars ve Hint kaynaklı temel eserleri Arapçaya aktardı. Bu âlimler tercümeyle yetinmedi, bilakis o eserleri şerh ettiler, eleştirdiler ve onlara özgün katkılar eklediler. Bağdat’taki Beytü’l-Hikme bu harekette merkezi bir rol oynadı; zira farklı din ve ırklardan âlimlerin buluştuğu bir merkezdi. Bu bilgiler daha sonra Endülüs ve Sicilya yoluyla Avrupa’ya geçti ve Avrupa Rönesansı’nın doğuşuna katkıda bulundu.'),

P('تعد الأمراض المزمنة كالسكري وأمراض القلب [1] الأسباب الرئيسية للوفاة في العالم اليوم. والمثير للقلق أن هذه الأمراض لم تعد [2] على كبار السن، بل باتت تصيب فئات عمرية أصغر. ويعزو الأطباء ذلك إلى أنماط الحياة الحديثة [3] تتسم بقلة الحركة والإفراط في تناول الأطعمة المصنعة. ومع أن العوامل الوراثية تؤدي دورا لا يمكن [4]، فإن تغيير العادات اليومية قد يقي من نسبة كبيرة من هذه الأمراض. [5] تدعو منظمات الصحة إلى الاستثمار في الوقاية بدلا من الاكتفاء بالعلاج.',
  [c(['من', 'إلى', 'عن', 'على', 'مع'], ['“... -den biri sayılır” kalıbı:', '@تعد من']),
   c(['مقتصرة', 'منتشرة', 'معتمدة', 'متوقفة', 'متفوقة'], ['“Artık yaşlılarla sınırlı değil, bilakis daha genç yaşları da etkiliyor.”', 'Edat belirleyici:', '@اقتصر على']),
   c(['التي', 'الذي', 'اللذين', 'الذين', 'اللاتي'], ['Akıl sahibi olmayan çoğul isme müfred müennes mevsul uyar:', '@أنماط الحياة التي']),
   c(['إنكاره', 'إثباته', 'تأكيده', 'قبوله', 'فهمه'], ['“İnkâr edilemeyecek bir rol” deyimi; “rağmen” yapısıyla birlikte genetiğin önemini kabul ediyor.']),
   c(['ولهذا', 'ومع ذلك', 'وبالرغم من ذلك', 'وعلى العكس', 'وإلا'], ['Önceki cümle sebep, bu cümle sonuç: “bu yüzden”.'])],
  tr='Diyabet ve kalp hastalıkları gibi kronik hastalıklar bugün dünyada başlıca ölüm sebeplerinden sayılıyor. Endişe verici olan, bu hastalıkların artık yaşlılarla sınırlı kalmayıp daha genç yaş gruplarını da etkiler hâle gelmesi. Doktorlar bunu hareketsizlik ve işlenmiş gıdaların aşırı tüketimiyle belirginleşen modern yaşam tarzlarına bağlıyor. Genetik etkenler inkâr edilemeyecek bir rol oynasa da günlük alışkanlıkları değiştirmek bu hastalıkların büyük bir kısmını önleyebilir. Bu yüzden sağlık kuruluşları yalnızca tedaviyle yetinmek yerine önlemeye yatırım yapılması çağrısında bulunuyor.'),
]
