"""Harf-i cerli fiiller ve kalıp ifadelerden kelime kartı, soru ve konu anlatımı üretir."""
import random
import re

PV = {'fi': 'فِي', 'ala': 'عَلَى', 'an': 'عَنْ', 'min': 'مِنْ', 'ila': 'إِلَى', 'bi': 'بِـ', 'li': 'لِـ', 'maa': 'مَعَ'}
PU = {'fi': 'في', 'ala': 'على', 'an': 'عن', 'min': 'من', 'ila': 'إلى', 'bi': 'بـ', 'li': 'لـ', 'maa': 'مع'}
PNAME = {'fi': 'Fî', 'ala': 'Alâ', 'an': 'An', 'min': 'Min', 'ila': 'İlâ', 'bi': 'Bi', 'li': 'Li', 'maa': 'Mea'}
ORDER = ['fi', 'ala', 'an', 'min', 'ila', 'bi', 'li', 'maa']

K_VB, K_VM = 'Harf-i cer · Boşluk', 'Harf-i cer · Anlam'
K_EB, K_EM = 'Kalıp ifade · Boşluk', 'Kalıp ifade · Anlam'
P_VB = 'Cümledeki boşluğa uygun düşen edat hangisidir?'
P_VM = 'Edatıyla verilen fiilin anlamı hangisidir?'
P_EB = 'Cümledeki boşluğa uygun düşen kalıp ifade hangisidir?'
P_EM = 'Kalıp ifadenin anlamı hangisidir?'
KINDS = [K_VB, K_VM, K_EB, K_EM]

BR = re.compile(r'\{([^}]*)\}')


def phrase(v):
    return f"{v['past']} {PV[v['prep']]}"


def muz(v):
    return f"{v['muz']} {PV[v['prep']]}"


def full(s):
    """Parantezleri kaldırır; bitişik edat (بـ, لـ) sonraki kelimeye yapışır."""
    return BR.sub(lambda m: m.group(1).replace('ـ', ''), s)


def blanked(s):
    return BR.sub('------', s)


def build(mod, err):
    rnd = random.Random(41)
    words, qs = [], []
    verbs, exprs = mod.VERBS, mod.EXPRS

    def check(where, s):
        if len(BR.findall(s)) != 1:
            err(where, f'örnekte tek {{…}} olmalı: {s}')

    # Fiiller
    for i, v in enumerate(verbs, 1):
        where = f'hc{i:03d} {phrase(v)}'
        check(where, v['ex'])
        inner = BR.search(v['ex']).group(1) if BR.search(v['ex']) else ''
        if inner != PU[v['prep']]:
            err(where, f'parantezdeki edat ({inner}) ile edat alanı ({PU[v["prep"]]}) uyuşmuyor')
        for a in v['alt']:
            if a not in PV:
                err(where, f'bilinmeyen edat: {a}')
        v['id'] = f'h{i:03d}'
        words.append({'id': v['id'], 'ar': phrase(v), 'root': v['root'], 'extra': muz(v), 'tr': v['tr'],
                      'pos': 'h', 'tag': v['prep'], 'ex': full(v['ex']), 'ext': v['ext']})

    def contrasts(v):
        return [w for w in verbs if w is not v and w['past'] == v['past'] and w['prep'] in v['alt']]

    for i, v in enumerate(verbs, 1):
        others = [p for p in ORDER if p != v['prep'] and p not in v['alt']]
        rnd.shuffle(others)
        opts = [PU[v['prep']]] + [PU[p] for p in others[:4]]
        exp = ['Bu fiil şu edatla kullanılır:', '@' + phrase(v), f"Anlamı: {v['tr']}.", f"Cümle: {v['ext']}"]
        for c in contrasts(v):
            exp += ['Aynı fiil başka edatla farklı anlam kazanır:', '@' + phrase(c), f"Anlamı: {c['tr']}."]
        qs.append(dict(id=f'hc{i:03d}b', kind=K_VB, prompt=P_VB, lines=[{'a': blanked(v['ex'])}],
                       opts=opts, optAr=True, exp=exp, gloss=[[phrase(v), v['tr']]]))

        # Anlam sorusu: önce aynı fiilin diğer edatlı hâlleri, sonra rastgele
        def ok(w):
            return (w is not v and w['tr'] != v['tr'] and not set(w['g']) & set(v['g']))
        pool = [w for w in contrasts(v) if ok(w)]
        rest = [w for w in verbs if ok(w) and w not in pool]
        rnd.shuffle(rest)
        picks = (pool + rest)[:4]
        allw = [v] + picks
        if len({w['tr'] for w in allw}) != 5:
            err(f'hc{i:03d}m', 'anlam şıkları tekrar ediyor')
        exp = [f"Anlamı: {v['tr']}.", 'Örnek:', '@' + full(v['ex']), f"Çeviri: {v['ext']}"]
        for c in contrasts(v):
            exp += ['Dikkat, edat değişince anlam değişir:', '@' + phrase(c), f"Anlamı: {c['tr']}."]
        qs.append(dict(id=f'hc{i:03d}m', kind=K_VM, prompt=P_VM, lines=[{'a': phrase(v)}],
                       opts=[w['tr'] for w in allw], optAr=False, exp=exp,
                       gloss=[[phrase(w), w['tr']] for w in allw]))

    # Kalıp ifadeler
    for i, e in enumerate(exprs, 1):
        where = f'hk{i:03d} {e["ar"]}'
        check(where, e['ex'])
        e['id'] = f'hk{i:03d}'
        e['u'] = BR.search(e['ex']).group(1) if BR.search(e['ex']) else ''
        words.append({'id': e['id'], 'ar': e['ar'], 'root': '', 'extra': '', 'tr': e['tr'],
                      'pos': 'h', 'tag': 'kalip', 'ex': full(e['ex']), 'ext': e['ext']})
    for i, e in enumerate(exprs, 1):
        def ok(w):
            return w is not e and not set(w['g']) & set(e['g'])
        cand = [w for w in exprs if ok(w)]
        rnd.shuffle(cand)
        if len(cand) < 4:
            err(e['id'], f'yeterli çeldirici yok ({len(cand)})')
        picks = cand[:4]
        qs.append(dict(id=f'hk{i:03d}b', kind=K_EB, prompt=P_EB, lines=[{'a': blanked(e['ex'])}],
                       opts=[e['u']] + [w['u'] for w in picks], optAr=True,
                       exp=['Doğru ifade:', '@' + e['ar'], f"Anlamı: {e['tr']}.", f"Cümle: {e['ext']}"],
                       gloss=[[w['ar'], w['tr']] for w in [e] + picks]))
        cand = [w for w in exprs if ok(w)]
        rnd.shuffle(cand)
        picks = cand[:4]
        qs.append(dict(id=f'hk{i:03d}m', kind=K_EM, prompt=P_EM, lines=[{'a': e['ar']}],
                       opts=[e['tr']] + [w['tr'] for w in picks], optAr=False,
                       exp=[f"Anlamı: {e['tr']}.", 'Örnek:', '@' + full(e['ex']), f"Çeviri: {e['ext']}"],
                       gloss=[[w['ar'], w['tr']] for w in [e] + picks]))

    # Konu anlatımı blokları
    blocks = [('h', 'Nasıl çalışılır?'),
              ('b', 'Fiili tek başına değil, edatıyla birlikte ezberle.'),
              ('b', 'Aynı fiil farklı edatla bambaşka anlam kazanabilir; bu çiftler sınavda sık sorulur.'),
              ('a', full('رغب {في} السفر.'), 'Yolculuğa çıkmak istedi.'),
              ('a', full('رغب {عن} السفر.'), 'Yolculuktan vazgeçti.')]
    for p in ORDER:
        vs = [v for v in verbs if v['prep'] == p]
        blocks.append(('h', f'{PNAME[p]} edatıyla ({len(vs)})'))
        for v in vs:
            blocks.append(('a', phrase(v), v['tr']))
    blocks.append(('h', 'Harf-i cerli kalıp ifadeler'))
    for e in exprs:
        blocks.append(('a', e['ar'], e['tr']))
    return words, qs, blocks
