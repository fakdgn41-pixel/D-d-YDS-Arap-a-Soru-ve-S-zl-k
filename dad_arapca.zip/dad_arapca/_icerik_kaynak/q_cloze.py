# Paragrafta boşluk doldurma (cloze): her parçada beş numaralı boşluk
def c(opts, exp=None, gloss=None):
    return q(None, opts, exp or [], gloss or [])

PS = [
P('يعد ابن بطوطة من أشهر الرحالة في التاريخ الإسلامي، [1] قضى نحو ثلاثين عاما في التنقل بين البلدان. وقد بدأ رحلته من مدينة طنجة [2] كان في الحادية والعشرين من عمره. زار خلال رحلاته بلاد الشام والعراق والهند والصين، [3] وصل إلى بعض مناطق إفريقيا. وبعد عودته إلى المغرب أملى ما شاهده على كاتب يدعى ابن جزي، فظهر كتابه المعروف [4] تحفة النظار. ولا يزال هذا الكتاب [5] مهما لدراسة أحوال المجتمعات في القرن الرابع عشر.',
  [c(['إذ', 'لكي', 'لئلا', 'لعل', 'كأن'], ['Boşluktan sonra gelen cümle bir gerekçe ve açıklama bildirir. “Çünkü, zira” anlamındaki edat gelir.']),
   c(['عندما', 'لولا', 'كلما', 'ريثما', 'بينما لم'], ['Cümle: Yolculuğuna yirmi bir yaşındayken Tanca’dan başladı. Zaman bildiren “-dığında” edatı uygundur.']),
   c(['كما', 'لكن', 'إلا', 'أو', 'ثم لا'], ['Önceki cümleye ek bilgi verildiği için “ayrıca” anlamındaki bağlaç gelir.']),
   c(['باسم', 'بسبب', 'برغم', 'بدلا من', 'بعيدا عن'], ['Kitabın adını tanıtmak için “adıyla” anlamındaki ifade kullanılır.']),
   c(['مصدرا', 'عائقا', 'سببا', 'مانعا', 'شاهدا على عكس'], ['Cümle: Bu kitap 14. yüzyıldaki toplumların durumunu incelemek için hâlâ önemli bir kaynaktır.'], [('مصدر', 'kaynak'), ('عائق', 'engel'), ('مانع', 'engel')])]),

P('تعاني مناطق كثيرة في العالم من نقص المياه الصالحة للشرب. ويرجع ذلك [1] أسباب عدة، منها ارتفاع درجات الحرارة وقلة الأمطار. [2] يؤدي الاستهلاك المفرط للمياه في الزراعة والصناعة إلى استنزاف المخزون الجوفي. ولهذا تسعى الحكومات إلى [3] تقنيات حديثة لتحلية مياه البحر. غير أن هذه التقنيات ما زالت [4] التكلفة، فلا تستطيع الدول الفقيرة الاستفادة منها بسهولة. لذلك يرى الخبراء أن ترشيد الاستهلاك هو [5] الأمثل في الوقت الحاضر.',
  [c(['إلى', 'على', 'عن', 'مع', 'في'], ['Bir sebebe dayanmak anlamındaki kalıp:', '@يرجع ذلك إلى']),
   c(['كما', 'لكن', 'بل', 'إلا أن', 'لعل'], ['Ek bir sebep sayıldığı için “ayrıca” anlamındaki bağlaç gelir.']),
   c(['استخدام', 'إهمال', 'منع', 'تجاهل', 'رفض'], ['Cümle: Hükümetler deniz suyunu arıtmak için modern teknikler kullanmaya çalışıyor.']),
   c(['باهظة', 'رخيصة', 'قليلة', 'معدومة', 'بسيطة'], ['Sonraki cümle yoksul ülkelerin bu tekniklerden kolayca yararlanamadığını söylüyor. Demek ki maliyet çok yüksektir.'], [('باهظة التكلفة', 'maliyeti çok yüksek')]),
   c(['الحل', 'السبب', 'العائق', 'الخطر', 'الضرر'], ['Cümle: Uzmanlar tüketimi akılcı hâle getirmenin şu an için en uygun çözüm olduğunu düşünüyor.'])]),

P('اللغة العربية من أقدم اللغات الحية في العالم، [1] يتحدث بها اليوم أكثر من أربعمئة مليون إنسان. وهي لغة القرآن الكريم، ولذلك [2] بها المسلمون في مختلف أنحاء العالم. وتتميز العربية بثراء مفرداتها [3] قدرتها على اشتقاق كلمات جديدة من جذر واحد. وقد [4] الأمم المتحدة يوم الثامن عشر من ديسمبر يوما عالميا للغة العربية. ومع انتشار وسائل الاتصال الحديثة ازداد [5] بتعلمها في كثير من الجامعات الأجنبية.',
  [c(['إذ', 'لئلا', 'كي', 'لو', 'لعل'], ['Konuşan sayısı, önceki yargıyı açıklayan bir bilgidir. “Zira” anlamındaki edat uygundur.']),
   c(['يهتم', 'يستهين', 'يضجر', 'يتخلى', 'يسخر'], ['Cümle: Bu yüzden dünyanın her yerindeki Müslümanlar ona ilgi gösterir.', 'İlgilenmek fiili şu edatla kullanılır:', '@اهتم ب']),
   c(['و', 'أو', 'لكن', 'بل', 'ثم'], ['İki özellik art arda sayıldığı için “ve” bağlacı gelir.']),
   c(['اعتمدت', 'ألغت', 'رفضت', 'نسيت', 'منعت'], ['Cümle: Birleşmiş Milletler 18 Aralık’ı Dünya Arapça Günü olarak kabul etti.']),
   c(['الإقبال', 'الإعراض', 'النفور', 'الإهمال', 'الامتناع'], ['Cümle: Modern iletişim araçlarının yayılmasıyla yabancı üniversitelerde Arapça öğrenmeye rağbet arttı.'], [('الإقبال', 'rağbet'), ('الإعراض', 'yüz çevirme'), ('النفور', 'kaçınma')])]),

P('يقضي الأطفال اليوم ساعات طويلة أمام الشاشات، [1] يثير قلق الآباء والمربين. فقد أثبتت دراسات حديثة أن الإفراط في استخدام الأجهزة الذكية [2] سلبا على النوم والتركيز. ويرى المختصون أن [3] الأطفال من هذه الأجهزة تماما ليس حلا واقعيا. [4] ينصحون بتحديد أوقات معينة لاستخدامها وتشجيع الأنشطة الرياضية والقراءة. فالهدف هو تحقيق [5] بين العالم الرقمي والحياة الواقعية.',
  [c(['مما', 'لما', 'إذا', 'كي', 'حيث لا'], ['Önceki cümlenin tamamına gönderme yapan ve “bu da ... -e yol açıyor” anlamı veren ifade:', '@مما يثير']),
   c(['يؤثر', 'يزيد', 'يساعد', 'يحمي', 'يقوي'], ['Cümle: Akıllı cihazların aşırı kullanımı uykuyu ve odaklanmayı olumsuz etkiler.', 'Etkilemek fiili zarfla birlikte şöyle gelir:', '@يؤثر سلبا على']),
   c(['حرمان', 'تشجيع', 'تعويد', 'تعليم', 'تقريب'], ['Cümle: Uzmanlara göre çocukları bu cihazlardan tamamen mahrum bırakmak gerçekçi bir çözüm değildir.']),
   c(['بل', 'لأن', 'لذلك لا', 'حتى', 'كأن'], ['Önceki cümledeki görüşü düzelten ve yerine başka bir öneri getiren “bilakis” anlamındaki edat gelir.']),
   c(['التوازن', 'الصراع', 'الانفصال', 'التنافس', 'الخلاف'], ['Cümle: Amaç dijital dünya ile gerçek hayat arasında denge sağlamaktır.'])]),

P('النوم حاجة أساسية لجسم الإنسان [1] الطعام والماء. فأثناء النوم يقوم الدماغ بتنظيم المعلومات التي اكتسبها خلال النهار، [2] يساعد على تقوية الذاكرة. ويحتاج الشخص البالغ إلى سبع ساعات على الأقل كل ليلة، [3] الأطفال فيحتاجون إلى مدة أطول. ومن المعروف أن قلة النوم [4] إلى ضعف المناعة وصعوبة التركيز. ولذلك ينصح الأطباء بالابتعاد عن الشاشات قبل النوم [5] الأقل.',
  [c(['مثل', 'خلاف', 'دون', 'بدل', 'ضد'], ['Cümle: Uyku, yemek ve su gibi insan bedeni için temel bir ihtiyaçtır.']),
   c(['مما', 'لئلا', 'كأنما', 'لولا', 'إذا ما'], ['Önceki cümlenin sonucunu bildiren ifade:', '@مما يساعد']),
   c(['أما', 'إما', 'لما', 'إلا', 'لو'], ['Karşılaştırma yapılıyor ve devamında fâ geliyor. Bu yapı “...’e gelince” anlamındaki edatla kurulur:', '@أما ... ف']),
   c(['تؤدي', 'تمنع', 'تحمي', 'تقلل', 'تعالج'], ['Cümle: Uyku azlığının bağışıklığın zayıflamasına yol açtığı bilinir.', 'Yol açmak fiili şu edatla kullanılır:', '@أدى إلى']),
   c(['بساعة على', 'بيوم على', 'بسنة على', 'بدقيقة في', 'بأسبوع على'], ['Cümle: Doktorlar yatmadan en az bir saat önce ekranlardan uzak durmayı tavsiye ediyor.'])]),

P('يعد التصحر من أخطر المشكلات البيئية التي [1] العالم اليوم. ويقصد به تحول الأراضي الخصبة [2] أراض جافة لا تصلح للزراعة. ومن أهم أسبابه قطع الأشجار والرعي الجائر، [3] التغيرات المناخية. وقد أطلقت بعض الدول مشاريع ضخمة لزراعة ملايين الأشجار [4] الحد من هذه الظاهرة. ويؤكد الخبراء أن نجاح هذه المشاريع [5] على تعاون الدول والمجتمعات المحلية.',
  [c(['تواجه', 'تحل', 'تسبب', 'تنهي', 'تخفي'], ['Cümle: Çölleşme bugün dünyanın karşı karşıya olduğu en tehlikeli çevre sorunlarındandır.']),
   c(['إلى', 'على', 'عن', 'من', 'ب'], ['Bir şeyden başka bir şeye dönüşmek anlamındaki kalıp:', '@تحول إلى']),
   c(['إضافة إلى', 'بدلا من', 'بعيدا عن', 'خلافا ل', 'رغما عن'], ['Sebepler sayılmaya devam ediyor. “-e ek olarak” anlamındaki ifade uygundur.']),
   c(['بهدف', 'بسبب', 'برغم', 'بدون', 'بعكس'], ['Cümle: Bazı ülkeler bu olguyu sınırlamak amacıyla milyonlarca ağaç dikme projesi başlattı.']),
   c(['يتوقف', 'يقضي', 'يحكم', 'يقع', 'يدل'], ['Cümle: Uzmanlar bu projelerin başarısının devletlerin ve yerel toplulukların iş birliğine bağlı olduğunu vurguluyor.', 'Bağlı olmak anlamındaki kalıp:', '@يتوقف على'])]),

P('عرف العرب صناعة الورق في القرن الثامن الميلادي [1] تعلموها من الصينيين. وقد أنشئ أول مصنع للورق في بغداد، [2] انتشرت هذه الصناعة في دمشق والقاهرة والأندلس. وكان لانتشار الورق أثر كبير في [3] حركة التأليف والترجمة. فقد أصبح الكتاب [4] سعرا من ذي قبل، وأقبل الناس على اقتناء الكتب. ومن الأندلس انتقلت صناعة الورق [5] أوروبا في القرون التالية.',
  [c(['بعد أن', 'قبل أن', 'لكي', 'لولا أن', 'كأن'], ['Cümle: Araplar kâğıt yapımını Çinlilerden öğrendikten sonra 8. yüzyılda tanıdı.']),
   c(['ثم', 'لكن', 'أو', 'لئلا', 'إلا'], ['Olaylar zaman sırasıyla anlatılıyor; “sonra” anlamındaki bağlaç gelir.']),
   c(['ازدهار', 'تراجع', 'توقف', 'ضعف', 'انهيار'], ['Cümle: Kâğıdın yayılması telif ve tercüme hareketinin gelişmesinde büyük etki yaptı.'], [('ازدهار', 'gelişme, parlama'), ('تراجع', 'gerileme'), ('انهيار', 'çöküş')]),
   c(['أرخص', 'أغلى', 'أثقل', 'أندر', 'أصعب'], ['Sonraki cümlede insanların kitap edinmeye yöneldiği söyleniyor. Demek ki kitap öncekinden daha ucuz olmuştur.']),
   c(['إلى', 'من', 'عن', 'على', 'ب'], ['Bir yerden bir yere geçmek için “-e” anlamındaki edat gelir.'])]),

P('شهدت المدن الكبرى في العقود الأخيرة نموا سكانيا سريعا، [1] أدى إلى ظهور مشكلات متعددة. فقد ازدحمت الطرق وارتفعت أسعار المساكن [2] كبيرا. [3] ذلك، تراجعت المساحات الخضراء بسبب التوسع العمراني. ولمواجهة هذه التحديات بدأت بعض البلديات في تطوير وسائل النقل العام [4] تشجيع السكان على ترك سياراتهم. كما تعمل على إنشاء حدائق جديدة [5] جودة الحياة في المدينة.',
  [c(['مما', 'لكي', 'لو', 'إلا', 'كأن'], ['Önceki cümlenin tamamının sonucunu bildiren “bu da” anlamındaki ifade:', '@مما أدى إلى']),
   c(['ارتفاعا', 'انخفاضا', 'ارتفاع', 'مرتفعا', 'رفعا'], ['Fiili pekiştiren mastar mansub olur ve fiilin kendi kökünden gelir:', '@ارتفعت ... ارتفاعا كبيرا']),
   c(['علاوة على', 'بدلا من', 'على عكس', 'قبل', 'بسبب عدم'], ['Yeni bir olumsuzluk ekleniyor. “Buna ek olarak” anlamındaki ifade uygundur.']),
   c(['بهدف', 'بدون', 'برغم', 'بسبب', 'بعيدا عن'], ['Cümle: Belediyeler halkı araçlarını bırakmaya teşvik etmek amacıyla toplu taşımayı geliştiriyor.']),
   c(['لتحسين', 'لتقليل', 'لإهمال', 'لإلغاء', 'لتأخير'], ['Cümle: Ayrıca şehirde yaşam kalitesini iyileştirmek için yeni parklar kuruyorlar.'])]),
]
