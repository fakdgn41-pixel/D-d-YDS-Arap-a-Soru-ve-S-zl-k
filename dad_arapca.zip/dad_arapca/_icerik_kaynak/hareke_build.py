"""Harekeli hâlleri sorulara ve metinlere ekler, ses listesini üretir."""
import hashlib
import re
from pathlib import Path

DIA = re.compile('[ً-ْٰ]')
HERE = Path(__file__).parent


def strip(s):
    return DIA.sub('', s)


def load_all(err):
    H = {}
    for f in sorted((HERE / 'hareke').glob('h_*.py')):
        g = {}
        exec(f.read_text(encoding='utf-8'), g)
        for k, v in g['H'].items():
            k2 = k
            if strip(v) != strip(k2):
                a, b = strip(v).split(), strip(k2).split()
                bad = next(((x, y) for x, y in zip(a, b) if x != y), ('uzunluk', f'{len(a)}/{len(b)}'))
                err(f'hareke {f.name}', f'harekesi silinince asıl metne eşit değil: {bad[0]} ≠ {bad[1]}  [{k2[:40]}]')
                continue
            if k2 in H and H[k2] != v:
                pass  # ilk gelen geçerli
            H.setdefault(k2, v)
    return H


def sub_h(hline, target):
    """Harekeli satırda, harekesiz hâli target olan parçayı bulur."""
    n = len(hline)
    for i in range(n):
        if DIA.match(hline[i]):
            continue
        acc = ''
        for j in range(i, n):
            if not DIA.match(hline[j]):
                acc += hline[j]
                if acc == target:
                    k = j + 1
                    while k < n and DIA.match(hline[k]):
                        k += 1
                    return hline[i:k]
                if not target.startswith(acc):
                    break
    return None


def attach(questions, passages, H):
    used = set()

    def g(s):
        v = H.get(s)
        if v is not None and v != s:
            used.add(s)
            return v
        return None

    for x in questions:
        for l in x['lines']:
            if 'a' in l:
                h = g(l['a'])
                if h:
                    l['h'] = h
        if x['optAr']:
            oh = [H.get(o, o) for o in x['opts']]
            if any(H.get(o) for o in x['opts']):
                for o in x['opts']:
                    if o in H: used.add(o)
                x['oh'] = oh
        for e in x['exp']:
            if 'a' in e:
                h = g(e['a'])
                if h:
                    e['h'] = h
        t = x.get('target')
        if t:
            for l in x['lines']:
                if 'h' in l and t in l['a']:
                    th = sub_h(l['h'], t)
                    if th:
                        x['th'] = th
                    break
    for p in passages:
        h = g(p['text'])
        if h:
            p['th'] = h
    return used


def speech(s):
    return s.replace(' · ', '، ').replace('·', '، ').replace('←', ' ').replace('/', '، ')


def audio_list(passages, bas_data, H):
    items, seen = [], set()
    for p in passages:
        yeni = p['id'].startswith('okumaP') and int(p['id'][6:]) >= 19
        if p['id'].startswith('guncel') or yeni:
            items.append({'k': 'p_' + p['id'], 's': p['text'], 't': speech(p.get('th') or p['text']), 'r': '-5%'})
            seen.add(p['text'])
    if bas_data:
        for u in bas_data['units']:
            if u['id'] == 'u1':
                continue  # harfler: ses yok
            for les in u['lessons']:
                for b in les['blocks']:
                    a = b.get('a')
                    if a and a not in seen:
                        seen.add(a)
                        k = 'b_' + hashlib.md5(a.encode()).hexdigest()[:10]
                        items.append({'k': k, 's': a, 't': speech(H.get(a, a)), 'r': '-20%'})
    return items
