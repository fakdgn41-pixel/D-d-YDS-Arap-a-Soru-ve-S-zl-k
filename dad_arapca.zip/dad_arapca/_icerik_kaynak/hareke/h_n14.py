# Harekeli hâller: anahtar harekesiz asıl metin, değer harekeli metin.
H = {}
H['يلتزمْ'] = 'يَلْتَزِمْ'
