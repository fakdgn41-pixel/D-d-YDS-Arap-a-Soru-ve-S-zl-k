"""Sarf modülü üreticisi: düzenli (sahih) fiillerin çekimi, tablolar ve sorular."""
import random

F, D, K, S, SH, SK = 'َ', 'ُ', 'ِ', 'ّ', 'ْ', 'ْ'
A, U, I, SUK, SHD = F, D, K, SH, S

PERSONS = ['هو', 'هما', 'هم', 'هي', 'هما', 'هن', 'أنتَ', 'أنتما', 'أنتم', 'أنتِ', 'أنتما', 'أنتن', 'أنا', 'نحن']
PERSON_TR = ['3. tekil eril (o)', '3. ikil eril (ikisi)', '3. çoğul eril (onlar)',
             '3. tekil dişil (o)', '3. ikil dişil (ikisi)', '3. çoğul dişil (onlar)',
             '2. tekil eril (sen)', '2. ikil eril (siz ikiniz)', '2. çoğul eril (siz)',
             '2. tekil dişil (sen)', '2. ikil dişil (siz ikiniz)', '2. çoğul dişil (siz)',
             '1. tekil (ben)', '1. çoğul (biz)']
EMIR_IDX = [6, 7, 8, 9, 11]  # emir şahısları: أنتَ أنتما أنتم أنتِ أنتن
TENSES = [('mazi', 'Mazi'), ('muzari', 'Muzari (merfu)'), ('mansub', 'Muzari (mansub)'),
          ('meczum', 'Muzari (meczum)'), ('emir', 'Emir'), ('mazi_m', 'Meçhul mazi'), ('muzari_m', 'Meçhul muzari')]
TENSE_TR = dict(TENSES)

PAST_END = [A, A + 'ا', D + 'وا', A + 'تْ', A + 'تَا', SUK + 'نَ', SUK + 'تَ', SUK + 'تُمَا', SUK + 'تُمْ',
            SUK + 'تِ', SUK + 'تُمَا', SUK + 'تُنَّ', SUK + 'تُ', SUK + 'نَا']
PRE = ['ي', 'ي', 'ي', 'ت', 'ت', 'ي', 'ت', 'ت', 'ت', 'ت', 'ت', 'ت', 'أ', 'ن']
MUZ_END = [D, A + 'انِ', D + 'ونَ', D, A + 'انِ', SUK + 'نَ', D, A + 'انِ', D + 'ونَ', K + 'ينَ', A + 'انِ', SUK + 'نَ', D, D]


def _nasb(e):
    return {D: A, A + 'انِ': A + 'ا', D + 'ونَ': D + 'وا', K + 'ينَ': K + 'ي'}.get(e, e)


def _cezm(e):
    return {D: SUK}.get(e, _nasb(e))


def sound(root, form, mv='u', pv='a'):
    """Sahih fiilin bütün çekimleri. root: üç harf; form: 1..10; mv: muzari ayn harekesi; pv: mazi ayn harekesi."""
    c1, c2, c3 = root
    V = {'a': A, 'u': U, 'i': I}
    if form == 1:
        past, mpre, mstem = c1 + A + c2 + V[pv] + c3, A, c1 + SUK + c2 + V[mv] + c3
        hv = 'اُ' if mv == 'u' else 'اِ'
        emir = hv + c1 + SUK + c2 + V[mv] + c3
        pm, mm = c1 + U + c2 + I + c3, c1 + SUK + c2 + A + c3
    elif form == 2:
        past, mpre, mstem = c1 + A + c2 + S + A + c3, U, c1 + A + c2 + S + I + c3
        emir = c1 + A + c2 + S + I + c3
        pm, mm = c1 + U + c2 + S + I + c3, c1 + A + c2 + S + A + c3
    elif form == 3:
        past, mpre, mstem = c1 + A + 'ا' + c2 + A + c3, U, c1 + A + 'ا' + c2 + I + c3
        emir = c1 + A + 'ا' + c2 + I + c3
        pm, mm = c1 + U + 'و' + c2 + I + c3, c1 + A + 'ا' + c2 + A + c3
    elif form == 4:
        past, mpre, mstem = 'أَ' + c1 + SUK + c2 + A + c3, U, c1 + SUK + c2 + I + c3
        emir = 'أَ' + c1 + SUK + c2 + I + c3
        pm, mm = 'أُ' + c1 + SUK + c2 + I + c3, c1 + SUK + c2 + A + c3
    elif form == 5:
        past, mpre, mstem = 'تَ' + c1 + A + c2 + S + A + c3, A, 'تَ' + c1 + A + c2 + S + A + c3
        emir = 'تَ' + c1 + A + c2 + S + A + c3
        pm, mm = 'تُ' + c1 + U + c2 + S + I + c3, 'تَ' + c1 + A + c2 + S + A + c3
    elif form == 6:
        past, mpre, mstem = 'تَ' + c1 + A + 'ا' + c2 + A + c3, A, 'تَ' + c1 + A + 'ا' + c2 + A + c3
        emir = 'تَ' + c1 + A + 'ا' + c2 + A + c3
        pm, mm = 'تُ' + c1 + U + 'و' + c2 + I + c3, 'تَ' + c1 + A + 'ا' + c2 + A + c3
    elif form == 7:
        past, mpre, mstem = 'اِنْ' + c1 + A + c2 + A + c3, A, 'نْ' + c1 + A + c2 + I + c3
        emir = 'اِنْ' + c1 + A + c2 + I + c3
        pm = mm = None
    elif form == 8:
        past, mpre, mstem = 'اِ' + c1 + SUK + 'تَ' + c2 + A + c3, A, c1 + SUK + 'تَ' + c2 + I + c3
        emir = 'اِ' + c1 + SUK + 'تَ' + c2 + I + c3
        pm, mm = 'اُ' + c1 + SUK + 'تُ' + c2 + I + c3, c1 + SUK + 'تَ' + c2 + A + c3
    elif form == 10:
        past, mpre, mstem = 'اِسْتَ' + c1 + SUK + c2 + A + c3, A, 'سْتَ' + c1 + SUK + c2 + I + c3
        emir = 'اِسْتَ' + c1 + SUK + c2 + I + c3
        pm, mm = 'اُسْتُ' + c1 + SUK + c2 + I + c3, 'سْتَ' + c1 + SUK + c2 + A + c3
    else:
        raise ValueError(form)

    t = {}
    t['mazi'] = [past + e for e in PAST_END]
    t['muzari'] = [PRE[i] + mpre + mstem + MUZ_END[i] for i in range(14)]
    t['mansub'] = [PRE[i] + mpre + mstem + _nasb(MUZ_END[i]) for i in range(14)]
    t['meczum'] = [PRE[i] + mpre + mstem + _cezm(MUZ_END[i]) for i in range(14)]
    t['emir'] = [emir + _cezm(MUZ_END[i]) for i in EMIR_IDX]
    if pm:
        t['mazi_m'] = [pm + e for e in PAST_END]
        t['muzari_m'] = [PRE[i] + U + mm + MUZ_END[i] for i in range(14)]
    # أ + ُ/َ ön ekinin yazımı: 1. tekil
    for k in ('muzari', 'mansub', 'meczum', 'muzari_m'):
        if k in t:
            t[k] = [w.replace('أ' + U, 'أُ').replace('أ' + A, 'أَ') for w in t[k]]
    return t


def table_from_lists(d):
    """Elle yazılmış tablo: her kip boşlukla ayrılmış 14 (emirde 5) form."""
    out = {}
    for k, v in d.items():
        out[k] = v.split()
    return out


def check_table(name, t, err):
    for k, v in t.items():
        n = 5 if k == 'emir' else 14
        if len(v) != n:
            err(f'sarf:{name}', f'{k} {len(v)} form (beklenen {n})')


# ---------------------------------------------------------------- türemiş isim kalıpları (sahih kök)
def derived(root, form, masdar1=''):
    c1, c2, c3 = root
    if form == 1:
        return dict(fail=c1 + A + 'ا' + c2 + I + c3, meful='مَ' + c1 + SUK + c2 + U + 'و' + c3, masdar=masdar1)
    pat = {
        2: ('مُ' + c1 + A + c2 + S + I + c3, 'مُ' + c1 + A + c2 + S + A + c3, 'تَ' + c1 + SUK + c2 + I + 'ي' + c3),
        3: ('مُ' + c1 + A + 'ا' + c2 + I + c3, 'مُ' + c1 + A + 'ا' + c2 + A + c3, 'مُ' + c1 + A + 'ا' + c2 + A + c3 + A + 'ة'),
        4: ('مُ' + c1 + SUK + c2 + I + c3, 'مُ' + c1 + SUK + c2 + A + c3, 'إِ' + c1 + SUK + c2 + A + 'ا' + c3),
        5: ('مُتَ' + c1 + A + c2 + S + I + c3, 'مُتَ' + c1 + A + c2 + S + A + c3, 'تَ' + c1 + A + c2 + S + U + c3),
        6: ('مُتَ' + c1 + A + 'ا' + c2 + I + c3, 'مُتَ' + c1 + A + 'ا' + c2 + A + c3, 'تَ' + c1 + A + 'ا' + c2 + U + c3),
        7: ('مُنْ' + c1 + A + c2 + I + c3, 'مُنْ' + c1 + A + c2 + A + c3, 'اِنْ' + c1 + I + c2 + A + 'ا' + c3),
        8: ('مُ' + c1 + SUK + 'تَ' + c2 + I + c3, 'مُ' + c1 + SUK + 'تَ' + c2 + A + c3, 'اِ' + c1 + SUK + 'تِ' + c2 + A + 'ا' + c3),
        10: ('مُسْتَ' + c1 + SUK + c2 + I + c3, 'مُسْتَ' + c1 + SUK + c2 + A + c3, 'اِسْتِ' + c1 + SUK + c2 + A + 'ا' + c3),
    }[form]
    return dict(fail=pat[0], meful=pat[1], masdar=pat[2])


FORMS = [1, 2, 3, 4, 5, 6, 7, 8, 10]
HOW_FAIL = {
    1: 'Sülasi mücerredde ism-i fâil fâ‘il kalıbındadır.',
    'm': 'Mezid babda ism-i fâil muzariden yapılır: ön ek yerine ötreli mim gelir, sondan bir önceki harf esrelidir.',
}
HOW_MEFUL = {
    1: 'Sülasi mücerredde ism-i mef‘ûl mef‘ûl kalıbındadır.',
    'm': 'Mezid babda ism-i mef‘ûl de muzariden yapılır; fâilden farkı, sondan bir önceki harfin fethalı olmasıdır.',
}


def _opts(correct, pool, rnd, n=5):
    out = [correct]
    for x in pool:
        if x and x not in out:
            out.append(x)
    head, rest = out[:1], out[1:]
    rnd.shuffle(rest)
    return head + rest[:n - 1] if len(head + rest) >= n else None


def is_sound(root):
    return not any(ch in root for ch in 'ويأءا') and root[1] != root[2]


def drill_questions(mod, q, err):
    BAB_TR = mod.BAB_TR
    qs = []
    for vi, v in enumerate(mod.DRILL, 1):
        rnd = random.Random(vi * 7919)
        if v['kind'] == 's':
            root, form = v['root'], v['form']
            t = sound(root, form, v['mv'], v['pv'])
            past, muz, emir = t['mazi'][0], t['muzari'][0], t['emir'][0]
            d = derived(root, form, v['masdar'])
            if v.get('masdar') and form != 1:
                d['masdar'] = v['masdar']
            if root == 'ورد' and form == 10:
                d['masdar'] = 'اِسْتِيرَاد'
            fail, meful, masdar = d['fail'], (d['meful'] if v['trans'] else ''), d['masdar']
            others = [f for f in FORMS if f != form]
            sound_root = is_sound(root)
            if sound_root:
                od = {f: derived(root, f, '') for f in others}
        else:
            past, muz, masdar, fail, meful, emir, form = v['past'], v['muz'], v['masdar'], v['fail'], v['meful'], v['emir'], v['form']
            sound_root = False
            t = None
        bab = BAB_TR[form]
        head = f'{past} {muz}'
        gloss = [(past, v['tr'])]
        same = [fail, meful, masdar, muz, emir, past]
        key = 1 if form == 1 else 'm'

        # ism-i fâil
        pool = [meful] + ([od[f]['fail'] for f in others] if sound_root else []) + same
        o = _opts(fail, pool, rnd)
        if o:
            qs.append(q(None, o, [f'Fiil: {v["tr"]}. Bab: {bab}.', HOW_FAIL[key], '@' + f'{muz} ← {fail}'] +
                        ([HOW_MEFUL[key], '@' + meful] if meful else []),
                        gloss, kind='Sarf · Türemiş isim', prompt='Fiilin ism-i fâili hangisidir?', lines=[head], optAr=True))
        # ism-i mef‘ûl
        if meful:
            pool = [fail] + ([od[f]['meful'] for f in others] if sound_root else []) + same
            o = _opts(meful, pool, rnd)
            if o:
                qs.append(q(None, o, [f'Fiil: {v["tr"]}. Bab: {bab}.', HOW_MEFUL[key], '@' + f'{muz} ← {meful}', 'İsm-i fâil ise şudur:', '@' + fail],
                            gloss, kind='Sarf · Türemiş isim', prompt='Fiilin ism-i mef‘ûlü hangisidir?', lines=[head], optAr=True))
        # masdar
        if masdar:
            pool = ([od[f]['masdar'] for f in others if f != 1] if sound_root else []) + same
            o = _opts(masdar, pool, rnd)
            if o:
                e = [f'Fiil: {v["tr"]}. Bab: {bab}.']
                e += ['Sülasi mücerredin masdarı semâîdir; ezberlenir.'] if form == 1 else ['Mezid babların masdarı kıyasîdir; her babın sabit bir masdar kalıbı vardır.']
                e += ['@' + f'{past} ← {masdar}']
                qs.append(q(None, o, e, gloss, kind='Sarf · Masdar', prompt='Fiilin masdarı hangisidir?', lines=[head], optAr=True))
        # bab ya da muzari kalıbı
        if form != 1:
            names = [BAB_TR[f] for f in FORMS if f != form]
            rnd.shuffle(names)
            o = [bab] + names[:4]
            qs.append(q(None, o, [f'Fiil: {v["tr"]}.', f'Mazi ve muzari kalıbı {bab} babını gösterir:', '@' + head],
                        gloss, kind='Sarf · Bab', prompt='Fiil hangi babdandır?', lines=[head], optAr=False))
        elif sound_root:
            c1, c2, c3 = root
            cands = ['يَ' + c1 + SUK + c2 + x + c3 + U for x in (U, I, A)]
            cands += ['يُ' + c1 + SUK + c2 + I + c3 + U, 'يُ' + c1 + A + c2 + S + I + c3 + U]
            o = _opts(muz, cands, rnd)
            if o:
                qs.append(q(None, o, [f'Fiil: {v["tr"]}.', 'Sülasi mücerredin muzari harekesi işitmeye dayanır. Bu fiilin muzarisi:', '@' + muz,
                                      'Muzari ön eki ötreli olan kalıplar mezid bablara (II, III, IV) aittir.'],
                            gloss, kind='Sarf · Muzari kalıbı', prompt='Fiilin muzarisi hangisidir?', lines=[past], optAr=True))
        # emir
        mec2 = None
        if t:
            mec2 = t['meczum'][6]
        pool = [mec2, muz, past, masdar, fail]
        o = _opts(emir, pool, rnd)
        if o and vi % 2 == 0:
            qs.append(q(None, o, [f'Fiil: {v["tr"]}.', 'Emir, muzarinin meczum ikinci şahsından ön ek atılarak yapılır:', '@' + f'{muz} ← {emir}'],
                        gloss, kind='Sarf · Çekim', prompt='Fiilin emri (sen, eril) hangisidir?', lines=[head], optAr=True))
    return qs


def table_questions(tables, q):
    """Çekim tablolarından: istenen çekimi bul ve kip/şahıs tanı."""
    qs = []
    for ti, tb in enumerate(tables, 1):
        rnd = random.Random(ti * 104729)
        cells = []  # (tense, person_idx, form)
        for tk, _ in TENSES:
            if tk not in tb['t']:
                continue
            idxs = EMIR_IDX if tk == 'emir' else list(range(14))
            for j, f in enumerate(tb['t'][tk]):
                cells.append((tk, idxs[j], f))
        count = {}
        for c in cells:
            count[c[2]] = count.get(c[2], 0) + 1

        def label(tk, pi):
            return f'{TENSE_TR[tk]} · {PERSON_TR[pi]}'
        # çekimi bul: 4 soru
        picks = [c for c in cells if c[0] in ('mazi', 'muzari', 'mansub', 'meczum', 'emir', 'mazi_m', 'muzari_m')]
        rnd.shuffle(picks)
        n = 0
        for tk, pi, f in picks:
            if n >= 4:
                break
            pool = [c[2] for c in cells if c[1] == pi and c[2] != f] + [c[2] for c in cells if c[0] == tk and c[2] != f]
            rnd.shuffle(pool)
            o = _opts(f, pool, rnd)
            if not o:
                continue
            n += 1
            qs.append(q(None, o, [f'{TENSE_TR[tk]}, {PERSON_TR[pi]}:', '@' + f, tb.get('note', '')] if tb.get('note') else
                        [f'{TENSE_TR[tk]}, {PERSON_TR[pi]}:', '@' + f],
                        [(tb['verb'], tb['tr'])], kind='Sarf · Çekim', prompt='Fiilin istenen çekimi hangisidir?',
                        lines=[tb['verb'], '#İstenen: ' + label(tk, pi)], optAr=True))
        # kip ve şahıs tanı: 3 soru
        uniq = [c for c in cells if count[c[2]] == 1]
        rnd.shuffle(uniq)
        for tk, pi, f in uniq[:3]:
            same_t = [label(c[0], c[1]) for c in cells if c[0] == tk and c[1] != pi]
            same_p = [label(c[0], c[1]) for c in cells if c[1] == pi and c[0] != tk]
            rnd.shuffle(same_t)
            rnd.shuffle(same_p)
            pool = same_p[:2] + same_t
            o = _opts(label(tk, pi), pool, rnd)
            if not o:
                continue
            qs.append(q(None, o, [f'Fiil: {tb["tr"]}.', 'Bu form yalnızca şu kip ve şahısta bulunur: ' + label(tk, pi) + '.', '@' + f],
                        [(tb['verb'], tb['tr'])], kind='Sarf · Sığa', prompt='Fiil hangi kip ve şahıstadır?',
                        lines=[f], optAr=False))
    return qs


def build(mod, q, err):
    """Dönüş: (ham sorular, sarf.json içeriği, konu listesi)."""
    tables = []
    for root, form, mv, pv, tr, typ, mech in mod.SOUND_TABLES:
        t = sound(root, form, mv, pv)
        if not mech:
            t.pop('mazi_m', None)
            t.pop('muzari_m', None)
        tables.append(dict(id=f'{root}{form}', verb=f'{t["mazi"][0]} {t["muzari"][0]}', tr=tr, type=typ, note='', t=t))
    for w in mod.WEAK_TABLES:
        t = {k: w[k].split() for k in ('mazi', 'muzari', 'mansub', 'meczum', 'emir')}
        tables.append(dict(id=w['id'], verb=w['verb'], tr=w['tr'], type=w['type'], note=w['note'], t=t))
    for tb in tables:
        check_table(tb['id'], tb['t'], err)

    raw = drill_questions(mod, q, err) + table_questions(tables, q)
    for c in mod.CTX:
        raw.append(q(c['stem'], c['opts'], c['exp'], kind='Sarf · Cümlede sarf',
                     prompt='Cümledeki boşluğa uygun düşen ifade hangisidir?'))

    data = dict(
        persons=PERSONS, personsTr=PERSON_TR, emirIdx=EMIR_IDX,
        tenses=[dict(k=k, tr=tr) for k, tr in TENSES],
        babs=mod.BABS,
        tables=[dict(id=tb['id'], verb=tb['verb'], tr=tb['tr'], type=tb['type'], note=tb['note'], t=tb['t']) for tb in tables],
    )
    return raw, data, mod.TOPICS
