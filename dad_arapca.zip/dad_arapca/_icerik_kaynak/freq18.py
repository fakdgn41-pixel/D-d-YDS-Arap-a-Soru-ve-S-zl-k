"""YDS Arapça sıklık verisi: ÖSYM'nin yayımladığı sınav kitapçıklarından Dâd için yapılan sayım.

sik.json: [{"sec": ..., "forms": [...], "s": geçtiği sınav sayısı}] (dosya yoksa etiketleme yapılmaz)
tag(words): her kelimeye 's' (kaç sınavda geçtiği, /15) alanını yazar.
"""
import json, re, itertools
from pathlib import Path

MARK = set('ًٌٍَُِّْٰـ‫‬')


def plain(s):
    return ''.join(c for c in s if c not in MARK).strip()


def norm(s):
    s = plain(s)
    s = re.sub(r'\s+', ' ', s)
    s = ' '.join(re.sub('^(ال)(?=..)', '', t) for t in s.split(' '))
    for a, b in (('أ', 'ا'), ('إ', 'ا'), ('آ', 'ا'), ('ى', 'ي'), ('ة', 'ه')):
        s = s.replace(a, b)
    s = s.replace('ـ', '')
    return s.strip()


def lig_variants(form):
    """PDF metninde 'لا' bağlaşığı 'ال' olarak çıkıyor; kelime başı dışındaki her 'ال' için iki ihtimal."""
    idx = [m.start() for m in re.finditer('ال', form)
           if (m.start() > 0 and form[m.start() - 1] != ' ')
           or form == 'ال' or form.startswith('ال ')]
    out = set()
    for k in range(len(idx) + 1):
        for comb in itertools.combinations(idx, k):
            s = list(form)
            for i in comb:
                s[i], s[i + 1] = 'ل', 'ا'
            out.add(''.join(s))
    return out


def load():
    p = Path(__file__).parent / 'sik.json'
    return json.loads(p.read_text()) if p.exists() else []


def index():
    idx = {}
    for e in load():
        for f in e['forms']:
            for v in lig_variants(plain(f)):
                k = norm(v)
                if not k:
                    continue
                s, secs = idx.get(k, (0, set()))
                idx[k] = (max(s, e['s']), secs | {e['sec']})
    return idx


def tag(words):
    """Her kelimeye 's' (kaç sınavda geçtiği, /15) yazar; edat/bağlaç olanlara konu 'edat' verir."""
    idx = index()
    n = 0
    for w in words:
        ar = plain(w['ar'])
        keys = {norm(ar)}
        if w['pos'] not in ('h', 'b'):
            keys.add(norm(ar.split(' ')[0]))
        for k in list(keys):
            if k.startswith('ا') and len(k) > 3:
                keys.add(k[1:])  # hemze-i vasl: امراه / مراه
        if w['ar'].endswith('\u064d'):
            keys.add(norm(ar) + 'ي')  # ism-i menkus: تال / تالي
        hits = [idx[k] for k in keys if k in idx]
        if not hits:
            continue
        w['s'] = max(h[0] for h in hits)
        n += 1
        secs = set().union(*(h[1] for h in hits))
        if secs & {'edat', 'baglac'} and w['pos'] == 'b' and 'k' not in w:
            w['k'] = 'edat'
    return n
