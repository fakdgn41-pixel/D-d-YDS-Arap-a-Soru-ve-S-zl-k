"""İçerik derleyicisi: content/ altındaki Python veri dosyalarını doğrular ve
uygulamanın okuduğu JSON dosyalarını üretir.

Soru biçimi (kısa yazım):
  q(stem, opts, exp=[...], gloss=[(ar, tr), ...])
  - opts: beş şık, DOĞRU CEVAP HER ZAMAN İLK SIRADA (uygulama karıştırır)
  - exp: Türkçe açıklama cümleleri; '@' ile başlayan öğe kendi satırında Arapçadır
  - stem içinde boşluk: ------
Parça (cloze / okuma) biçimi:
  P(text, [q(...), ...], tr=None)   cloze metninde boşluklar [1] ... [5]
"""
import importlib.util
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).parent
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE.parent / 'dad_arapca' / 'assets' / 'data'
BLANK = '------'
AR = re.compile(r'[؀-ۿ]')
LATIN = re.compile(r'[A-Za-zÇĞİÖŞÜçğıöşü]')

CATS = {
    'kelime': ('Kelime bilgisi', 'Cümledeki boşluğa uygun düşen kelime hangisidir?'),
    'gramer': ('Dilbilgisi', 'Cümledeki boşluğa uygun düşen ifade hangisidir?'),
    'cloze': ('Paragrafta boşluk', 'Parçadaki numaralı boşluğa uygun düşen ifade hangisidir?'),
    'tamamlama': ('Cümle tamamlama', 'Cümleyi anlamca uygun şekilde tamamlayan seçenek hangisidir?'),
    'ceviri': ('Çeviri', ''),
    'okuma': ('Okuma parçası', 'Parçaya göre sorunun cevabı hangisidir?'),
    'diyalog': ('Diyalog tamamlama', 'Diyalogdaki boşluğa uygun düşen ifade hangisidir?'),
    'anlam': ('Anlamca en yakın cümle', 'Verilen cümleye anlamca en yakın cümle hangisidir?'),
    'paragraf': ('Paragraf tamamlama', 'Paragraftaki boşluğa uygun düşen cümle hangisidir?'),
    'akis': ('Akışı bozan cümle', 'Numaralanmış cümlelerden hangisi paragrafın anlam bütünlüğünü bozar?'),
}


def q(stem=None, opts=None, exp=None, gloss=None, kind=None, prompt=None, target=None,
      lines=None, optAr=None, tr=False, ans=0, noShuffle=False, b=None):
    return dict(stem=stem, opts=opts, exp=exp or [], gloss=gloss or [], kind=kind, prompt=prompt,
                target=target, lines=lines, optAr=optAr, tr=tr, ans=ans, noShuffle=noShuffle, b=b)


def P(text, qs, tr=None, title=None):
    return dict(text=text, qs=qs, tr=tr, title=title)


def load(name):
    p = HERE / f'{name}.py'
    if not p.exists():
        return None
    spec = importlib.util.spec_from_file_location(name, p)
    m = importlib.util.module_from_spec(spec)
    m.q, m.P, m.BLANK = q, P, BLANK
    spec.loader.exec_module(m)
    return m


errors = []


def err(where, msg):
    errors.append(f'{where}: {msg}')


def exp_json(items, where):
    out = []
    for e in items:
        if e.startswith('@'):
            t = e[1:].strip()
            if LATIN.search(t):
                err(where, f'Arapça açıklamada Latin harf: {t}')
            out.append({'a': t})
        else:
            if AR.search(e):
                err(where, f'Türkçe açıklamada Arapça harf (ayrı satıra al): {e}')
            out.append({'t': e})
    return out


def make(cat, raw, qid, pid=None):
    kind_d, prompt_d = CATS[cat]
    where = qid
    opts = raw['opts']
    if not opts or len(opts) != 5:
        err(where, f'5 şık olmalı, {len(opts or [])} var')
    if len(set(opts)) != len(opts):
        err(where, 'tekrar eden şık')
    optAr = raw['optAr']
    if optAr is None:
        optAr = bool(AR.search(opts[0]))
    for o in opts:
        if optAr and LATIN.search(o) and not re.fullmatch(r'[IV]+', o):
            err(where, f'Arapça şıkta Latin harf: {o}')
        if not optAr and AR.search(o):
            err(where, f'Türkçe şıkta Arapça harf: {o}')
    if raw['lines'] is not None:
        lines = []
        for l in raw['lines']:
            if isinstance(l, tuple):
                lines.append({'n': l[0], 'a': l[1]})
            elif l.startswith('#'):
                lines.append({'t': l[1:].strip()})
            else:
                lines.append({'a': l})
    elif raw['stem'] is None:
        lines = []
    elif raw['tr']:
        lines = [{'t': raw['stem']}]
    else:
        lines = [{'a': raw['stem']}]
    for l in lines:
        if 'a' in l and LATIN.search(l['a']):
            err(where, f'Arapça satırda Latin harf: {l["a"]}')
    if cat in ('kelime', 'gramer', 'diyalog', 'paragraf') and raw['target'] is None and raw['lines'] is None:
        if BLANK not in (raw['stem'] or ''):
            err(where, 'boşluk (------) yok')
    if raw['target'] and raw['target'] not in (raw['stem'] or ''):
        err(where, 'altı çizili hedef kelime cümlede yok')
    o = {
        'id': qid, 'cat': cat, 'kind': raw['kind'] or kind_d, 'prompt': raw['prompt'] or prompt_d,
        'lines': lines, 'opts': opts, 'optAr': optAr, 'ans': raw['ans'],
        'exp': exp_json(raw['exp'], where), 'gloss': [list(g) for g in raw['gloss']],
    }
    if not o['prompt']:
        err(where, 'soru yönergesi yok')
    if raw['target']:
        o['target'] = raw['target']
    if raw['noShuffle']:
        o['noShuffle'] = True
    if pid:
        o['pid'] = pid
    if raw['b'] is not None:
        o['b'] = raw['b']
    return o


def main():
    questions, passages = [], []

    # Eski sorular: yeni kategorilere taşınır, okuma parçası olanlar yeniden yazıldı.
    legacy = json.loads((HERE / 'legacy_questions.json').read_text())
    recat = {'q16': 'akis', 'q13': 'anlam', 'q14': 'diyalog', 'q15': 'diyalog'}
    for x in legacy:
        if x['id'] in ('q17a', 'q17b'):
            continue
        x = dict(x)
        x['cat'] = recat.get(x['id'], x['cat'])
        if x['cat'] == 'akis':
            x['kind'] = CATS['akis'][0]
        questions.append(x)

    for cat in CATS:
        m = load(f'q_{cat}')
        if m is None:
            continue
        for i, raw in enumerate(getattr(m, 'QS', []), 1):
            questions.append(make(cat, raw, f'{cat}{i:03d}'))
        for pi, p in enumerate(getattr(m, 'PS', []), 1):
            pid = f'{cat}P{pi:02d}'
            if LATIN.search(p['text']):
                err(pid, 'parçada Latin harf')
            if cat == 'cloze':
                nums = re.findall(r'\[(\d)\]', p['text'])
                if nums != [str(k) for k in range(1, len(p['qs']) + 1)]:
                    err(pid, f'boşluk numaraları soru sayısıyla uyuşmuyor: {nums}')
            passages.append({'id': pid, 'cat': cat, 'text': p['text'], **({'tr': p['tr']} if p['tr'] else {})})
            for qi, raw in enumerate(p['qs'], 1):
                if cat == 'cloze' and raw['b'] is None:
                    raw['b'] = qi
                questions.append(make(cat, raw, f'{pid}q{qi}', pid=pid))

    ids = [x['id'] for x in questions]
    if len(ids) != len(set(ids)):
        err('genel', 'tekrar eden soru kimliği')

    # Kelimeler
    words = json.loads((HERE / 'legacy_words.json').read_text())
    mods = [load(f.stem) for f in sorted(HERE.glob('words*.py'))]
    ex = {}
    new = []
    for wm in mods:
        ex.update(getattr(wm, 'LEGACY_EX', {}))
        new += getattr(wm, 'NEW', [])
    if True:
        for w in words:
            if w['id'] in ex:
                w['ex'], w['ext'] = ex[w['id']]
        seen = {(w['ar'], w['pos']) for w in words}
        n = len(words)
        for t in new:
            ar, root, extra, trn, pos = t[:5]
            key = (ar, pos)
            if key in seen:
                err(ar, 'sözlükte zaten var')
                continue
            seen.add(key)
            w = {'id': f'w{n}', 'ar': ar, 'root': root, 'extra': extra, 'tr': trn, 'pos': pos}
            if len(t) >= 7:
                w['ex'], w['ext'] = t[5], t[6]
            if pos not in 'fisb':
                err(ar, f'tür hatalı: {pos}')
            if LATIN.search(ar + root + extra + w.get('ex', '')):
                err(ar, 'Arapça alanda Latin harf')
            if AR.search(trn + w.get('ext', '')):
                err(ar, 'Türkçe alanda Arapça harf')
            words.append(w)
            n += 1

    if errors:
        print('\n'.join(errors))
        print(f'{len(errors)} HATA')
        sys.exit(1)

    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'questions.json').write_text(json.dumps(questions, ensure_ascii=False, indent=0))
    (OUT / 'passages.json').write_text(json.dumps(passages, ensure_ascii=False, indent=0))
    (OUT / 'words.json').write_text(json.dumps(words, ensure_ascii=False, indent=0))
    from collections import Counter
    print('Soru:', len(questions), dict(Counter(x['cat'] for x in questions)))
    print('Parça:', len(passages), 'Kelime:', len(words), 'Örnekli:', sum(1 for w in words if w.get('ex')))


if __name__ == '__main__':
    main()
