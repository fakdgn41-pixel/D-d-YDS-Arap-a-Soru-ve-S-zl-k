"""İçerik derleyicisi: content/ altındaki Python veri dosyalarını doğrular ve
uygulamanın okuduğu JSON dosyalarını üretir.

Soru biçimi (kısa yazım):
  q(stem, opts, exp=[...], gloss=[(ar, tr), ...])
  - opts: beş şık, DOĞRU CEVAP HER ZAMAN İLK SIRADA (uygulama karıştırır)
  - exp: Türkçe açıklama cümleleri; '@' ile başlayan öğe kendi satırında Arapçadır
  - stem içinde boşluk: ------
Parça (cloze / okuma) biçimi:
  P(text, [q(...), ...], tr=None)   cloze metninde boşluklar [1] ... [5]
"""
import importlib.util
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).parent
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE.parent / 'dad_arapca' / 'assets' / 'data'
BLANK = '------'
AR = re.compile(r'[؀-ۿ]')
LATIN = re.compile(r'[A-Za-zÇĞİÖŞÜçğıöşü]')

CATS = {
    'kelime': ('Kelime bilgisi', 'Cümledeki boşluğa uygun düşen kelime hangisidir?'),
    'gramer': ('Dilbilgisi', 'Cümledeki boşluğa uygun düşen ifade hangisidir?'),
    'cloze': ('Paragrafta boşluk', 'Parçadaki numaralı boşluğa uygun düşen ifade hangisidir?'),
    'tamamlama': ('Cümle tamamlama', 'Cümleyi anlamca uygun şekilde tamamlayan seçenek hangisidir?'),
    'ceviri': ('Çeviri', ''),
    'okuma': ('Okuma parçası', 'Parçaya göre sorunun cevabı hangisidir?'),
    'diyalog': ('Diyalog tamamlama', 'Diyalogdaki boşluğa uygun düşen ifade hangisidir?'),
    'anlam': ('Anlamca en yakın cümle', 'Verilen cümleye anlamca en yakın cümle hangisidir?'),
    'paragraf': ('Paragraf tamamlama', 'Paragraftaki boşluğa uygun düşen cümle hangisidir?'),
    'akis': ('Akışı bozan cümle', 'Numaralanmış cümlelerden hangisi paragrafın anlam bütünlüğünü bozar?'),
    'harfcer': ('Harf-i cerli kalıplar', 'Cümledeki boşluğa uygun düşen edat hangisidir?'),
    'sarf': ('Sarf', 'Doğru seçenek hangisidir?'),
    'baslangic': ('Sıfırdan Arapça', 'Doğru seçenek hangisidir?'),
}


def q(stem=None, opts=None, exp=None, gloss=None, kind=None, prompt=None, target=None,
      lines=None, optAr=None, tr=False, ans=0, noShuffle=False, b=None):
    return dict(stem=stem, opts=opts, exp=exp or [], gloss=gloss or [], kind=kind, prompt=prompt,
                target=target, lines=lines, optAr=optAr, tr=tr, ans=ans, noShuffle=noShuffle, b=b)


def P(text, qs, tr=None, title=None):
    return dict(text=text, qs=qs, tr=tr, title=title)


def load(name):
    p = HERE / f'{name}.py'
    if not p.exists():
        return None
    spec = importlib.util.spec_from_file_location(name, p)
    m = importlib.util.module_from_spec(spec)
    m.q, m.P, m.BLANK = q, P, BLANK
    spec.loader.exec_module(m)
    return m


errors = []


def err(where, msg):
    errors.append(f'{where}: {msg}')


def exp_json(items, where):
    out = []
    for e in items:
        if e.startswith('@'):
            t = e[1:].strip()
            if LATIN.search(t):
                err(where, f'Arapça açıklamada Latin harf: {t}')
            out.append({'a': t})
        else:
            if AR.search(e):
                err(where, f'Türkçe açıklamada Arapça harf (ayrı satıra al): {e}')
            out.append({'t': e})
    return out


def make(cat, raw, qid, pid=None):
    kind_d, prompt_d = CATS[cat]
    where = qid
    opts = raw['opts']
    if not opts or len(opts) != 5:
        err(where, f'5 şık olmalı, {len(opts or [])} var')
    if len(set(opts)) != len(opts):
        err(where, 'tekrar eden şık')
    optAr = raw['optAr']
    if optAr is None:
        optAr = bool(AR.search(opts[0]))
    for o in opts:
        if optAr and LATIN.search(o) and not re.fullmatch(r'[IV]+', o):
            err(where, f'Arapça şıkta Latin harf: {o}')
        if not optAr and AR.search(o):
            err(where, f'Türkçe şıkta Arapça harf: {o}')
    if raw['lines'] is not None:
        lines = []
        for l in raw['lines']:
            if isinstance(l, tuple):
                lines.append({'n': l[0], 'a': l[1]})
            elif l.startswith('#'):
                lines.append({'t': l[1:].strip()})
            else:
                lines.append({'a': l})
    elif raw['stem'] is None:
        lines = []
    elif raw['tr']:
        lines = [{'t': raw['stem']}]
    else:
        lines = [{'a': raw['stem']}]
    for l in lines:
        if 'a' in l and LATIN.search(l['a']):
            err(where, f'Arapça satırda Latin harf: {l["a"]}')
    if cat in ('kelime', 'gramer', 'diyalog', 'paragraf') and raw['target'] is None and raw['lines'] is None:
        if BLANK not in (raw['stem'] or ''):
            err(where, 'boşluk (------) yok')
    if raw['target'] and raw['target'] not in (raw['stem'] or ''):
        err(where, 'altı çizili hedef kelime cümlede yok')
    o = {
        'id': qid, 'cat': cat, 'kind': raw['kind'] or kind_d, 'prompt': raw['prompt'] or prompt_d,
        'lines': lines, 'opts': opts, 'optAr': optAr, 'ans': raw['ans'],
        'exp': exp_json(raw['exp'], where), 'gloss': [list(g) for g in raw['gloss']],
    }
    if not o['prompt']:
        err(where, 'soru yönergesi yok')
    if raw['target']:
        o['target'] = raw['target']
    if raw['noShuffle']:
        o['noShuffle'] = True
    if pid:
        o['pid'] = pid
    if raw['b'] is not None:
        o['b'] = raw['b']
    return o


def main():
    questions, passages = [], []

    # Eski sorular: yeni kategorilere taşınır, okuma parçası olanlar yeniden yazıldı.
    legacy = json.loads((HERE / 'legacy_questions.json').read_text())
    recat = {'q16': 'akis', 'q13': 'anlam', 'q14': 'diyalog', 'q15': 'diyalog'}
    for x in legacy:
        if x['id'] in ('q17a', 'q17b'):
            continue
        x = dict(x)
        x['cat'] = recat.get(x['id'], x['cat'])
        if x['cat'] == 'akis':
            x['kind'] = CATS['akis'][0]
        questions.append(x)

    for cat in CATS:
      qn, pn = 0, 0
      for suffix in ('', '_2', '_3'):
        m = load(f'q_{cat}{suffix}')
        if m is None:
            continue
        for raw in getattr(m, 'QS', []):
            qn += 1
            questions.append(make(cat, raw, f'{cat}{qn:03d}'))
            if suffix == '_3':
                questions[-1]['hard'] = True
        for p in getattr(m, 'PS', []):
            pn += 1
            pi = pn
            pid = f'{cat}P{pi:02d}'
            if LATIN.search(p['text']):
                err(pid, 'parçada Latin harf')
            if cat == 'cloze':
                nums = re.findall(r'\[(\d)\]', p['text'])
                if nums != [str(k) for k in range(1, len(p['qs']) + 1)]:
                    err(pid, f'boşluk numaraları soru sayısıyla uyuşmuyor: {nums}')
            passages.append({'id': pid, 'cat': cat, 'text': p['text'], **({'tr': p['tr']} if p['tr'] else {})})
            for qi, raw in enumerate(p['qs'], 1):
                if cat == 'cloze' and raw['b'] is None:
                    raw['b'] = qi
                questions.append(make(cat, raw, f'{pid}q{qi}', pid=pid))
                if suffix == '_3':
                    questions[-1]['hard'] = True

    # Güncel okuma metinleri (okuma bölümüne ve denemeye de girer)
    gms = [m for m in (load('okuma_guncel'), load('okuma_guncel_2')) if m is not None]
    if gms:
        class _G: pass
        gm = _G()
        gm.TOPICS = {}
        gm.TEXTS = []
        hard_ids = set()
        for mi, m in enumerate(gms):
            gm.TOPICS.update(m.TOPICS)
            for r in m.TEXTS:
                if mi > 0:
                    hard_ids.add(len(gm.TEXTS) + 1)
                gm.TEXTS.append(r)
        for gi, r in enumerate(gm.TEXTS, 1):
            pid = f'guncel{gi:02d}'
            if r['topic'] not in gm.TOPICS:
                err(pid, f'bilinmeyen konu: {r["topic"]}')
            if LATIN.search(r['text']):
                err(pid, 'metinde Latin harf')
            if AR.search(r['tr'] + r['title']):
                err(pid, 'çeviride ya da başlıkta Arapça harf')
            for a, t in r['gloss']:
                if LATIN.search(a) or AR.search(t):
                    err(pid, f'kelime listesi hatalı: {a} / {t}')
            if len(r['qs']) != 4:
                err(pid, 'dört soru olmalı')
            passages.append({'id': pid, 'cat': 'okuma', 'text': r['text'], 'tr': r['tr'], 'title': r['title'],
                             'topic': r['topic'], 'gloss': [list(g) for g in r['gloss']]})
            for qi, raw in enumerate(r['qs'], 1):
                questions.append(make('okuma', raw, f'{pid}q{qi}', pid=pid))
                if gi in hard_ids:
                    questions[-1]['hard'] = True

    # Harf-i cerli fiiller ve kalıp ifadeler
    import harfcer_build
    hm = load('harfcer')
    h_words, h_qs, h_blocks = harfcer_build.build(hm, err)
    for raw in h_qs:
        for l in raw['lines']:
            if LATIN.search(l['a']):
                err(raw['id'], f'Arapça satırda Latin harf: {l["a"]}')
        for o in raw['opts']:
            if raw['optAr'] and LATIN.search(o):
                err(raw['id'], f'Arapça şıkta Latin harf: {o}')
            if not raw['optAr'] and AR.search(o):
                err(raw['id'], f'Türkçe şıkta Arapça harf: {o}')
        if len(raw['opts']) != 5 or len(set(raw['opts'])) != 5:
            err(raw['id'], f'şıklar hatalı: {raw["opts"]}')
        questions.append({'id': raw['id'], 'cat': 'harfcer', 'kind': raw['kind'], 'prompt': raw['prompt'],
                          'lines': raw['lines'], 'opts': raw['opts'], 'optAr': raw['optAr'], 'ans': 0,
                          'exp': exp_json(raw['exp'], raw['id']), 'gloss': raw['gloss']})

    for x in questions:
        if x.get('hard'):
            k = x['kind'].replace(' · YDS düzeyi', '').replace(' · YDS', '')
            x['kind'] = {'Kelime': 'Kelime bilgisi', 'Anlamca en yakın': 'Anlamca en yakın cümle'}.get(k, k)

    # Sarf: bablar, çekim tabloları, türemiş isimler
    import sarf_build
    sm = load('sarf')
    sarf_data, sarf_topics = None, []
    if sm is not None:
        s_raw, sarf_data, sarf_topics = sarf_build.build(sm, q, err)
        for i, raw in enumerate(s_raw, 1):
            questions.append(make('sarf', raw, f'sarf{i:03d}'))
        for b in sm.BABS:
            for x in b['forms']:
                if LATIN.search(x):
                    err('bab ' + b['key'], f'Latin harf: {x}')
            for x in [b['name'], b['group']] + b['meanings'] + [e[1] for e in b['examples']] + [e[3] for e in b['examples']]:
                if AR.search(x):
                    err('bab ' + b['key'], f'Türkçe alanda Arapça: {x}')

    # Sıfırdan Arapça
    import baslangic_build
    bm = load('baslangic')
    bas_data = None
    if bm is not None:
        b_raw, bas_data = baslangic_build.build(bm, q, err)
        cnt = {}
        for lid, raw in b_raw:
            cnt[lid] = cnt.get(lid, 0) + 1
            questions.append(make('baslangic', raw, f'bl_{lid}_{cnt[lid]:02d}'))
        for l in bas_data['letters']:
            if AR.search(l['name'] + l['tr'] + l['note'] + l['ext']):
                err('harf ' + l['ch'], 'Türkçe alanda Arapça')
        for u in bas_data['units']:
            for les in u['lessons']:
                if AR.search(les['title'] + les['intro']):
                    err(les['id'], 'başlıkta Arapça')
                for b in les['blocks']:
                    if 'a' in b:
                        if LATIN.search(b['a']):
                            err(les['id'], f'Arapça blokta Latin: {b["a"]}')
                        if AR.search(b['tr']):
                            err(les['id'], f'çeviride Arapça: {b["tr"]}')
                    else:
                        for v in b.values():
                            if AR.search(v):
                                err(les['id'], f'Türkçe blokta Arapça: {v}')

    ids = [x['id'] for x in questions]
    if len(ids) != len(set(ids)):
        err('genel', 'tekrar eden soru kimliği')

    # Kelimeler
    words = json.loads((HERE / 'legacy_words.json').read_text())
    mods = [load(f.stem) for f in sorted(HERE.glob('words*.py'))]
    ex = {}
    new = []
    for wm in mods:
        ex.update(getattr(wm, 'LEGACY_EX', {}))
        new += getattr(wm, 'NEW', [])
    if True:
        for w in words:
            if w['id'] in ex:
                w['ex'], w['ext'] = ex[w['id']]
        seen = {(w['ar'], w['pos']) for w in words}
        n = len(words)
        for t in new:
            ar, root, extra, trn, pos = t[:5]
            key = (ar, pos)
            if key in seen:
                err(ar, 'sözlükte zaten var')
                continue
            seen.add(key)
            w = {'id': f'w{n}', 'ar': ar, 'root': root, 'extra': extra, 'tr': trn, 'pos': pos}
            if len(t) >= 7:
                w['ex'], w['ext'] = t[5], t[6]
            if pos not in 'fisb':
                err(ar, f'tür hatalı: {pos}')
            if LATIN.search(ar + root + extra + w.get('ex', '')):
                err(ar, 'Arapça alanda Latin harf')
            if AR.search(trn + w.get('ext', '')):
                err(ar, 'Türkçe alanda Arapça harf')
            words.append(w)
            n += 1

    for w in h_words:
        if LATIN.search(w['ar'] + w['root'] + w['extra'] + w['ex']):
            err(w['ar'], 'Arapça alanda Latin harf')
        if AR.search(w['tr'] + w['ext']):
            err(w['ar'], 'Türkçe alanda Arapça harf')
    words += h_words

    # Konu anlatımları
    topics = []
    tm = load('topics')
    if tm is not None:
        kinds_in_bank = {x['kind'] for x in questions}
        for t in tm.TOPICS + sarf_topics:
            if t['id'] == 'harfcer':
                t = dict(t, title='Harf-i cerli fiiller ve kalıplar',
                         intro='Fiillerin hangi edatla kullanıldığını ve edat değişince anlamın nasıl değiştiğini bilmek, kelime ve edat sorularının anahtarıdır.',
                         blocks=h_blocks, kinds=t['kinds'] + harfcer_build.KINDS)
            blocks = []
            for b in t['blocks']:
                if b[0] == 'a':
                    if LATIN.search(b[1]):
                        err(t['id'], f'Arapça örnekte Latin harf: {b[1]}')
                    if AR.search(b[2]):
                        err(t['id'], f'Çeviride Arapça harf: {b[2]}')
                    blocks.append({'a': b[1], 'tr': b[2]})
                else:
                    if AR.search(b[1]):
                        err(t['id'], f'Türkçe metinde Arapça harf: {b[1]}')
                    blocks.append({b[0]: b[1]})
            for k in t['kinds']:
                if k not in kinds_in_bank:
                    err(t['id'], f'bu türde soru yok: {k}')
            topics.append({'id': t['id'], 'title': t['title'], 'group': t['group'], 'intro': t['intro'],
                           'blocks': blocks, 'kinds': t['kinds']})

    if errors:
        print('\n'.join(errors))
        print(f'{len(errors)} HATA')
        sys.exit(1)

    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'questions.json').write_text(json.dumps(questions, ensure_ascii=False, indent=0))
    (OUT / 'passages.json').write_text(json.dumps(passages, ensure_ascii=False, indent=0))
    (OUT / 'words.json').write_text(json.dumps(words, ensure_ascii=False, indent=0))
    (OUT / 'topics.json').write_text(json.dumps(topics, ensure_ascii=False, indent=0))
    if bas_data:
        (OUT / 'baslangic.json').write_text(json.dumps(bas_data, ensure_ascii=False, indent=0))
    if sarf_data:
        (OUT / 'sarf.json').write_text(json.dumps(sarf_data, ensure_ascii=False, indent=0))
    print('Konu:', len(topics))
    from collections import Counter
    print('Soru:', len(questions), dict(Counter(x['cat'] for x in questions)))
    print('Parça:', len(passages), 'Kelime:', len(words), 'Örnekli:', sum(1 for w in words if w.get('ex')))


if __name__ == '__main__':
    main()
