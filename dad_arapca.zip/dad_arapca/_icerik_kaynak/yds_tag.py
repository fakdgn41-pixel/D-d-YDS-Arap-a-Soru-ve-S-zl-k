"""Sözlük kelimelerine YDS (2011-2013) yıl etiketi ekler.
Kaynak listenin PDF'den çıkarılmış metninde bazı harf çiftleri ters
dizilmiştir; eşleştirme bu bozulmayı hesaba katar."""
import json, re
from pathlib import Path
HERE = Path(__file__).parent
SW = set('حجخميىرز')

def norm(s):
    s = re.sub('[ً-ْٰـ]', '', s)
    s = re.sub('[أإآٱ]', 'ا', s).replace('ى', 'ي').replace('ة', 'ه')
    s = re.sub(r'\s+(ب|ل)ـ$', '', s.replace('ـ', ''))
    return re.sub(r'\s+', ' ', s).strip()

def variants(s):
    out = {s}
    def rec(i, cur):
        if i >= len(cur) - 1:
            out.add(cur); return
        rec(i + 1, cur)
        a, b = cur[i], cur[i + 1]
        if (b in SW and a != ' ') or (a == 'ل' and b == 'ا'):
            rec(i + 2, cur[:i] + b + a + cur[i + 2:])
    if len(s) <= 14:
        rec(0, s)
    return out

def load():
    raw = json.loads((HERE / 'yds_years.json').read_text())
    return {norm(k): v for k, v in raw.items()}

def tag(words):
    yy = load()
    n = 0
    for w in words:
        base = norm(w['ar'])
        keys = [base]
        if base.startswith('ال') and len(base) > 4:
            keys.append(base[2:])
        if base.endswith('ي') or w.get('pos') == 's':
            keys.append(base + 'ه')
        ex = norm(w.get('extra', ''))
        if w.get('pos') == 'i' and ex and ' ' not in ex:
            keys.append(ex)
        if w.get('pos') == 'f' and ' ' in base:
            keys.append(base.split(' ')[0])
        hit = None
        for k in keys:
            for v in variants(k):
                if v in yy:
                    hit = yy[v]; break
            if hit: break
        if hit:
            w['yds'] = sorted({y[:4] for y in hit})
            n += 1
    return n
