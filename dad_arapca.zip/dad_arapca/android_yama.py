"""flutter create ile üretilen Android dosyalarına bildirim eklentisinin
ihtiyaç duyduğu ayarları ekler. Birden fazla çalıştırılsa da sonuç aynıdır."""
import re
from pathlib import Path

man = Path('android/app/src/main/AndroidManifest.xml')
s = man.read_text()
perms = [
    '<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>',
    '<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>',
]
for p in perms:
    if p not in s:
        s = s.replace('<application', p + '\n    <application', 1)
receivers = '''
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
'''
if 'ScheduledNotificationReceiver' not in s:
    s = s.replace('</application>', receivers + '    </application>', 1)
man.write_text(s)

kts = Path('android/app/build.gradle.kts')
groovy = Path('android/app/build.gradle')
DESUGAR = 'com.android.tools:desugar_jdk_libs:2.1.4'
if kts.exists():
    g = kts.read_text()
    if 'isCoreLibraryDesugaringEnabled' not in g:
        g = re.sub(r'compileOptions\s*\{', 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true', g, count=1)
    if 'coreLibraryDesugaring(' not in g:
        g += f'\ndependencies {{\n    coreLibraryDesugaring("{DESUGAR}")\n}}\n'
    kts.write_text(g)
elif groovy.exists():
    g = groovy.read_text()
    if 'coreLibraryDesugaringEnabled' not in g:
        g = re.sub(r'compileOptions\s*\{', 'compileOptions {\n        coreLibraryDesugaringEnabled true', g, count=1)
    if 'coreLibraryDesugaring ' not in g:
        g += f"\ndependencies {{\n    coreLibraryDesugaring '{DESUGAR}'\n}}\n"
    groovy.write_text(g)
else:
    raise SystemExit('Android build dosyası bulunamadı')

# Sürüm derlemesinde R8, bildirim eklentisinin kullandığı Gson sınıflarını
# silmesin; yoksa zamanlanmış bildirim kurulurken hata verir.
rules = Path('android/app/proguard-rules.pro')
KEEP = """-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.dexterous.** { *; }
"""
old = rules.read_text() if rules.exists() else ''
if 'com.dexterous' not in old:
    rules.write_text(old + KEEP)
print('Android ayarları güncellendi')
