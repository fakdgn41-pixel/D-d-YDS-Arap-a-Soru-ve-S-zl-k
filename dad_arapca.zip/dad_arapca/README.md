# Dâd Arapça

YDS Arapça soru pratiği ve sözlük uygulaması (Flutter, Android).

## İçindekiler

- `lib/`: uygulama kodu
  - `screens/home.dart`: Ana sayfa (geri sayım, haftalık takvim, setler)
  - `screens/quiz.dart`: Soru ve cevap geri bildirimi
  - `screens/result.dart`: Set sonucu
  - `screens/dictionary.dart`, `screens/word.dart`: Sözlük ve kelime kartı
  - `screens/daily.dart`: Günlük sonuçlar ve Excel'e aktarma
- `assets/data/questions.json`: soru bankası (yeni soru eklemek için bu dosya düzenlenir)
- `assets/data/words.json`: sözlük
- `assets/fonts/`: Amiri, Figtree, Bricolage Grotesque (OFL lisanslı)
- `derle.sh`: GitHub'da otomatik derleme betiği. Depoda `.github/workflows/android.yml` dosyası tek satırlık bir ayarla bu betiği çalıştırır; proje depoya `dad_arapca.zip` olarak yüklenir.

---

## Yol 1: Bilgisayara hiçbir şey kurmadan GitHub ile derleme

1. github.com'da ücretsiz hesap aç.
2. Sağ üstteki **+** menüsünden **New repository** seç. Adı `dad-arapca` olsun, **Private** işaretle, oluştur.
3. Açılan sayfada **uploading an existing file** bağlantısına tıkla. Bu klasörün **içindeki her şeyi** sürükleyip bırak.
   - `.github` klasörü gizli olabilir. Mac'te Finder'da `Cmd + Shift + .`, Windows'ta Gezgin > Görünüm > Gizli öğeler ile görünür yap. Bu klasör yüklenmezse derleme başlamaz.
4. **Commit changes** düğmesine bas.
5. Üstteki **Actions** sekmesine geç. "Android derleme" birkaç dakika içinde kendiliğinden çalışır (çalışmazsa sol menüden seçip **Run workflow**).
6. Yeşil tik çıkınca çalışmaya tıkla. Alttaki **Artifacts** bölümünden `dad-arapca-…` dosyasını indir.
   - İçindeki `app-release.apk` dosyasını telefonuna at ve aç. Android "bilinmeyen kaynak" izni isteyecek, bir kez izin ver.

Derleme kırmızı çarpıyla biterse hata ekranının görüntüsünü veya metnini bana gönder, düzeltirim.

## Yol 2: Play Store için imzalı paket

Play Store, uygulamanın senin "yükleme anahtarınla" imzalanmasını ister. Bu anahtar bir kez oluşturulur.

1. Anahtarı oluştur (Java veya Android Studio kurulu bir bilgisayarda, terminalde):

   ```
   keytool -genkeypair -v -keystore upload.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
   ```

   Bir şifre ve ad-soyad bilgisi sorar. **`upload.jks` dosyasını ve şifreyi güvenli bir yerde sakla.**
   Bu dosyayı GitHub'a yükleme.

2. Dosyayı metne çevir:
   - Mac / Linux: `base64 -i upload.jks | pbcopy` (Linux'ta `base64 -w0 upload.jks`)
   - Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("upload.jks")) | Set-Clipboard`

3. GitHub'da depoya git: **Settings > Secrets and variables > Actions > New repository secret**. Üç tane ekle:
   - `KEYSTORE_BASE64`: 2. adımda kopyaladığın metin
   - `KEYSTORE_PASSWORD`: anahtar şifresi
   - `KEY_ALIAS`: `upload`

4. **Actions > Android derleme > Run workflow** ile yeniden çalıştır. Artık indirilen dosyada `dad-arapca-play.aab` da olacak. Play Console'a yüklenecek dosya budur.

## Play Console adımları

1. play.google.com/console adresinden geliştirici hesabı aç (tek seferlik 25 dolar, kimlik doğrulama).
2. **Uygulama oluştur**: ad "Dâd Arapça", dil Türkçe, ücretsiz.
3. **Test > Kapalı test**: yeni bir kanal oluştur, `dad-arapca-play.aab` dosyasını yükle, test edenlerin Gmail adreslerini ekle.
   - Yeni kişisel hesaplarda en az **12 test kullanıcısının 14 gün kesintisiz** testte kalması gerekir. Ondan sonra üretim (herkese açık yayın) başvurusu yapılabilir.
4. Mağaza kaydı için gerekenler:
   - 512×512 simge (`assets/icon/icon.png` küçültülerek kullanılabilir)
   - 1024×500 öne çıkan görsel
   - En az 2 telefon ekran görüntüsü
   - Gizlilik politikası bağlantısı (uygulama veriyi yalnızca telefonda tutar, internete bir şey göndermez)
   - Veri güvenliği formu: "Veri toplanmıyor / paylaşılmıyor"
5. Her yeni sürümde GitHub derlemesi sürüm numarasını kendiliğinden artırır. Yeni `.aab` dosyasını aynı kanala yüklemen yeterli.

## Yol 3: Kendi bilgisayarında geliştirme (isteğe bağlı)

Flutter ve Android Studio kuruluysa:

```
flutter create --org com.akdogan --project-name dad_arapca --platforms android .
rm -rf test
flutter pub get
dart run flutter_launcher_icons
flutter run
```

## Verileri genişletme

Yeni soru eklemek için `assets/data/questions.json` dosyasına aynı yapıda kayıt eklenir:

- `cat`: `kelime`, `gramer`, `ceviri`, `tamamlama`, `okuma`
- `lines`: soru satırları; `{"a": "..."}` Arapça, `{"t": "..."}` Türkçe satır. Boşluk için `------` yazılır.
- `opts`: beş şık, `ans`: doğru şıkkın sırası (0 = ilk), `optAr`: şıklar Arapça ise `true`
- `exp`: açıklama; `{"t": "..."}` Türkçe cümle, `{"a": "..."}` kendi satırında Arapça örnek
