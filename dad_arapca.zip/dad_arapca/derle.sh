#!/usr/bin/env bash
# GitHub Actions üzerinde Android derlemesi. Ayar dosyası bu betiği çalıştırır.
set -euo pipefail
cd "$(dirname "$0")"
OUT="${GITHUB_WORKSPACE:-$PWD}/cikti"
mkdir -p "$OUT"
BUILD="${GITHUB_RUN_NUMBER:-1}"

echo "::group::Flutter kurulumu"
if [ ! -d "$HOME/flutter" ]; then
  git clone -q --depth 1 -b stable https://github.com/flutter/flutter.git "$HOME/flutter"
fi
export PATH="$HOME/flutter/bin:$PATH"
if [ -n "${JAVA_HOME_17_X64:-}" ]; then export JAVA_HOME="$JAVA_HOME_17_X64"; fi
flutter --version
flutter config --no-analytics >/dev/null
echo "::endgroup::"

echo "::group::Android proje dosyaları"
if [ ! -d android ]; then
  flutter create --org com.akdogan --project-name dad_arapca --platforms android .
  rm -rf test
fi
sed -i 's/android:label="dad_arapca"/android:label="Dâd Arapça"/' android/app/src/main/AndroidManifest.xml
python3 android_yama.py
grep -n "compileOptions" -A3 android/app/build.gradle* || true
echo "::endgroup::"

echo "::group::Arapça sesler"
python3 -m venv /tmp/sesenv && /tmp/sesenv/bin/pip install -q edge-tts && /tmp/sesenv/bin/python ses_uret.py || echo "Sesler üretilemedi, uygulama sessiz derlenecek."
du -sh assets/audio || true
echo "::endgroup::"

echo "::group::Paketler ve simge"
flutter pub get
dart run flutter_launcher_icons
echo "::endgroup::"

echo "::group::Kod kontrolü"
flutter analyze --no-fatal-infos --no-fatal-warnings
echo "::endgroup::"

echo "::group::APK"
flutter build apk --release --build-number "$BUILD"
cp build/app/outputs/flutter-apk/app-release.apk "$OUT/dad-arapca.apk"
echo "::endgroup::"

echo "::group::AAB"
flutter build appbundle --release --build-number "$BUILD"
if [ -n "${KEYSTORE_BASE64:-}" ]; then
  echo "$KEYSTORE_BASE64" | base64 -d > /tmp/upload.jks
  cp build/app/outputs/bundle/release/app-release.aab "$OUT/dad-arapca-play.aab"
  zip -q -d "$OUT/dad-arapca-play.aab" 'META-INF/*.SF' 'META-INF/*.RSA' 'META-INF/*.EC' 'META-INF/*.DSA' 'META-INF/MANIFEST.MF' || true
  jarsigner -keystore /tmp/upload.jks -storepass "$KEYSTORE_PASSWORD" \
    -sigalg SHA256withRSA -digestalg SHA-256 "$OUT/dad-arapca-play.aab" "$KEY_ALIAS"
  jarsigner -verify "$OUT/dad-arapca-play.aab"
  rm /tmp/upload.jks
else
  echo "Yükleme anahtarı tanımlı değil; Play için imzalı AAB üretilmedi."
fi
echo "::endgroup::"

ls -la "$OUT"
